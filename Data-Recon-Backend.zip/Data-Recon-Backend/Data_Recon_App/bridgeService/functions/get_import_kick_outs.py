import csv
from . update_outs import update_outs


'''
<!---------- Method to get the imported kick outs file data
             and return as structured data ----------!>
'''


def get_import_kick_outs(recon_id, file_path):

    # Creating the data object
    data_object = {
        'status': 200,
        'recon_id': recon_id,
        'rows': []
    }

    # Reding the imported file
    with open(file_path, newline='', encoding="utf-8-sig") as Outs_File:
        reader = csv.reader(Outs_File)

        # Looping through the file data
        for index, row in enumerate(reader):
            number_of_col = len(row)

            # Checking if all columns are there
            if number_of_col < 3:
                response_data = {
                    'status': 6002,
                    'message': 'Missing required columns in file!'
                }
                return response_data
            else:
                row_object = {
                    'app1_app2': row[0],
                    'source_member': row[1],
                    'bridge_member': row[2]
                }
                data_object['rows'].append(row_object)

    # Update kick outs
    response_data = update_outs(recon_id, data_object['rows'])

    return response_data
