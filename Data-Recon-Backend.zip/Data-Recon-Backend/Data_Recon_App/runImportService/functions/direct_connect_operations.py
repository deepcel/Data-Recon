from ...models import ReconUser, ReconApplications, DCUser
from django.conf import settings
from Crypto.Cipher import AES
from zipfile import ZipFile
import zipfile
from ...utils.user_permissions import is_write_permitted
import requests
import time
import os
import pandas
import json
from pandas import json_normalize

def pbcs_fccs(request):
    email = request.data['email']
    recon_id = request.data['recon_id']
    app_type = request.data['appType']
    app_type = 0 if app_type == 0 else 1
    dc_jobname = request.data['jobname']

    app_instance = ReconApplications.objects.filter(recon_id=recon_id, app_name=app_type)[0]
    delimiter = app_instance.import_delimiter

    instance = ReconUser.objects.filter(email=email)
    instance = instance[0]
    # dc_url = instance.DC_Url
    dc_username = instance.DC_Username

    instance_url = ReconApplications.objects.filter(recon_id=recon_id, app_name=app_type)
    instance_url = instance_url[0]
    dc_url = instance_url.url

    key = b"\xf82\xea\xaap@\n'Yw\x10B\xd8b\xac\xc6"

    instance = ReconUser.objects.filter(email=email)[0]

    dc_password = bytes(instance.DC_Password)

    tag = bytes(instance.tag)

    nonce = bytes(instance.nonce)

    cipher = AES.new(key, AES.MODE_EAX, nonce)
    plaintext = cipher.decrypt_and_verify(dc_password, tag)

    dc_password = plaintext.decode()

    params = {
        "jobType": "EXPORT_DATA", "jobName": dc_jobname,
        "parameters": {
            "ExportFileName": "Direct_Connect_ExportData.zip"
        }
    }

    # Getting the app name for the Hyperion platform
    dc_appname = requests.get(dc_url + "/HyperionPlanning/rest/v3/applications",
                              auth=(dc_username, dc_password))
    dc_appname = dc_appname.json()
    dc_appname = dc_appname['items']
    dc_appname = dc_appname[0]['name']

    # Getting the job details from the platform
    dc_response = requests.get(dc_url + "/HyperionPlanning/rest/v3/applications/" + dc_appname + "/jobdefinitions",
                               auth=(dc_username, dc_password))

    dc_obj = dc_response.json()
    dc_obj = dc_obj['items']
    job_exists = False
    for i in dc_obj:
        if i['jobName'] == dc_jobname:
            job_exists = True

    # Prepping the job to be exported from the cloud
    if job_exists:
        export_obj = requests.post(dc_url + "/HyperionPlanning/rest/v3/applications/" + dc_appname + "/jobs",
                                   auth=(dc_username, dc_password), json=params)
        export_obj = export_obj.json()
        job_id = export_obj['jobId']

        time.sleep(7)

        # Downloading the export file from the cloud
        dc_file = requests.get(
            dc_url + "/interop/rest/11.1.2.3.600/applicationsnapshots/" + dc_jobname + ".zip/contents",
            auth=(dc_username, dc_password))

        # Creating the folder if the folder doesn't exist
        folder_path = os.path.join(settings.MEDIA_ROOT, str(recon_id))
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)

        # Saving as a zip file
        with open(settings.MEDIA_ROOT + "/" + str(recon_id) + "/" + dc_jobname + ".zip", 'wb') as fd:
            for chunk in dc_file.iter_content():
                fd.write(chunk)

        zipfilepath = settings.MEDIA_ROOT + "/" + str(recon_id) + "/" + dc_jobname + ".zip"
        cont = zipfile.ZipFile(zipfilepath)
        cont = cont.namelist()
        file_name = []
        filepath = []
        for file in cont:
            file_name.append(file)
            filepath.append(str(settings.MEDIA_ROOT + "/" + str(recon_id) + "/" + file))

            with ZipFile(settings.MEDIA_ROOT + "/" + str(recon_id) + "/" + dc_jobname + ".zip", 'r') as zObject:
                # Extracting all the members of the zip
                # into a specific location.
                zObject.extractall(
                    path=settings.MEDIA_ROOT + "/" + str(recon_id))

        file_location = filepath[0].replace(cont[0], '')
        response_data = [file_name, file_location, filepath]
    else:
        response_data = {
            'status': 6002,
            'message': 'Please Enter A Valid Job Name'
        }

    return response_data


def onestream(request):
    email = request.data['email']
    instance = ReconUser.objects.filter(email=email)
    instance = instance[0]
    if instance.onestream:
        admin_tag = instance.admin_tag
        onestream_instance = DCUser.objects.filter(email=admin_tag)
        onestream_instance = onestream_instance[0]
        onestream_url = onestream_instance.dc_url
        onestream_client_id = onestream_instance.dc_username
        onestream_client_secret = onestream_instance.dc_password
        onestream_tenant_id = onestream_instance.tenant_id

        key = b"\xf82\xea\xaap@\n'Yw\x10B\xd8b\xac\xc6"

        tag = bytes(onestream_instance.tag)

        nonce = bytes(onestream_instance.nonce)

        cipher = AES.new(key, AES.MODE_EAX, nonce)
        plaintext = cipher.decrypt_and_verify(onestream_client_secret, tag)

        onestream_client_secret = plaintext.decode()

        # Acquiring Access Token from IDP
        payload = 'grant_type=client_credentials&Scope=api://' + onestream_client_id + '/.default'
        headers = {
            'Accept': 'application/json',
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        url = "https://login.microsoftonline.com/" + onestream_tenant_id + "/oauth2/v2.0/token"

        onestream_access_token = requests.post(url, headers=headers, data=payload,
                                               auth=(onestream_client_id, onestream_client_secret))

        onestream_access_token = onestream_access_token.json()
        onestream_access_token = onestream_access_token['access_token']

        application_name = request.data['application_name']

        cube_name = request.data['cube_name']
        custom_subs = 'RecCube=' + cube_name
        dimensions = request.data['dimensions']
        for key, value in dimensions.items():
            key = 'Rec' + key + '='
            custom_subs += ',' + key + value

        params = {
            'BaseWebServerUrl': onestream_instance.dc_url+"/OneStreamWeb",
            'ApplicationName': application_name,
            'AdapterName': 'DataRecon',
            'ResultDataTableName': 'ResultsTable',
            'IsSystemLevel': 'False',
            'CustomSubstVarsAsCommaSeparatedPairs': custom_subs
        }

        headers = {
            'Authorization': 'Bearer ' + onestream_access_token,
            'Content-Type': 'application/json'
        }

        extracted_data = requests.post(
            onestream_url + "/OneStreamApi/api/DataProvider/GetAdoDataSetForAdapter?api-version=5.2.0",
            headers=headers, json=params)
        # print(extracted_data.text)
        data = json.loads(extracted_data.json())
        df_onestream = json_normalize(data['Table'])
        print(df_onestream)

        response_data = {
            'status': 200,
            'message': 'Success',
            'headers': headers,
            'params': params
        }
    else:
        response_data = {
            'status': 6002,
            'message': 'User does not have access to onestream'
        }
    return response_data
