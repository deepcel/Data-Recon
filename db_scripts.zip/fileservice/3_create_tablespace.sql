DROP TABLESPACE IF EXISTS tbsp_data_recon2;
CREATE TABLESPACE tbsp_data_recon2
  OWNER postgres
  LOCATION 'C:\Workspace\tbsp_data_recon2';

ALTER TABLESPACE tbsp_data_recon2
  OWNER TO postgres;