import React from "react";
import { useSelector } from "react-redux";
import { Bars } from 'react-loader-spinner';
import './Loader.scss';

const PageLoader = () => {
  const { loading } = useSelector((state) => state.loader);
  return (
    loading && <div className="loader-layer">
          <div className='loader-wrapper'>
            <div className='loader'>
              <Bars
                height="70"
                width="70"
                color="#333366"
                ariaLabel="bars-loading"
                wrapperStyle={{}}
                wrapperClass=""
                visible={true}
              />
            </div>
            <div className='loaderText'>
              <h4>Loading...</h4>
            </div>
          </div>
        </div>
  );
};
export default PageLoader;
