import React, { useState, useRef} from "react";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import { jecommentsImport } from "../../../../store/sliceReducers/BridgeMemberReducer";
import { getExtension, chooseOptions, uploadOptions, cancelOptions } from "../../../../utils/fileutils";
import { FileUpload } from 'primereact/fileupload';
import { Button } from "primereact/button";
import "./bridgeMembers.scss";

const JECommentsFile = (props) => {

  const dispatch = useDispatch();
  const authData = useSelector((state) => state.auth);
  let { data } = authData.data;
  const AccessType = data.access_type.privilege === 0 ? true : false;
  const fileUploadRef = useRef(null);
  
  const [totalSizecommentJE, setTotalSizecommentJE] = useState(0);

  const selectedReconId = useSelector(state =>
    state.reconRun.selectedReconRunId
  );

  const onTemplateRemovecommentJE = (file, callback) => {
    setTotalSizecommentJE(totalSizecommentJE - file.size);
    callback();
  };

  const itemTemplatecommentJE = (file, props) => {
    return (
      <div className="flex justify-content-between ">
        <div className="flex align-items-center" style={{ width: "40%" }}>
          <span className="flex flex-column text-left ml-3">{file.name}</span>
        </div>
        <Button
          icon="pi pi-times"
          className="p-button-secondary"
          onClick={() => onTemplateRemovecommentJE(file, props.onRemove)}
        />
      </div>
    );
  };

  const commentJEFile = (files) => {
    const supportedFileFormat = ["csv", "txt"];
    const [file] = files;
    if (file) {
      if (!supportedFileFormat.includes(getExtension(file.name))) {
        toast.error("Unsupported file format, Please upload valid files(.csv,.txt)");
        return;
      }
    }
    const fileReader = new FileReader();
    fileReader.onload = (e) => {
      let formData = new FormData();
      formData.append('comments_file', file);
      formData.append('recon_id', selectedReconId);
      dispatch(jecommentsImport(formData));
      fileUploadRef.current.clear(); 
    };
    fileReader.readAsDataURL(file);
  }

  const jecommentsFileUpload = ({ files }) => {
    commentJEFile(files);
  }

  return (
    <>
      <div className="col-12">
        <FileUpload accept=".csv, .txt"
        ref={fileUploadRef}
          disabled={!AccessType}
          maxFileSize={100000000}
          customUpload
          chooseOptions={chooseOptions}
          uploadOptions={uploadOptions}
          cancelOptions={cancelOptions}
          itemTemplate={itemTemplatecommentJE}
          uploadHandler={jecommentsFileUpload}
          emptyTemplate={<p className="m-0">Drag and drop files to here to upload.</p>} />
      </div>
    </>
  )
}
export default JECommentsFile;