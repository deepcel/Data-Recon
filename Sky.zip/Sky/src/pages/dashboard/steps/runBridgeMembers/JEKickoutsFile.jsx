import React, { useState, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import "./runBridgeMembers.scss";
import {
  unMappedKickoutImportJE,
} from "../../../../store/sliceReducers/RunBridgeReducer";
import { getExtension, chooseOptions, uploadOptions, cancelOptions } from "../../../../utils/fileutils";
import { toast } from "react-toastify";
import { Button } from "primereact/button";
import { FileUpload } from 'primereact/fileupload';
import 'primeicons/primeicons.css';
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';

const JEKickoutsFile = () => {
  const dispatch = useDispatch();
  const authData = useSelector((state) => state.auth);
  let { data } = authData.data;
  const AccessType = data.access_type.privilege === 0 ? true : false;
  const fileUploadRef = useRef(null);
  const [totalSizeBridgeJE, setTotalSizeBridgeJE] = useState(0);

  const selectedReconId = useSelector(state =>
    state.reconRun.selectedReconRunId
  );

  const onTemplateRemoveBridgeJE = (file, callback) => {
    setTotalSizeBridgeJE(totalSizeBridgeJE - file.size);
    callback();
  };
  const itemTemplateBridgeJE = (file, props) => {
    return (
      <div className="flex justify-content-between ">
        <div className="flex align-items-center" style={{ width: "40%" }}>
          <span className="flex flex-column text-left ml-3">{file.name}</span>
        </div>

        <Button
          icon="pi pi-times"
          className="p-button-secondary"
          onClick={() => onTemplateRemoveBridgeJE(file, props.onRemove)}
        />
      </div>
    );
  };

  const unMappedKickoutFileuploadJE = ({ files }) => {
    const supportedFileFormat = ["csv", "txt"];
    const [file] = files;
    if (file) {
      if (!supportedFileFormat.includes(getExtension(file.name))) {
        toast.error("Unsupported file format, Please upload valid files(.csv,.txt)");
        return;
      }
    }
    const fileReader = new FileReader();
    fileReader.onload = (e) => {
      let formData = new FormData();
      formData.append('kick_out_file', file);
      formData.append('recon_id', selectedReconId);
      dispatch(unMappedKickoutImportJE(formData, selectedReconId));
      fileUploadRef.current.clear(); 
    };
    fileReader.readAsDataURL(file);
  };

  return (
    <>
      <FileUpload accept=".csv, .txt"
      ref={fileUploadRef}
        disabled={!AccessType}
        maxFileSize={100000000}
        customUpload
        chooseOptions={chooseOptions}
        uploadOptions={uploadOptions}
        cancelOptions={cancelOptions}
        itemTemplate={itemTemplateBridgeJE}
        uploadHandler={unMappedKickoutFileuploadJE}
        emptyTemplate={<p className="m-0">Drag and drop files to here to upload.</p>} />
    </>
  )
}
export default JEKickoutsFile;