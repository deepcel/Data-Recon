from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from . import views


urlpatterns = [
    path('dimension/list/<int:recon_id>', views.dimension_names_list, name='dimension_names_list'),
    path('list/<int:recon_id>', views.bridge_list, name='bridge_list'),
    path('update', views.bridge_update, name='bridge_update'),
    path('import', views.import_bridge, name='import_bridge'),
    path('delete', views.delete_bridge, name='delete_bridge'),
    path('export', views.export_bridge, name='export_bridge'),
    path('run', views.run_bridge, name='run_bridge'),
    path('outs', views.get_kick_outs, name='get_kick_outs'),
    path('outs/update', views.update_kick_outs, name='update_kick_outs'),
    path('comments/import', views.import_comments, name='import_comments'),
    path('comments/update', views.comments_update, name='comments_update'),
    path('comments/list/<int:recon_id>', views.comments_list, name='comments_list'),
    path('comments/delete', views.delete_comment, name='delete_comment'),
    path('comments/export/<int:recon_id>', views.comments_export, name='comments_export'),
    path('outs/export', views.kick_out_export, name='kick_out_export'),
    path('outs/import', views.import_kick_outs, name='import_kick_outs'),
    path('run/export/', views.run_bridge_export, name='run_bridge_export'),
    path('comments/je/import', views.import_je_comments, name='import_je_comments'),
    path('comments/je/update', views.je_comments_update, name='je_comments_update'),
    path('comments/je/list/<int:recon_id>', views.je_comments_list, name='je_comments_list'),
    path('comments/je/delete', views.delete_je_comment, name='delete_je_comment'),
    path('comments/je/export/<int:recon_id>', views.je_comments_export, name='comments_export'),
    path('default', views.default_function, name='default_function'),
]

urlpatterns = format_suffix_patterns(urlpatterns)
