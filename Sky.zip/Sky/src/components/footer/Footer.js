import React from "react";

// This footer component used in login page for copyrights
const Footer = () => {
    return (
        <div className="bg-primary text-gray-100 p-3 flex justify-content-right lg:justify-content-right align-items-right flex-wrap">
            <div className="hidden lg:flex" >
                <span className="line-height-3">Copyright © 2022. All rights reserved @Donyati.</span>
            </div>
        </div>
    )
}
export default Footer;