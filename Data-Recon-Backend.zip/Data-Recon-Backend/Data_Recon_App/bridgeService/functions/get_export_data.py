from ... models import ReconBridgeMapping, ReconDimensions
from ..serializers import BridgeGetSerializer, DimensionNameSerializer
import io
import csv
from . get_comments import get_comments
from ... utils.get_recon import get_recon
from .get_view_data import get_kick_out_view_data, get_view_data


'''
<!---------- Method to get the bridge data from db
             and return as file data for download ----------!>
'''


def get_export_data(recon_id, app_type):
    # Get bridge instance and serialized data
    bridge_instance = ReconBridgeMapping.objects.filter(recon_id=recon_id, app_type=app_type, is_deleted=False)
    bridge_serialized = BridgeGetSerializer(bridge_instance, many=True)

    # Get dimension instance and serialized data
    dim_instance = ReconDimensions.objects.filter(is_deleted=False, recon_id=recon_id, app_type=app_type)
    dim_serialized = DimensionNameSerializer(dim_instance, many=True)

    # Creating a file object without saving
    csv_file = io.StringIO()
    header = ['dimension_name', 'source_member', 'flip_sign', 'bridge_member']
    csv_writer = csv.DictWriter(csv_file, fieldnames=header)
    # csv_writer.writeheader()

    for i in range(0, len(bridge_serialized.data)):
        dim_name = None
        if bridge_serialized.data[i]['dim_id']:
            dim_name = [x for x in dim_serialized.data
                        if x["dimensions_id"] == bridge_serialized.data[i]['dim_id']][0]['dimension']

        # Creating the row object
        row = dict()
        row['dimension_name'] = dim_name
        row['source_member'] = bridge_serialized.data[i]['source_member']
        row['flip_sign'] = bridge_serialized.data[i]['flip_sign']
        row['bridge_member'] = bridge_serialized.data[i]['bridge_member']

        # Writing to file object
        csv_writer.writerow(row)

    return csv_file


def get_comment_export_data(recon_id, je):
    # Get bridge instance and serialized data
    comments_data = get_comments(recon_id, je)

    # Get dimension instance and serialized data
    dim_instance = ReconDimensions.objects.filter(is_deleted=False, recon_id=recon_id)
    dim_serialized = DimensionNameSerializer(dim_instance, many=True)

    # Creating a file object without saving
    csv_file = io.StringIO()
    header = ['app_type', 'dimension_name', 'source_member', 'comment']
    csv_writer = csv.DictWriter(csv_file, fieldnames=header)

    for i in range(0, len(comments_data['rows'])):
        dim_name = None
        if comments_data['rows'][i]['dim_id']:
            dim_name = [x for x in dim_serialized.data
                        if x["dimensions_id"] == comments_data['rows'][i]['dim_id']][0]['dimension']

        # Creating the row object
        row = dict()
        row['app_type'] = comments_data['rows'][i]['app_type']
        row['dimension_name'] = dim_name
        row['source_member'] = comments_data['rows'][i]['source_member']
        row['comment'] = comments_data['rows'][i]['comment']

        # Writing to file object
        csv_writer.writerow(row)

    return csv_file


def get_kick_out_export_data(recon_id):
    recon_data = get_recon(recon_id)
    recon_name = recon_data['name']
    app1_id = recon_data['app1_id']
    app2_id = recon_data['app2_id']

    # Getting both apps data
    view_query = 'SELECT * FROM fileService.view_bridge_' + str(recon_id) + \
                 '_kickout'
    kick_out_data = get_kick_out_view_data(view_query, app1_id, app2_id)

    # Creating a file object without saving
    csv_file = io.StringIO()
    header = ['app1_app2', 'source_member']
    csv_writer = csv.DictWriter(csv_file, fieldnames=header)

    for i in range(0, len(kick_out_data['rows'])):
        # Creating the row object
        row = dict()
        row['app1_app2'] = kick_out_data['rows'][i]['app1_app2']
        row['source_member'] = kick_out_data['rows'][i]['source_member']

        # Writing to file object
        csv_writer.writerow(row)

    return csv_file


def get_run_bridge_export_data(recon_id):
    recon_data = get_recon(recon_id)
    recon_name = recon_data['name']
    app1_id = recon_data['app1_id']
    app2_id = recon_data['app2_id']

    # Getting both apps data
    view_query = 'SELECT * FROM fileService.view_bridge_' + str(recon_id) + \
                 ' where not(kickout)'
    bridge_run_data = get_view_data(view_query, app1_id, app2_id)

    # Creating a file object without saving
    csv_file = io.StringIO()
    header = bridge_run_data['headers']
    csv_writer = csv.DictWriter(csv_file, fieldnames=header)
    csv_writer.writeheader()

    for i in range(0, len(bridge_run_data['rows'])):
        # Creating the row object
        row = dict()

        # Looping headers and adding in object
        for head in header:
            if head == 'Comments':
                comment_data = list(filter(None, bridge_run_data['rows'][i][head]))
                if comment_data:
                    bridge_run_data['rows'][i][head] = "-".join(comment_data)
                else:
                    bridge_run_data['rows'][i][head] = None

            row[head] = bridge_run_data['rows'][i][head]

        # Writing to file object
        csv_writer.writerow(row)

    return csv_file
