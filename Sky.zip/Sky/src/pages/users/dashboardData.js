const dashboardLabel = {
    logo: {
        src: "./assets/images/Donyati-Logo.png",
        label: "logo"
    },
    navBtn: {
        // label: "Manage user",
        path: "/manageuser"
    }
};
export default dashboardLabel; 