import React,{useState} from "react";
import {
    getDirectConnectSourceData,DCDialogApp1
} from "../../../../store/sliceReducers/DirectConnectReducer";
import { useDispatch, useSelector } from "react-redux";
import "./runImport.scss";
import { Button } from "primereact/button";
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';
import App1Job from "./App1Job";
import OSExtracApp1 from "./OsExtractApp1";
import App1FileUpload from "./App1FileUpload";
import { useFormik } from 'formik';
import { classNames } from 'primereact/utils';
import { InputText } from 'primereact/inputtext';
import { Dialog } from 'primereact/dialog';
import { getEmail } from '../../../../utils/utils';
import DirectConnectTableApp1 from "../direct connect/DirectConnectTableApp1";

const App1SourceFile = () => {
   
    const app1_Import_type=useSelector(state =>
        state.dimField.reconDetails.app1_import_type
      );

    let showfileUpload=app1_Import_type==='0'?true:false;
    let showJob=((app1_Import_type==='1') ||(app1_Import_type==='2')) ?true:false;
    let showOneStream=app1_Import_type==='3'?true:false;

    return (
        <>
           {showfileUpload && <App1FileUpload/>}
           {showJob && <App1Job/>}
           {showOneStream && <OSExtracApp1/>}
        </>
    )
}
export default App1SourceFile;