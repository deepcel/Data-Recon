-- SEQUENCE: fileservice.recon_transformation_id_seq

DROP sequence if EXISTS fileservice.recon_transformation_id_seq CASCADE;

CREATE SEQUENCE fileservice.recon_transformation_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE fileservice.recon_transformation_id_seq
    OWNER TO "user_dataRecon_file";

GRANT ALL ON SEQUENCE fileservice.recon_transformation_id_seq TO postgres;

GRANT ALL ON SEQUENCE fileservice.recon_transformation_id_seq TO "user_dataRecon_file";


-- Table: fileservice.recon_transformation

DROP TABLE if exists fileservice.recon_transformation CASCADE;

CREATE TABLE fileservice.recon_transformation
(
    id bigint NOT NULL DEFAULT nextval('fileservice.recon_transformation_id_seq'::regclass),
    recon_id int8 NULL,
	app_id int8 NULL,
	dim_id int8 NULL,
	tgt_concat_dimid varchar NULL,
	tgt_concat_dimname varchar NULL,
	bridge_concat_dim_name varchar NULL,
	concat_delimiter char NULL,
	apply_all_members bool NULL,
	CONSTRAINT pk_recon_transformation_id PRIMARY KEY (id)
)

TABLESPACE tbsp_data_recon;

ALTER TABLE fileservice.recon_transformation
    OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE fileservice.recon_transformation TO postgres;

GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.recon_transformation TO "user_dataRecon_file";