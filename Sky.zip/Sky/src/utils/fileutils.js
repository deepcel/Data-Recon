
export const chooseOptions = {icon:"pi pi-plus" , className:"bg-primary" };
export const uploadOptions = { icon: 'pi pi-fw pi-cloud-upload', className: 'p-button-outlined bg-primary' };
export const cancelOptions = { icon: 'pi pi-fw pi-times',  className:"p-button-outlined bg-primary" };

export const getExtension=(path) =>{
    var basename = path.split(/[\\/]/).pop(),  // extract file name from full path ...
        // (supports `\\` and `/` separators)
        pos = basename.lastIndexOf(".");       // get last position of `.`

    if (basename === "" || pos < 1)            // if file name is empty or ...
        return "";                             //  `.` not found (-1) or comes first (0)

    return basename.slice(pos + 1);            // extract extension ignoring `.`
}

