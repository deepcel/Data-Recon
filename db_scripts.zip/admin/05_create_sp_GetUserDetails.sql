CREATE OR REPLACE FUNCTION admin.getuserdetails(userid character varying, name character varying, useremail character varying, password character varying)
 RETURNS SETOF admin."UserDetails"
 LANGUAGE sql
AS $function$

	CALL admin.sp_AddUser(UserId,Name,UserEmail,Password);
	SELECT * FROM admin."UserDetails" WHERE email=UserEmail;

$function$
;

-- Permissions

ALTER FUNCTION "admin".getuserdetails(varchar, varchar, varchar, varchar) OWNER TO "user_dataRecon_admin";
GRANT ALL ON FUNCTION "admin".getuserdetails(varchar, varchar, varchar, varchar) TO postgres;
