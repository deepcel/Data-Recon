create or replace procedure fileservice.sp_create_report(
	in recon_run_id integer
)
language 'plpgsql'
as $body$
declare
var_recon_id integer := recon_run_id;
s_schema_name text := 'fileservice';
var_bridge_name text := 'bridge_'||var_recon_id;
var_threshold integer := 0;
var_app1_id integer;
var_app2_id integer;
var_split integer := 1;
var_name text;
var_dim text[];
var_year text;
var_period text;
v_dim text;
var_amount text;
var_query text;
var_q1_sel text;
var_q2_cat text;
var_q1_sel_gt text;
var_order text := '';
v_order2 text := '';
var_round text := '';
var_piv text :='';
var_yp text;
v_yp text;
v_yp2 text;
v_yp3 text;
v_yp4 text;
v_yp5 text;
v_gt text;
var_yp2 text;
begin

	/*
	 * if active get the individual application id that belong to the recon id
	 *
	 */
	if
		exists (select 1 from fileservice.recon r where r.recon_id=var_recon_id and r.is_deleted=false)
		then
			select r.app1_id, r.app2_id, r.recon_id as view_name, r.variance_threshold
			into var_app1_id, var_app2_id, var_name, var_threshold
			from fileservice.recon r
			where r.recon_id = var_recon_id
			and r.is_deleted = false;
		else
			call fileService.sp_log_entry(
				null::integer,
				'''ERROR: Recon id '|| var_recon_id ||' does not exist''',
				var_recon_id,
				null::text
			);
			return;
	end if;

	/*
	 * Construct
	 * 1. Crosstab Query 1
	 * 2. Crosstab Query 1 modified for Grand Total
	 * 3. Crosstab Query 2
	 *
	 * Merge above 1,3 into Query for main pivot table
	 * union 2
	 * add 'order_by column is to force the 'Grand Total' record to the end'
	 *
	 * convert all of above to with clause and add:
	 * 'Below query will use with clause as the source table'
	 *
	 * Store above as view or table
	 *
	 */


	/*
	 * Crosstab Query Parts
	 */
	select
	concat(
		'concat(',
		string_agg(case when turn_on_define_order not in (0,1,2) then dim_name else null end,',''''|'''','),',''''|'''',',
		'concat(',string_agg(case when turn_on_define_order not in (0,1,2) then bridge_comment else null end,',''''^'''','),
		')) as conc',',',
	'concat(',string_agg(case when turn_on_define_order in (0,1) then dim_name else null end,','),') as year_period',','
	) as sel_clause_1, ----------------------------------------------------------------------------------------------------------------------
	'sum("Amount-Amount")' as amt,-----------------------------------------------------------------------------------------------------------
	concat(
		'concat(''''Grand Total''''',
		string_agg('',''),
		') as conc',',',
	'concat(',string_agg(case when turn_on_define_order in (0,1) then dim_name else null end,','),') as year_period',','
	) as sel_clause_gt, ---------------------------------------------------------------------------------------------------------------------
	concat(
	'concat(',string_agg(case when turn_on_define_order in (0,1) then dim_name else null end,','),') as year_period'
	) as sel_clause_category,----------------------------------------------------------------------------------------------------------------
	array_append(array_agg(case when turn_on_define_order not in (0,1,2) then dim_name end),'"bridge-comment"'
	) as dim_name, --------------------------------------------------------------------------------------------------------------------------
	trim(string_agg(dim_year,'')) as dim_year, ----------------------------------------------------------------------------------------------
	trim(string_agg(dim_period,'')) as dim_period -------------------------------------------------------------------------------------------
	into var_q1_sel, var_amount, var_q1_sel_gt, var_q2_cat, var_dim, var_year, var_period
	from (
		select
		distinct
		dim_name,
		dim_year, dim_period,
		concat('case ',string_agg(bridge_comment,' ') over (partition by turn_on_define_order::integer),' else '''''''' end') as bridge_comment,
		order_by, turn_on_define_order::integer
		from (
			select concat('"bridgesync-',rd1.dimension,'-',rd2.dimension,'"') as dim_name,
			case when rd1.turn_on_define_order::integer = 0 then concat('"bridgesync-',rd1.dimension,'-',rd2.dimension,'"') else '' end as dim_year,
			case when rd1.turn_on_define_order::integer = 1 then concat('"bridgesync-',rd1.dimension,'-',rd2.dimension,'"') else '' end as dim_period,
			concat('when trim(lower("bridgesync-',rd1.dimension,'-',rd2.dimension,'"))=trim(lower(''''',rbm.source_member,''''')) then ',case when rbm.bridge_comment is null then 'null' else ''''''||rbm.bridge_comment||'''''' end,'') as bridge_comment,
			rd1.turn_on_define_order, 1 as order_by
			from fileservice.recon r
			inner join fileservice.recon_dimensions rd1
			on rd1.recon_id = r.recon_id
			and rd1.recon_app_id = r.app1_id
			and rd1.is_active
			inner join fileservice.recon_dimensions rd2
			on rd2.recon_id = r.recon_id
			and rd2.recon_app_id = r.app2_id
			and rd2.is_active
			and rd1.turn_on_define_order = rd2.turn_on_define_order
			inner join fileservice.recon_bridge_mapping rbm
			on r.recon_id = rbm.recon_id
			and (rd1.dimensions_id=rbm.dim_id or rd2.dimensions_id=rbm.dim_id)
			and not rbm.is_deleted
			and not rbm.is_invalid
			where r.recon_id = var_recon_id --------------------------------------------------------------------------------------------------------------------------
			and rd1.dimension <> 'Amount'
		) q
		order by order_by, turn_on_define_order
	) q2
	;


	var_q2_cat = 'select '|| var_q2_cat ||' from '||s_schema_name||'.view_bridgesync_'||var_recon_id||' group by 1';
--	raise notice '%',var_q2_cat;

	execute 'select string_agg(concat(''"'',year_period,''"''),'','') as yp
from ('||var_q2_cat||')q'
	into v_yp;


	execute 'select substring(split_part(regexp_replace('''||v_yp||''',''"'','''',''g''),'','',1),5)'
	into var_order;

	execute 'select
	case
		when '''||var_order||''' = "Mon" then ''to_date(concat('||var_year||','||var_period||'),''''''''yyyyMon'''''''')''
		when '''||var_order||''' = "P_mm" then ''substring(concat('||var_year||','||var_period||'),length("year_period")-1)::integer''
		when trim('''||var_order||''',''0'') = "Month_ID"::text then ''to_date(concat('||var_year||','||var_period||'),''''''''MM'''''''')''
		when '''||var_order||''' = "Month" then ''to_date(concat('||var_year||','||var_period||'),''''''''Month'''''''')''
	end as yp_order_1,
	case
		when '''||var_order||''' = "Mon" then ''to_date(concat('||var_year||','||var_period||'),''''yyyyMon'''')''
		when '''||var_order||''' = "P_mm" then ''substring(concat('||var_year||','||var_period||'),length("year_period")-1)::integer''
		when trim('''||var_order||''',''0'') = "Month_ID"::text then ''to_date(concat('||var_year||','||var_period||'),''''MM'''')''
		when '''||var_order||''' = "Month" then ''to_date(concat('||var_year||','||var_period||'),''''Month'''')''
	end as yp_order_2
	from fileservice.recon_month_static
	where trim('''||var_order||''',''0'')::text in ("Month","Mon","P_mm","Month_ID"::text)'
	into var_order, v_order2;
--raise notice '%', var_order;

	
	/*
	 * Crosstab Query 1
	 */
	var_q1_sel = 'select '||var_q1_sel||var_amount||' from '||s_schema_name||'.view_bridgesync_'||var_recon_id||' group by 1,2 order by 1,'||var_order;
--raise notice '%', var_q1_sel;


	/*
	 * Crosstab Query 1 - Grand Total
	 */
	var_q1_sel_gt = 'select '|| var_q1_sel_gt||var_amount||' from '||s_schema_name||'.view_bridgesync_'||var_recon_id||' group by 1,2 order by 1,'||var_order;
--raise notice '%', var_q1_sel_gt;

	execute 'select string_agg(concat(''"'',year_period,''" decimal''),'','') as yp2
,string_agg(concat(''round(coalesce("'',year_period,''",0),2) as "'',year_period,''"''),'','') as yp3
,string_agg(concat(''case when "'',year_period,''"<0 then concat(''''('''',"'',year_period,''"* -1,'''')'''') else "'',year_period,''"::text end as "'',year_period,''"''),'','') as yp_4
,string_agg(concat(''case when "'',year_period,''"<0 then "'',year_period,''"*-1 else "'',year_period,''" end ''), ''+ '') as yp5 from ('||var_q2_cat||' order by '|| v_order2 ||')q'
	into v_yp2,v_yp3,v_yp4,v_yp5;

	/*
	 * Crosstab Query 2 - Category
	 */	
	var_q2_cat = var_q2_cat||' order by '||var_order;
--raise notice '%', var_q2_cat;

	var_order := '';
	var_query = 'drop table if exists '||s_schema_name||'.report_'||var_recon_id||' cascade; create table '||s_schema_name||'.report_'||var_recon_id;
	var_query = var_query||' as (with pivot_table as (';
	var_query = var_query||E'\n select ';
	
	foreach v_dim in array var_dim
	loop
		if v_dim is not null
		then
			if var_split = 1
			then
				v_gt = v_dim;
			end if;
		
			var_piv = var_piv||'split_part(conc,''|'','||var_split||') as '||v_dim||',';
			var_order = var_order||','||v_dim; 
			var_split = var_split+1;
		end if;
	end loop;
--raise notice '%', var_piv;

	var_query = var_query||E'\n'||var_piv||E'\n'||v_yp;
	var_query = var_query||E'\n ,1 as order_by \n from crosstab(';
	var_query = var_query||E'\n'''||var_q1_sel||''','||E'\n'''||var_q2_cat||''') as final_result (';
	var_query = var_query||E'\n conc text,'||v_yp2||E'\n ) ';
	
	/*union';
	var_query = var_query||E'\nselect \n'||var_piv||E'\n'||v_yp||E'\n ,2 as order_by \n from crosstab(';
	var_query = var_query||E'\n'''||var_q1_sel_gt||''','||E'\n'''||var_q2_cat||''') as final_result (';
	var_query = var_query||E'\nconc text,'||v_yp2||E'\n )*/
	
	var_query = var_query||'order by order_by'||var_order||E'), final_table as (\n select \n'||substring(var_order,2)||','||v_yp3||' from pivot_table) ';
	var_query = var_query||E'\nselect \n'||substring(var_order,2)||E',\n'||v_yp4||', ';
	var_query = var_query||E'\ncase \n\twhen ('||v_yp5||E')>'||var_threshold||E'\n\tthen '||v_yp5||E'\n\telse 0 '||'end as Grand_ABS_Total';
	var_query = var_query||E'\nfrom final_table \norder by case when '||v_gt||E'=''Grand Total'' then 2 else 1 end, '||substring(var_order,2)||');';

--raise notice '%',var_query;	
	execute var_query;

--	Log Script
	call fileService.sp_log_entry(
								null::integer,
								'''Report table report_'|| var_recon_id || ' created'''::text,
								var_recon_id::integer,
								'report_'||var_recon_id::text
								);

	update fileservice.recon 
	set status = 'Report Generated'
	where recon_id = var_recon_id;	

end;
$body$
