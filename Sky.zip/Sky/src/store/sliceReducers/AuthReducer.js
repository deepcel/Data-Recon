import { createSlice } from '@reduxjs/toolkit';
import { PURGE } from "redux-persist";
import { authUser, makePostAPICall, forgotPassPost, makePostAPICallRegister,makePostAPICallgetUserDetails,
         makePutAPICall, 
        makeResetPostAPICall} from '../../utils/apiService';
import { updateToken ,getEmail} from '../../utils/utils';
import { toast } from 'react-toastify';
import { enableLoader, hideLoader } from './LoadReducer';

// This reducer handles login
export const authReducer = createSlice({
    name: "auth",
    initialState: {
        data: [],
        error: null,
        loading: false,
        isAuthenticated: false
    },
    reducers: {
        isLoading: (state, action) => {
            state.error = null;
        },
        usersReceived: (state, action) => {
            state.data = action.payload;
            state.error = null;
        },
        directconnectdetailsReceived: (state, action) => {
            state.data = action.payload;
            state.error = null;
        },
        failedLogin: (state, action) => {
            state.data = [];
            state.error = action.payload.message;
        },
        resetSuccess:(state, action) => {
            state.loading = false;
            state.error = null;
        },
        clearError: (state) => {
            state.error = null;
        }
    },
    extraReducers: builder => {
        builder.addCase(PURGE, state => {
          state.loading = true
        })
}
    
})
export const { isLoading, usersReceived,
               usersCredentialReceived, failedLogin,
               resetSuccess, directconnectdetailsReceived, clearError } = authReducer.actions;

// Login api and update token
export const checkUserLogin = (payload) => async dispatch => {
    dispatch(enableLoader());
    try {
        const response = await authUser('user/auth', payload.email, payload.password);
        if (response.status === 200) {
            updateToken(response);
            getEmail();
            dispatch(usersReceived(response));
        } else {
            toast.error(response.message);
            dispatch(failedLogin(response));
            dispatch(hideLoader());
        }
        dispatch(hideLoader());
    }
    catch {
        dispatch(hideLoader());
    }
}

// get userCredentials by sending email
export const getUserCredentials = (payload) => async dispatch => {
    dispatch(enableLoader());
    try {
        const response = await makePostAPICallgetUserDetails('general/user/info', payload);
        if (response.status === 200)
         {  
            dispatch(usersReceived(response)); 
         } 
         else {
            toast.error(response.message);
            dispatch(failedLogin(response));
        }
        dispatch(hideLoader());    
    }
    catch {
        dispatch(hideLoader());
    }    
    dispatch(hideLoader());
}
// Logout api call
export const doLogout = () => async dispatch => {
    dispatch(enableLoader());
    try {
        const response = await makePostAPICall('user/logout');
        dispatch(failedLogin(response));
    }
    catch {
        dispatch(hideLoader());
    }
}

export const resetError = () => async dispatch => {
    dispatch(clearError());
}

export const sendResetDetails = (payload,callRedirect) => async dispatch => {
    dispatch(enableLoader({loading:true}));
    const response = await forgotPassPost('general/forgot',{email:payload.email});
    if(response.status === 200)
    {
      dispatch(resetSuccess(response));
      setTimeout(()=>{
        callRedirect(response);
      },2000)
      toast.success(response.message, { autoClose: 1000 });
    } else {
      dispatch(failedLogin(response));
      callRedirect(response);
    }
    dispatch(hideLoader({ loading: false }));
}

export const registerUserDetails = (payload, callRedirect, message) => async dispatch => {
    dispatch(enableLoader({loading:true}));
    const response = await makePostAPICallRegister('general/user/add',payload, false);
    if(response.status === 200){
      toast.success(message, { autoClose: 1000 });  
      dispatch(resetSuccess(response));
      setTimeout(() => {
        callRedirect();
      }, 1500)
    } else {
      dispatch(failedLogin(response));
      toast.error(response.message);
      callRedirect(response);
    }
    dispatch(hideLoader({ loading: false }));
}

export const resetPassword = (payload, callRedirect, message) => async dispatch => {
    dispatch(enableLoader({ loading: true }));
    const response = await makeResetPostAPICall('general/reset', payload);
    if (response.status === 200) {
        toast.success(message, { autoClose: 1000 });  
        dispatch(resetSuccess(response));
        setTimeout(() => {
            callRedirect();
          }, 1400)
    } else {
      dispatch(failedLogin(response));
      toast.error(response.message);
      callRedirect(response);
    }
    dispatch(hideLoader({ loading: false }));
  }

//Direct Connect Login
export const directconnectLogin = (payload, message) => async dispatch => {
    dispatch(enableLoader());
    try {
        const response = await makePutAPICall('recon/dc/info', payload);
        toast.success("Connected to direct connect successfully");  
        if (response.status === 200) {
            // updateToken(response);
            dispatch(directconnectdetailsReceived(response));
        } else {
            toast.error(response.message);
            dispatch(failedLogin(response));
            dispatch(hideLoader());
        }
    }
    catch {
        dispatch(hideLoader());
    }
}
export default authReducer.reducer;