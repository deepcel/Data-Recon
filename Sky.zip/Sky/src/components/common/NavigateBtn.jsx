import React from "react";
import { Button } from "primereact/button";
import { useNavigate } from "react-router";

const NavigateBtn = (props) => {
    const navigate = useNavigate();
    const navURI = props.path;
    const username=props.userName;
    return (
        <Button icon="pi pi-users" className="p-button-rounded p-button-secondary" tooltip="Manage user" tooltipOptions={{ position: 'bottom'}}
         iconPos="right" 
         style={{backgroundColor:"#494988",borderRadius:"50%",border:"1px solid #494988"}}
            onClick={() => {
                navigate(navURI)
        }}>
        </Button>
    )
}
export default NavigateBtn;