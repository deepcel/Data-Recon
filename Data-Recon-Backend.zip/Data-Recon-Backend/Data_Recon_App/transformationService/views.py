from django.http import HttpResponse
from rest_framework import status
from rest_framework.decorators import permission_classes, api_view, renderer_classes, parser_classes
from rest_framework.parsers import MultiPartParser, FormParser

from ..bridgeService.functions.add_dim_name import generic_dim_add
from ..utils.store_file import store_file
from rest_framework.permissions import IsAuthenticated
from rest_framework.renderers import JSONRenderer
from rest_framework.response import Response
from ..models import Recon, ReconTransformationOverride
from .functions.update_recon_trans import update_recon_trans
from .functions.get_transformations import get_transformations
from .functions.combine_sync_comb import combine_sync_comb
from .functions.update_tfn_sync import update_tfn_sync
from .functions.combine_sync_list import combine_sync_list
from .functions.export_sync_data import export_sync_data
from ..bridgeService.functions.is_valid_file import is_valid_file
from .functions.get_import_sync import get_import_sync
from .functions.execute_trans import execute_trans
from .functions.export_trans_run import export_trans_run
import datetime
from ..utils.user_permissions import is_write_permitted
from ..utils.run_export_script import run_export_script
from django.conf import settings
import pandas as pd
import os
from django.db import connections
from ..utils.export_query import run_trans_export_query


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def get_transformation(request, recon_id):
    # Checking if recon exists or not deleted
    if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
        source_data = get_transformations(recon_id)
        response_data = generic_dim_add(
            recon_id, source_data, 'rows', [{'key_id': 'app1_dimension_id', 'key_value': 'app_01'},
                                            {'key_id': 'app2_dimension_id', 'key_value': 'app_02'}],
            {'app1_dimension_id': 'app1_dim_name', 'app2_dimension_id': 'app2_dim_name'})
    else:
        response_data = {
            'status': 403,
            'message': 'No recon found with the specified id!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def update_transformation(request):
    # Getting the data from request
    recon_id = request.data['recon_id']
    trans_rows = request.data['rows']

    if is_write_permitted(request.user.email):
        # Checking if recon exists or not deleted
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            response_data = update_recon_trans(recon_id, trans_rows)
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def get_sync_combinations(request, recon_id):
    # Checking if recon exists or not deleted
    if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
        response_data = combine_sync_comb(recon_id)
    else:
        response_data = {
            'status': 403,
            'message': 'No recon found with the specified id!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def update_sync_mappings(request):
    # Getting the data from request
    recon_id = request.data['recon_id']
    app_type = request.data['app_type']
    sync_rows = request.data['rows']

    if is_write_permitted(request.user.email):
        # Checking if recon exists or not deleted
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            response_data = update_tfn_sync(recon_id, app_type, sync_rows)
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def get_tfn_sync(request, recon_id):
    # Checking if recon exists or not deleted
    if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
        response_data = combine_sync_list(recon_id)
    else:
        response_data = {
            'status': 403,
            'message': 'No recon found with the specified id!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def sync_export(request):
    # Getting the data from request
    recon_id = request.data['recon_id']
    app_type = request.data['app_type']
    app_key = 'App1_' if app_type == '0' else 'App2_'

    if is_write_permitted(request.user.email):
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            current_time = datetime.datetime.now().time().strftime("%H:%M:%S")
            current_date = datetime.datetime.now().strftime("%Y-%m-%d")
            modified_date = str(current_date) + '_' + str(current_time)
            file_name = app_key + 'Sync_Mappings_Export' + modified_date + '.csv'
            export_file = export_sync_data(recon_id, app_type)

            # Setting the download response
            response_data = HttpResponse(export_file.getvalue(), content_type='text/csv')
            response_data['Content-Disposition'] = 'attachment; filename=' + file_name
            response_data['Access-Control-Expose-Headers'] = 'Content-Disposition'
            return response_data
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@parser_classes((MultiPartParser, FormParser))
def import_sync(request):
    # Getting the data from request
    recon_id = request.data['recon_id']
    app_type = request.data['app_type']
    file_obj = request.FILES['sync_file']

    if is_write_permitted(request.user.email):
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            # Storing file
            save_file = store_file(recon_id, file_obj)
            file_path = save_file[1]

            is_valid = is_valid_file(file_path)
            if is_valid['status'] == 200:
                # Getting file data
                response_data = get_import_sync(recon_id, app_type, file_path)
            else:
                response_data = is_valid
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def run_transformation(request):
    # Getting the data from request
    recon_id = request.data['recon_id']
    max_rows = request.data['max_rows']
    page_number = request.data['page_number']

    if (request.data['sp_flag']):
        sp_flag = request.data['sp_flag']
    else:
        sp_flag = False

    # Checking if recon exists or not deleted
    if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
        response_data = execute_trans(recon_id, max_rows, page_number, sp_flag)
    else:
        response_data = {
            'status': 403,
            'message': 'No recon found with the specified id!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['DELETE'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def delete_sync(request):
    recon_id = request.data['recon_id']
    sync_id_list = request.data['sync_id']

    if is_write_permitted(request.user.email):

        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            for sync_id in sync_id_list:
                if ReconTransformationOverride.objects.filter(recon_id=recon_id, id=sync_id).exists():
                    instance = ReconTransformationOverride.objects.filter(recon_id=recon_id, id=sync_id)[0]
                    instance.delete()
                else:
                    response_data = {
                        'status': 403,
                        'message': 'No sync found with id ' + sync_id
                    }
                    return Response(response_data, status=status.HTTP_200_OK)
            response_data = {
                'status': 200,
                'message': 'Transformation sync deleted successfully!'
            }
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def run_trans_export(request, recon_id):
    if is_write_permitted(request.user.email):
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            current_time = datetime.datetime.now().time().strftime("%H:%M:%S")
            current_date = datetime.datetime.now().strftime("%Y-%m-%d")
            modified_date = str(current_date) + '_' + str(current_time)
            file_name = 'Run_transformation_Export.csv'

            # Calling functions for export query
            query = run_trans_export_query(recon_id)

            run_export_script(recon_id, file_name, query)

            file_path = os.path.join(settings.MEDIA_ROOT, str(recon_id) + "/export/" + file_name)
            file_path = (str(file_path).replace("\\", "/"))

            if os.path.exists(file_path):
                with open(file_path, 'rb') as fh:
                    response_data = HttpResponse(fh.read(), content_type="text/csv")
                    response_data['Content-Disposition'] = 'inline; filename=' + modified_date + os.path.basename(file_path)
                    response_data['Access-Control-Expose-Headers'] = 'Content-Disposition'
                    return response_data

            else:
                response_data = {
                    'status': 6002,
                    'message': 'File Not Found'
                }

            # Setting the download response
            # response_data = HttpResponse(export_file.getvalue(), content_type='text/csv')
            # response_data['Content-Disposition'] = 'attachment; filename=' + file_name
            # response_data['Access-Control-Expose-Headers'] = 'Content-Disposition'
            # return response_data
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)