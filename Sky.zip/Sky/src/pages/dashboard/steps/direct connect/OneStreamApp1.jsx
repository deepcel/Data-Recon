import React, { useState, useEffect } from 'react';
import { useDispatch,useSelector  } from "react-redux";
import { toast } from "react-toastify";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from "primereact/button";
import { InputText } from 'primereact/inputtext';        
import { InputTextarea } from 'primereact/inputtextarea';    
import { getEmail } from '../../../../utils/utils';    
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';
import { useFormik } from 'formik';
import { classNames } from 'primereact/utils';

function OneStreamApp1(props) {

  const email = getEmail();
  const authData = useSelector((state) => state.auth);
  let { data } = authData.data;
  const AccessType = data.access_type.privilege === 0 ? true : false;
  const dim=useSelector(state =>
    state.reconRun.dimensions.dimensionsimport
  );
  
  let app1dimensions= dim.map((item)=>{
    return (item.app1_is_active? item.app1_dimension.toUpperCase():'')
   });

   app1dimensions=app1dimensions.map(
    (item)=> (
    {
      dimension:item, values:''
    }
    ))
  console.log(app1dimensions)
  useEffect(()=>{
   
  },[])

  

const saveDimension=()=>{
 
//   if((dimensiontoSend.includes('YEAR'))&& (dimensiontoSend.includes('PERIOD'))&&(dimensiontoSend.includes('AMOUNT')))
//   {
//      dispatch(updateDimensions({
//               "recon_id":selectedReconId,
//               "appType":'0',  
//               "max_rows":5000,  
//               "page_number":1,
//               "headers":dimensiontoSend,
//               "files":fname}));
//   }
//   else
//   {
//     toast.info('YEAR, PERIOD, AMOUNT is a required dimension')
//   }
}

const oneStreamApp1 = useFormik({
  initialValues: {
      application_name:'',
      cube_name:''
  },
  validate: (data) => {
      let errors = {};

      if (!data.application_name) {
          errors.application_name = 'Application name is required.';
      }
      if (!data.cube_name) {
        errors.cube_name = 'Cube name is required.';
    }
      return errors;
  },
  onSubmit: (data) => {
      //    dispatch(getDirectConnectSourceData({
      //     "recon_id": selectedReconId,
      //     "application_name":data.application_name,
      //     "cube_name":data.cube_name,
      //     "dimensions":
      //     "appType": 0,               
      //     "email": email
      // }));
     data.application_name='';
     data.cube_name='';
  }
});
const isFormFieldValid = (name) => !!(oneStreamApp1.touched[name] && oneStreamApp1.errors[name]);
    const getFormErrorMessage = (name) => {
        return isFormFieldValid(name) && <small className="p-error">{oneStreamApp1.errors[name]}</small>;
    };

const renderHeader2 = () => {
  return (
     
          <form onSubmit={oneStreamApp1.handleSubmit} className="p-fluid">
          <div className="formgrid grid mb-2">
          <div className="col-2"> </div>
                <div className="col-4">
                      <span className="p-float-label p-input-icon-right">
                          <InputText id="application_name" value={oneStreamApp1.values.application_name}
                                     disabled={!AccessType}
                                     onChange={oneStreamApp1.handleChange}
                                     className={classNames({ 'p-invalid': isFormFieldValid('application_name') })} placeholder="Application Name" />
                          <label htmlFor="application_name" className={classNames({ 'p-error': isFormFieldValid('application_name') })}>Application Name*</label>
                      </span>
                      {getFormErrorMessage('application_name')}
                      </div>
                      <div className="col-4">
                      <span className="p-float-label p-input-icon-right">
                          <InputText id="cube_name" 
                                     value={oneStreamApp1.values.cube_name}
                                     disabled={!AccessType}
                                     onChange={oneStreamApp1.handleChange}
                                     className={classNames({ 'p-invalid': isFormFieldValid('cube_name') })} placeholder="Cube Name" />
                          <label htmlFor="cube_name" className={classNames({ 'p-error': isFormFieldValid('cube_name') })}>Cube Name*</label>
                      </span>
                      {getFormErrorMessage('cube_name')}
                      </div>
                      <div className="col-2">
                          <Button type="submit"
                                  disabled={!AccessType}
                                  label="Save Data" icon="pi pi-save" 
                                  className="  bg-primary" />
                  </div>
                  </div>
      </form>
     
  )
}

const actionBodyTemplate = (rowData) => {
  return (
    <React.Fragment>
      <Button icon="pi  pi-pencil" className="p-button-rounded p-button-warning mx-1 bg-primary"
        tooltip="edit"
       
        tooltipOptions={{ "position": "top" }}
       
      />
    </React.Fragment>
  );
}

const onCellEditComplete = (e) => {
  const updatedData = [...app1dimensions];
  let { rowData,newValue } = e;
  updatedData[e.rowIndex].values = newValue;
  // console.log('oscell'+ JSON.stringify(rowData))
  // console.log(e)
  app1dimensions=[...updatedData];
};

const textEditor = (options) => {
  return <InputTextarea type="text" value={options.value} 
  onChange={(e) => {options.editorCallback(e.target.value)}} className="w-full" />;
}
const header2 = renderHeader2();
  return (
   <DataTable id="DirectConnectTable"
              value={app1dimensions}
              header={header2}
              column
              dataKey="index"
              showGridlines
              scrollable
              scrollDirection="both"
              sortMode="multiple"
              scrollHeight="500px"
              rows={4}
              editMode="cell"
              paginator
              paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
              currentPageReportTemplate="Showing {first} to {last} of {totalRecords}"
              filterDisplay="menu"
              removableSort>
        <Column field="dimension" style={{ width: '25%' }}
                header="Dimensions"
                headerStyle={{fontSize:'1.1rem'}}/>
        <Column field="values" style={{ width: '75%',cursor:'pointer' }}
                editor={(options)=>textEditor(options)}               
                onCellEditComplete={onCellEditComplete}
                header="Edit Values"
                headerStyle={{fontSize:'1.1rem'}}/>
         {/* <Column style={{ width: '15%' }} align="left"
                    body={actionBodyTemplate} header="Action" ></Column> */}
</DataTable> 
    )
}
export default OneStreamApp1;