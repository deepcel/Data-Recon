from .. models import Recon, ReconApplications


'''
<!---------- Method to get recon and corresponding applications'
            data as a response ----------!>
'''


def get_recon(recon_id):
    recon_instance = Recon.objects.filter(recon_id=recon_id)[0]
    app1_id = recon_instance.app1_id
    app2_id = recon_instance.app2_id

    app1_instance = ReconApplications.objects.filter(recon_app_id=app1_id)[0]
    app2_instance = ReconApplications.objects.filter(recon_app_id=app2_id)[0]

    response = {
        'recon_id': recon_id,
        'name': recon_instance.name,
        'app1_id': recon_instance.app1_id,
        'app2_id': recon_instance.app2_id,
        'app1_delimiter': app1_instance.import_delimiter,
        'app2_delimiter': app2_instance.import_delimiter,
        'app1_has_header': app1_instance.has_header,
        'app2_has_header': app2_instance.has_header,
        'app1_import_type': app1_instance.import_type,
        'app2_import_type': app2_instance.import_type,
        'app1_source_file': app1_instance.filename,
        'app2_source_file': app2_instance.filename,
        'app1_currency_symbol': app1_instance.currency_symbol,
        'app1_currency_delimiter': app1_instance.currency_delimiter,
        'app2_currency_symbol': app2_instance.currency_symbol,
        'app2_currency_delimiter': app2_instance.currency_delimiter,
        'variance_threshold': recon_instance.variance_threshold,
        'created_by': recon_instance.created_by,
        'created_date': recon_instance.created_date,
        'last_modified_by': recon_instance.last_modified_by,
        'last_modified_date': recon_instance.last_modified_date,
        'execution_date': recon_instance.execution_date,
        'status': recon_instance.status,
        'description': recon_instance.description,
        'is_deleted': recon_instance.is_deleted
    }

    return response

