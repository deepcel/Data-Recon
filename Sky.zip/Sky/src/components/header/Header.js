import React, { useState, useEffect } from "react";
import { useSelector,useDispatch } from "react-redux";
import { useLocation } from 'react-router-dom';
import { Tooltip } from "primereact/tooltip";
import { isUserLoggedIn, redirectToLogin,getEmail } from "../../utils/utils";
import { persistor } from "../../store/index";
import "./header.scss";
import { getUserCredentials} from "../../store/sliceReducers/AuthReducer";
import dashboardLabel from "../../pages/users/dashboardData";
import NavigateBtn from "../common/NavigateBtn";
import NavigateImg from "../common/NavigateImg";

// Header component is common for all the pages
// and it's consist of logo and logout
const Header = () => {
  // state to decide user is logged in, to display logged out option
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [adminmode, setAdminmode] = useState(false);
  const [userName, setUserName]=useState('');
  const location = useLocation();
  const loc=location.pathname;
  const appData = useSelector((state) => state.auth);
  const mailId=getEmail();
  const dispatch= useDispatch();
  
  useEffect(()=>{
   
    if(mailId)
    {  
      dispatch(getUserCredentials({email:mailId}));
      let{data}=appData.data;
     
      if (data && (data.role==="Admin"))
         {
           setAdminmode(true);
           setUserName(data.first_name+' '+data.last_name);
         } 
         else 
         {
           setAdminmode(false);
         }
    }
   
 },[])
  // Based on user session set user loggedIn true/false
  useEffect(() => {
     if (isUserLoggedIn() || (appData && appData.data.status === 200 && appData.data.access_token !== "")) 
      {
       setIsLoggedIn(true);        
        let{data}=appData.data;
       
        if (data&&(data.role==="Admin"))
         {
           setAdminmode(true);
           setUserName(data.first_name+' '+data.last_name);
         } 
         else 
         {
           setAdminmode(false);
         }
    } 
    else {
      persistor.purge();
      setIsLoggedIn(false);
      
    }
  }, [appData]);

  // Clear session and redirect to login page
  const handleLogout = () => {
    persistor.purge();
    redirectToLogin();
  };
  return (
    <div className="flex flex-wrap md:justify-content-between justify-content-center bg-primary">
        {/* style={{width:'100%', position:'fixed' , top:'0', zIndex:'10'}}> */}
      <div className="text-white font-bold border-round m-2 flex align-items-center justify-content-center">
        <NavigateImg path={"/dashboard"} label={dashboardLabel.logo.src} name={userName}/>
        {/* <svg xmlns="http://www.w3.org/2000/svg" width="150" height="40" viewBox="0 0 240.509 84.801"
          path={'/dashboard'}>
          <g transform="translate(-61.662 -35.771)">
            <g transform="translate(61.662 35.771)">
              <path d="M324.848,109.726a14.321,14.321,0,0,1-8.432,2.386,16.651,16.651,0,0,1-5.49-.883,17.168,17.168,0,0,1-4.967-2.778l4.837-8.039a9.179,9.179,0,0,0,2.353,1.5,6.129,6.129,0,0,0,2.353.458,4.5,4.5,0,0,0,4.248-2.68l.85-1.634-14.64-34.509h11.96l8.431,23.006,7.516-23.006h11.568l-15.163,38.823A16.1,16.1,0,0,1,324.848,109.726Z" transform="translate(-186.175 -49.93)" fill="#fff">
              </path>
              <path d="M416.294,65.984q4.053,3.366,4.117,9.444V98.434H408.974V94.447q-3.53,4.509-10.653,4.509-5.621,0-8.856-3.039a10.474,10.474,0,0,1-3.236-8.006,9.5,9.5,0,0,1,3.5-7.844q3.5-2.808,10.033-2.875h9.215V76.8a4.713,4.713,0,0,0-1.732-3.922,7.9,7.9,0,0,0-5-1.372,20.191,20.191,0,0,0-5,.719,29.676,29.676,0,0,0-5.588,2.092l-3.2-7.844a46,46,0,0,1,8.268-2.908,35.1,35.1,0,0,1,8.2-.948Q412.24,62.618,416.294,65.984Zm-9.8,23.79a5.525,5.525,0,0,0,2.484-3.3V83.4h-6.928q-4.9,0-4.9,3.661a3.612,3.612,0,0,0,1.275,2.908,5.242,5.242,0,0,0,3.5,1.078A8.206,8.206,0,0,0,406.49,89.774Z" transform="translate(-227.086 -49.454)" fill="#fff"></path><path d="M487.506,88.655A17.458,17.458,0,0,1,483,90.387a21.746,21.746,0,0,1-5.163.621A11.934,11.934,0,0,1,469.369,88a10.772,10.772,0,0,1-3.236-8.3V64.538h-4.9V56.826h4.9v-9.8H477.7v9.8h9.15v7.712H477.7V77.871q0,3.725,3.071,3.726a11.35,11.35,0,0,0,4.51-1.177Z" transform="translate(-265.314 -41.505)" fill="#fff"></path><path d="M525.668,63.551h11.569V98.91H525.668Z" transform="translate(-298.155 -49.93)" fill="#fff"></path><path d="M150.5,73.743a22.787,22.787,0,0,1,4-6.112,17.053,17.053,0,0,1,12.752-5.305c10.3,0,18.832,7.878,18.832,18.177a18.648,18.648,0,0,1-18.648,18.648,19.962,19.962,0,0,1-5.291-.694c-.259-.071-9.283,3.191-16.851-1.543a7.8,7.8,0,0,1-3.563-7,13.838,13.838,0,0,1,2.861-6.762s-3.693,6.5,2.6,11.1c3.186,2.331,9.01,1.693,9.512,1.645,9.941-.943,17.167-7.321,20.889-13.166a25.865,25.865,0,0,0,2.983-6.245l1.726.5-2.983-7.955L173.023,74.9l1.806.314c-2.921,9.738-9.6,14.477-16.7,16.954a17.732,17.732,0,0,1-4.78.61c-4.33,0-7.209-2.543-7.756-4.863a8.871,8.871,0,0,1,2.132-8.062s-1.7,5.644,2.8,8.562c1.088.705,3.629.886,6.246.195a19.882,19.882,0,0,0,11.024-8.041l1.254.65-1.3-6.814-5.909,3.812s.26.122,1.366.705a11.673,11.673,0,0,1-6.359,6.049,8.653,8.653,0,0,1-4.987.8c-1.508-.351-2.523-1.014-2.737-4.1A24.756,24.756,0,0,1,150.5,73.743Z" transform="translate(-102.469 -49.306)" fill="#fff"></path><path d="M522.558,37.132l4.679,3.86,1.433,5.812,8.409-11.033Z" transform="translate(-296.57 -35.771)" fill="#fff"></path><path d="M261.966,66.278a12.283,12.283,0,0,0-9.313-3.659,14.414,14.414,0,0,0-6.83,1.568,12.566,12.566,0,0,0-4.869,4.64V63.076H229.32v3.344a21.413,21.413,0,0,1,5.267,14.063,22.926,22.926,0,0,1-5.267,14.755v3.2h11.634V79.743a7.7,7.7,0,0,1,2.189-4.837,6.714,6.714,0,0,1,4.739-1.9,5.735,5.735,0,0,1,4.378,1.732,6.63,6.63,0,0,1,1.634,4.738V98.435h11.568V76.147Q265.463,69.939,261.966,66.278Z" transform="translate(-147.113 -49.455)" fill="#fff"></path><path d="M105.037,65.94a21.151,21.151,0,0,1,.7-2.659,22.485,22.485,0,0,0-3.027-10.372,21.056,21.056,0,0,0-8.594-8.071A27.13,27.13,0,0,0,81.4,41.962H61.662V87.778H80.943A28.226,28.226,0,0,0,93.916,84.9a22.738,22.738,0,0,0,3.468-2.18C96.006,76.828,99.406,70.142,105.037,65.94ZM92.053,71.831a11.1,11.1,0,0,1-4.183,4.64,11.564,11.564,0,0,1-6.143,1.634h-8.1V51.7h7.516a12.317,12.317,0,0,1,6.406,1.667,11.722,11.722,0,0,1,4.411,4.672,14.524,14.524,0,0,1,1.6,6.928A15.145,15.145,0,0,1,92.053,71.831Z" transform="translate(-61.662 -38.927)" fill="#fff"
              >
              </path>
            </g>
            <path d="M61.883,181.778s14.676,1.355,40.6,2.218c19.021.633,50.481,1.024,68.948.876,28.967-.232,55.17-1.715,72.113-2.767,37.8-2.347,57.4-7.21,57.4-7.21s-20.835,8.515-86.619,13.47c-29.824,2.246-67.935,3.418-98.59,3.049s-53.855-2.279-53.855-2.279Z" transform="translate(-0.113 -70.908)" fill="#fff">
            </path>
          </g>
        </svg> */}
      </div>
      {
        // if user logged in then show logout options
        isLoggedIn && (
          <>
            <div className="title">
              <h1>DATA RECON AUTOMATION</h1>
            </div>
            {
               <div className="text-white font-bold border-round m-2 flex align-items-center justify-content-center">
              {/* <p>{userName}</p> &nbsp;&nbsp; */}
              {loc !=='/register' && adminmode && (
                <>
                  <NavigateBtn
                    path={dashboardLabel.navBtn.path}
                    label={dashboardLabel.navBtn.label}
                  />
                </>
              )}
              &nbsp;&nbsp;
              {loc !=='/register' &&
              <div className="login_box cursor-pointer" onClick={handleLogout}>
                <div className="pos p-link layout-topbar-button">
                  <i className="logout pi pi-sign-out"></i>
                  <Tooltip
                    target=".login_box"
                    content={`logout`}
                    position="bottom"
                  />
                </div>
              </div>
             }
            </div>
            }
          </>
        )
      }
    </div>
  );
};
export default Header;
