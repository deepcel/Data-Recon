import React, { useEffect, useState } from "react";
import { Button } from 'primereact/button';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { InputText } from 'primereact/inputtext';
import { InputSwitch } from 'primereact/inputswitch';
import { Badge } from 'primereact/badge';
import { ColumnGroup } from 'primereact/columngroup';
import { Row } from 'primereact/row';
import { Dropdown } from 'primereact/dropdown';
import { FilterMatchMode, FilterOperator } from 'primereact/api';
import {
    reorderDimension, updateReconDimension,
    listReconRunDimension, downloadApp1App2DimensionsFile
} from "../../../../store/sliceReducers/ReconRunReducer";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import "./dimensionLinking.scss";

const Dimensions = () => {
    const dispatch = useDispatch();
    const [editingRows, setEditingRows] = useState({});
    const authData = useSelector((state) => state.auth);
    let { data } = authData.data;
    const AccessType = data.access_type.privilege === 0 ? true : false;
    const [globalFilterValue1, setGlobalFilterValue1] = useState('');
    const [filters1, setFilters1] = useState(null);
    const [apidata, setapiData] = useState([]);

    const selectedReconId = useSelector(state =>
        state.reconRun.selectedReconRunId
    );

    const dimensions = useSelector(state =>
        state.reconRun.dimensions
    );

    useEffect(() => {
        setapiData(dimensions.dimensionsimport);
        initFilters1();
    }, [dimensions]);

    const clearFilter1 = () => {
        initFilters1();
    }

    const onGlobalFilterChange1 = (e) => {
        const value = e.target.value;
        let _filters1 = { ...filters1 };
        _filters1['global'].value = value;
        setFilters1(_filters1);
        setGlobalFilterValue1(value);
    }

    const initFilters1 = () => {
        setFilters1({
            'global': { value: null, matchMode: FilterMatchMode.CONTAINS },
            'app1_dimension': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'app1_dim_in_file': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'app1_type_field': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'app1_top_member': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'app2_dimension': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'app2_dim_in_file': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'app2_type_field': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'app2_top_member': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
        });
        setGlobalFilterValue1('');
    }

    const dimInFileData = [
        { label: 'YES', value: "YES" },
        { label: 'NO', value: "NO" },
    ];

    const textEditor = (options) => {
        // if(options.value)
        // {
        //     if((options.value.toUpperCase()!=='YEAR') && 
        //        (options.value.toUpperCase()!=='PERIOD') &&
        //        (options.value.toUpperCase()!=='AMOUNT'))
        //     {
             return <InputText type="text" value={options.value}
                     onChange={(e) => options.editorCallback(e.target.value)} className="w-full"
                               id={options.field + "_" + options.rowIndex}
                               disabled={getDisable(options)}/>;
    //         }
    //         else
    //         {
    //             return options.value
    //         }
    // }

    }

    const numberEditor = (options) => {
        return <InputText type="number" value={options.value}
            onChange={(e) => options.editorCallback(e.target.value)}
            className="w-full"
            id={options.field + "_" + options.rowIndex}
            disabled={getDisable(options)} />;
    }

    const addRow = () => {
        const newId = apidata.reduce((maxId, row) => Math.max(maxId, row.id), 0) + 1;
        let a = apidata.length.toString();

        setapiData([{
            id: newId,
            order: a,
            app1_dimension: '',
            app1_is_active: false,
            app1_dim_in_file: '',
            app1_type_field: '',
            app1_top_member: '',
            app1_app_type: '0',
            app2_is_active: false,
            app2_app_type: '1',
            app2_dimension: '',
            app2_dim_in_file: '',
            app2_type_field: '',
            app2_top_member: ''
        }, ...apidata]);
    };

    const getDisable = (options) => {
        if ((((options.rowData["app1_dim_in_file"]).toLowerCase() === 'no' && options.field.toLowerCase() === "app1_type_field") ||
            ((options.rowData["app1_dim_in_file"]).toLowerCase() === 'yes' && options.field.toLowerCase() === "app1_top_member")) ||
            (((options.rowData["app2_dim_in_file"]).toLowerCase() === 'no' && options.field.toLowerCase() === "app2_type_field") ||
                ((options.rowData["app2_dim_in_file"]).toLowerCase() === 'yes' && options.field.toLowerCase() === "app2_top_member"))) {
            return true;
        }
        else {
            return false;
        }
    }

    const setDisableField = (value, rowIndex, field) => {
        let app1TypeFieldElement = document.getElementById('app1_type_field_' + rowIndex);
        let app1TopMemberElement = document.getElementById('app1_top_member_' + rowIndex);
        let app2TypeFieldElement = document.getElementById('app2_type_field_' + rowIndex);
        let app2TopMemberElement = document.getElementById('app2_top_member_' + rowIndex);
        let trElement = document.getElementById('app1_top_member_' + rowIndex).closest('tr');
        app1TypeFieldElement.classList.remove('p-disabled');
        app1TopMemberElement.classList.remove('p-disabled');
        app2TypeFieldElement.classList.remove('p-disabled');
        app2TopMemberElement.classList.remove('p-disabled');
        if (field.toLowerCase() === "app1_dim_in_file" && value.toLowerCase() === 'yes') {
            app1TypeFieldElement.disabled = false;
            app1TopMemberElement.disabled = true;
            trElement.classList.remove("app1_dim_in_fileNo");
            trElement.classList.add("app1_dim_in_fileYes");
        }
        else if (field.toLowerCase() === "app1_dim_in_file" && value.toLowerCase() === 'no') {
            app1TypeFieldElement.disabled = true;
            app1TopMemberElement.disabled = false;
            trElement.classList.remove("app1_dim_in_fileYes");
            trElement.classList.add("app1_dim_in_fileNo");
        }

        if (field.toLowerCase() === "app2_dim_in_file" && value.toLowerCase() === 'yes') {
            app2TypeFieldElement.disabled = false;
            app2TopMemberElement.disabled = true;
            trElement.classList.remove("app2_dim_in_fileNo");
            trElement.classList.add("app2_dim_in_fileYes");
        }
        else if (field.toLowerCase() === "app2_dim_in_file" && value.toLowerCase() === 'no') {
            app2TypeFieldElement.disabled = true;
            app2TopMemberElement.disabled = false;
            trElement.classList.remove("app2_dim_in_fileYes");
            trElement.classList.add("app2_dim_in_fileNo");
        }
    }

    const statusEditor = (options) => {
        return (
            <InputSwitch checked={options.rowData.app1_is_active} 
                         onChange={(e) => options.editorCallback(!options.rowData.app1_is_active)} />
        );
    }

    const appDimInFileEditor = (options) => {
        console.log(options)
        return (
            <Dropdown value={options.value} options={dimInFileData} optionLabel="label" optionValue="value"
                onChange={(e) => { options.editorCallback(e.value); setDisableField(e.value, options.rowIndex, options.field); }} placeholder="select" />
        );
    }

    let headerGroup = <ColumnGroup>
        <Row>
            <Column header="" rowSpan={3} style={{ "width": "3%" }} />
            <Column header="Align Dimension Names and Information for APP1 & APP 2" 
                    colSpan={8} style={{ "width": "84%" }} />
            <Column header="Status" rowSpan={3} style={{ width: '6%' }} />
            <Column header="Edit" rowSpan={3} style={{ width: '7%' }} />
            <Column header="Delete" rowSpan={3} />
        </Row>
        <Row>
            <Column header="App1" colSpan={4} style={{ "width": "42%" }} />
            <Column header="App2" colSpan={4} style={{ "width": "42%" }} />
        </Row>
        <Row>
            <Column style={{ width: '20% !important' }}
             header="Dimension" sortable filter field="app1_dimension" />
            <Column style={{ width: '8% !important' }} header="Dim In File" sortable filter field="app1_dim_in_file" />
            <Column style={{ width: '9% !important' }} header="Yes-Type Field" sortable filter field="app1_type_field" />
            <Column style={{ width: '10% !important' }} header="No-Type Top Member" sortable filter field="app1_top_member" />
            <Column style={{ width: '15% !important' }} header="Dimension" sortable filter field="app2_dimension" />
            <Column style={{ width: '8% !important' }} header="Dim In File" sortable filter field="app2_dim_in_file" />
            <Column style={{ width: '9% !important' }} header="Yes-Type Field" sortable filter field="app2_type_field" />
            <Column style={{ width: '10% !important' }} header="No-Type Top Member" sortable filter field="app2_top_member" />
        </Row>
    </ColumnGroup>;

    const rowClass = (data) => {
        return {
            'app1DefaultDimension': data.app1_dimension?.substring(0, 3) === 'Dim',
            'app2DefaultDimension': data.app2_dimension?.substring(0, 3) === 'Dim',
            'app1_dim_in_fileYes': (data.app1_dim_in_file === 'YES' || data.app1_dim_in_file === 'yes'),
            'app2_dim_in_fileYes': (data.app2_dim_in_file === 'YES' || data.app2_dim_in_file === 'Yes'),
            'app1_dim_in_fileNo': (data.app1_dim_in_file === 'NO' || data.app1_dim_in_file === 'No'),
            'app2_dim_in_fileNo': (data.app2_dim_in_file === 'NO' || data.app2_dim_in_file === 'No')
        }
    }

    const isActiveTemplate = (rowData) => {
        return (
            <React.Fragment>
                <Badge value={rowData.app1_is_active ? "Active" : "Inactive"}
                    severity={`${(rowData.app1_is_active ? "success" : "info")}`}></Badge>
            </React.Fragment>
        );
    }
    const downloadApp1App2Dimensions = () => {
        dispatch(downloadApp1App2DimensionsFile(selectedReconId));
    }
    const app2topMemberTemplate = (rowData) => {
        return (
            <React.Fragment>
                {((rowData.app1_dim_in_file !== "") &&
                    (rowData.app2_dim_in_file === "" && rowData.app2_type_field === "" && rowData.app2_top_member === "")) ?
                    <span>App2NA_{rowData.app1_dimension}</span> : <span>{rowData.app2_top_member}</span>}
            </React.Fragment>
        );
    }

    const app1topMemberTemplate = (rowData) => {
        return (
            <React.Fragment>
                {((rowData.app2_dim_in_file !== "") && (rowData.app1_dim_in_file === "" && rowData.app1_type_field === "" && rowData.app1_top_member === "")) ?
                    <span>App1NA_{rowData.app2_dimension}</span> :
                    <span>{rowData.app1_top_member}</span>}
            </React.Fragment>
        );
    }

    const onRowEditChange = (e) => {
        {
            if (AccessType === true) {
                setEditingRows(e.data)
            }
        }
    }
     
    const onRowEditComplete = (e) => {
        let listOfDim = dimensions.dimensionsimport;
        let { newData } = e;
        let prevValues = listOfDim.find(p => p.order === newData.order);
        // console.log(newData, prevValues);
        const payload = {
            recon_id: selectedReconId,
            dimensions: [{
                ...newData,
                // prevValues
            }]
        }
        dispatch(updateReconDimension(payload));
        dispatch(listReconRunDimension(selectedReconId));
    }

    // const onRowReorder = (e) => {
    //     const dragIndex = e.dragIndex;
    //     const dropIndex = e.dropIndex;

    //     let dimensionClone = JSON.parse(JSON.stringify(dimensions));
    //     if (dimensionClone && ((dimensionClone[dragIndex].app1_dimension.toLowerCase() === "year") ||
    //         (dimensionClone[dropIndex].app1_dimension.toLowerCase() === "year") ||
    //         (dimensionClone[dragIndex].app1_dimension.toLowerCase() === "period") ||
    //         (dimensionClone[dropIndex].app1_dimension.toLowerCase() === "period"))
    //         || (dimensionClone[dragIndex].app1_dimension.toLowerCase() === "amount") ||
    //         dimensionClone[dropIndex].app1_dimension.toLowerCase() === "period") {
    //         toast.info('Year and Period and Amount dimension cannot be reordered');
    //         return;
    //     }

    //     dispatch(reorderDimension({
    //         "recon_id": selectedReconId,
    //         "dragOrder": dragIndex,
    //         "dropOrder": dropIndex
    //     }));
    //     toast.success(dimensionClone[dragIndex].app1_dimension + ' and ' + dimensionClone[dropIndex].app1_dimension + ' reordered successfully.');
    // }

    const onRowReorder = (e) => {
        const dragIndex = e.dragIndex;
        const dropIndex = e.dropIndex;
    
        let dimensionClone = JSON.parse(JSON.stringify(dimensions));
        if (
            (dimensionClone[dragIndex].app1_dimension.toLowerCase() === "year" ||
                dimensionClone[dragIndex].app1_dimension.toLowerCase() === "period" ||
                dimensionClone[dragIndex].app1_dimension.toLowerCase() === "amount") ||
            (dimensionClone[dropIndex].app1_dimension.toLowerCase() === "year" ||
                dimensionClone[dropIndex].app1_dimension.toLowerCase() === "period" ||
                dimensionClone[dropIndex].app1_dimension.toLowerCase() === "amount")
        ) {
            toast.info('Year, Period, and Amount dimensions cannot be reordered');
            return;
        }
    
        dispatch(
            reorderDimension({
                "recon_id": selectedReconId,
                "dragOrder": dragIndex,
                "dropOrder": dropIndex
            })
        );
        toast.success(
            dimensionClone[dragIndex].app1_dimension +
                ' and ' +
                dimensionClone[dropIndex].app1_dimension +
                ' reordered successfully.'
        );
    };

    const onRowEditValidator = (rowData) => {
        if (!rowData.app1_dimension) {
            toast.error("Please enter the app1 dimension");
            return false;
        }
        if (!rowData.app2_dimension) {
            toast.error("Please enter the app2 dimension");
            return false;
        }
        if (rowData.app1_dim_in_file.toLowerCase() === 'yes' && !rowData.app1_type_field) {
            toast.error("Please enter the app1 typefield.");
            return false;
        }

        if (rowData.app2_dim_in_file.toLowerCase() === 'yes' && !rowData.app2_type_field) {
            toast.error("Please enter the app2 typefield.");
            return false;
        }

        if (rowData.app1_dim_in_file.toLowerCase() === 'no' && !rowData.app1_top_member) {
            toast.error("Please enter the app1 top member.");
            return false;
        }

        if (rowData.app2_dim_in_file.toLowerCase() === 'no' && !rowData.app2_top_member) {
            toast.error("Please enter the app2 top member.");
            return false;
        }
        return true;
    }

    const renderHeader1 = () => {
        return (
            <div className="flex justify-content-end">
                <span className="p-input-icon-left" style={{ marginLeft: '10px' }}>
                    <i className="pi pi-search" />
                    <InputText value={globalFilterValue1} onChange={onGlobalFilterChange1} placeholder="Search" />
                </span>
                <div>
                    <Button type="button"
                        icon="pi pi-filter-slash"
                        title="Clear"
                        disabled={(selectedReconId==='' || !AccessType?true:false)}
                        className="p-button-rounded  ml-1 bg-primary"
                        onClick={clearFilter1} />
                    <Button type="button"
                        icon="pi pi-plus"
                        disabled={(selectedReconId==='' || !AccessType?true:false)}
                        title="Add row"
                        className="p-button-rounded  ml-1 bg-primary"
                        onClick={addRow} />
                    <Button icon="pi pi-download"
                        disabled={(selectedReconId==='' || !AccessType?true:false)}
                        onClick={downloadApp1App2Dimensions}
                        className="p-button-rounded  mx-1 bg-primary"
                        title="Download App1 App2 Dimensions" />
                </div>
            </div>
        )
    }

    const header1 = renderHeader1();

    const actionBodyTemplate = () => {
        return (
            <React.Fragment>
                <Button icon="pi pi-trash" disabled={!AccessType}
                    className="p-button-rounded mx-1 bg-primary" tooltip="delete"
                    tooltipOptions={{ "position": "top" }}
                    // onClick={(e) => deleteDimension(rowData.recon_id, e)}
                    />
            </React.Fragment>
        );
    }
    return (
        <>
            <DataTable value={apidata}
                id="dimensionTable"
                editMode="row"
                dataKey="order"
                headerColumnGroup={headerGroup}
                rowClassName={rowClass}
                onRowReorder={onRowReorder}
                onRowAdd={addRow}
                rowEditValidator={onRowEditValidator}
                editingRows={editingRows}
                onRowEditChange={onRowEditChange}
                onRowEditComplete={onRowEditComplete}
                reorderableRows
                showGridlines
                sortMode="multiple"
                scrollDirection="both"
                scrollable
                removableSort
                filters={filters1}
                filterDisplay="menu"
                globalFilterFields={['app1_dimension', 'app1_dim_in_file', 'app1_type_field', 'app1_top_member', 'app2_dimension', 'app2_dim_in_file', 'app2_top_member']}
                header={header1}
                paginator
                paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
                currentPageReportTemplate="Showing {first} to {last} of {totalRecords}"
                rows={30}
                scrollHeight="600px"
                rowsPerPageOptions={[30, 40, 50]}>
                <Column rowReorder style={{ width: '3.1%' }} />
                <Column style={{ width: '10.50%' }} field="app1_dimension" 
                        sortable filter hidden={false}
                        editor={(options) => textEditor(options)} ></Column>
                <Column style={{ width: '10.5%' }} field="app1_dim_in_file"
                        sortable filter 
                        editor={(options) => appDimInFileEditor(options)}></Column>
                <Column style={{ width: '10.5%' }} field="app1_type_field" 
                        sortable editor={(options) => numberEditor(options)} filter></Column>
                <Column style={{ width: '10.53%' }} body={app1topMemberTemplate} 
                        field="app1_top_member" sortable  filter 
                        editor={(options) => textEditor(options)}></Column>
                <Column style={{ width: '10.4%' }} field="app2_dimension" sortable 
                        editor={(options) => textEditor(options)} filter></Column>
                <Column style={{ width: '10.5%' }} field="app2_dim_in_file" sortable 
                        editor={(options) => appDimInFileEditor(options)} filter></Column>
                <Column style={{ width: '10.5%' }} field="app2_type_field" sortable 
                        editor={(options) => numberEditor(options)} filter></Column>
                <Column style={{ width: '10.55%' }} body={app2topMemberTemplate} 
                        field="app2_top_member" sortable  filter
                        editor={(options) => textEditor(options)}></Column>
                <Column style={{ width: '6%' }} body={isActiveTemplate} editor={(options) => statusEditor(options)} field="app1_is_active" ></Column>
                <Column style={{ width: '7%', cursor: AccessType === false ? 'default' : 'pointer' }}
                    rowEditor
                    headerStyle={{ width: '10%', minWidth: '8rem' }}
                    bodyStyle={{ textAlign: 'center' }}></Column>
                {/* <Column style={{ width: '7%', cursor: AccessType === false ? 'default' : 'pointer'}}
                    headerStyle={{width: '10%', minWidth:'8rem'}}
                    bodyStyle={{textAlign: 'center'}}
                    align="center" field="name" body={actionBodyTemplate} header="Action" ></Column> */}
            </DataTable>
        </>
    );
}
export default Dimensions;