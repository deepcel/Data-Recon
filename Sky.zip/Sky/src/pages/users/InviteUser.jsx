import React, { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { inviteUser } from '../../store/sliceReducers/UserReducer';
import { getToken } from '../../utils/utils';
import { useFormik } from 'formik';
import { InputText } from 'primereact/inputtext';
import { Dropdown } from 'primereact/dropdown';
import { classNames } from 'primereact/utils';
import { Button } from 'primereact/button';
import "../users/userList.scss";
import { Dialog } from 'primereact/dialog';
import OneStreamConfig from '../dashboard/steps/direct connect/OneStreamConfig';
export const InviteUser = () => {
  // redux state variables
  const dispatch = useDispatch();

  const [errMessage, setErrorMessage] = useState("");
  const [visible, setVisible] = useState(false);
  // Logged in user email
  const [loggedInUser, setLoggedInUser] = useState('');

  const Role = [
    { name: 'Admin', code: 'adm' },
    { name: 'User', code: 'use' },
  ];
  const [selectedrole, setSelectedrole] = useState('')

  const accesstype = [
    { name: 'Write', code: 'wr' },
    { name: 'Read', code: 'rd' },
  ];
  const [selectedaccess, setSelectedaccess] = useState('')
  const hideLoginScreen = () => {
    setVisible(!visible);
};
  useEffect(() => {
    let userObj = getToken('objUser');
    setLoggedInUser(userObj.email);
  }, []);

  const inviteForm = useFormik({
    initialValues: {
      email: '',
      role: '',
      accessType: ''
    },
    validate: (data) => {
      let errors = {};

      if (!data.email) {

        errors.email = 'Email is required.';
      }
      else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(data.email)) {
        errors.email = 'Invalid email address. E.g. example@email.com';
      }
      if (!data.role) {
        errors.role = 'select role'
      }
      if (!data.accessType) {
        errors.accessType = 'select access type'
      }
      return errors;
    },

    onSubmit: (data) => {
      let privilege = (selectedaccess.name) === 'Write' ? 0 : 1;
      let payload = {
        'email': data.email,
        'role': selectedrole.name,
        'access_type': { "privilege": privilege }
      }
      dispatch(inviteUser(payload));
      setSelectedrole();
      setSelectedaccess()
      data.email = "";
      setErrorMessage("");
    },
  });

  const isFormFieldValid = (name) => !!(inviteForm.touched[name] && inviteForm.errors[name]);
  const getFormErrorMessage = (name) => {

    //  setErrorMessage((isFormFieldValid(name) && <small className="p-error">{inviteForm.errors[name]}</small>))
    return isFormFieldValid(name) && <small className="p-error block">{inviteForm.errors[name]}</small>;
  };
  const removeErrorMessage = () => {
    if (errMessage && errMessage.length > 0) {
      setErrorMessage("");
    }

  }


  return (

    <form onSubmit={inviteForm.handleSubmit} style={{ display: 'flex' }} className="formgroup-inline">

      <div className="field">
        <span className="p-float-label p-input-icon-right">
          <i className="pi pi-envelope" />
          <InputText id="email"
            name="email"
            style={{ width: '300px' }}
            value={inviteForm.values.email}
            onChange={(e) => { removeErrorMessage(); inviteForm.handleChange(e); }}
            className={classNames({ 'p-invalid': isFormFieldValid('email') })} />
          <small className="p-error block">{getFormErrorMessage('email')}</small>
          <label htmlFor="email"
            className={classNames({ 'p-error': isFormFieldValid('email') })}>
            Email*
          </label>
        </span>
      </div>

      <div className="field">
        <span className="p-float-label">
          <Dropdown optionLabel="name"
            name="role"
            inputId="tabledropdown"
            style={{ width: '150px' }}
            value={selectedrole}
            options={Role}
            className={classNames({ 'p-invalid': isFormFieldValid('role') })}
            onChange={(e) => { setSelectedrole(e.value); removeErrorMessage(); inviteForm.handleChange(e); }}
            placeholder={selectedrole} />
          <small className="p-error block">{getFormErrorMessage('role')}</small>
          <label htmlFor="tabledropdown">Select role</label>
        </span>
      </div>
      <div className="field">
        <span className="p-float-label">
          <Dropdown optionLabel="name"
            name="accessType"
            inputId="tabledropdown1"
            style={{ width: '175px' }}
            value={selectedaccess}
            options={accesstype}
            onChange={(e) => {setSelectedaccess(e.value); removeErrorMessage(); inviteForm.handleChange(e); }}
            className={classNames({ 'p-invalid': isFormFieldValid('accessType') })}
            placeholder={selectedaccess} />
          <small className="p-error block">{getFormErrorMessage('accessType')}</small>
          <label htmlFor="tabledropdown1">Select access type</label>
        </span>
      </div>

      <div className="field">
        <Button type="submit" label="Send invite" className="bg-primary px-6" />
      </div>
      <div className="field">
        {/* <Button type="button" label="Configure OneStream" className="bg-primary"
        onClick={()=>{setVisible(!visible)}} /> */}
      </div>
      <Dialog visible={visible}
              header="OneStream Configuration"
              className="center-header"
              style={{ width: '29vw' }} 
              onHide={hideLoginScreen}>
                    <OneStreamConfig/>
      </Dialog> 
    </form>
  )
}
