import csv
from ... models import ReconDimensions, ReconApplications
from ..serializers import ReconApplicationSerializer


'''
<!---------- Method to get the imported bridge file data
             and return as structured data ----------!>
'''


def get_import_data(recon_id, app_type, file_path):
    header_instance = ReconApplications.objects.filter(recon_id=recon_id, app_name=app_type)

    header_stat = ReconApplicationSerializer(header_instance, many=True)

    # Creating the data object
    data_object = {
        'status': 200,
        'recon_id': recon_id,
        'app_type': app_type,
        'rows': []
    }

    # Reding the imported file
    with open(file_path, newline='', encoding="utf-8-sig") as Bridge_File:
        if header_stat.data[0]['has_header']:
            next(Bridge_File)
        reader = csv.reader(Bridge_File)

        # Looping through the file data
        for index, row in enumerate(reader):
            number_of_col = len(row)

            # Checking if all columns are there
            if number_of_col < 4:
                response_data = {
                    'status': 6002,
                    'message': 'Missing required columns in file!'
                }
                return response_data
            else:
                dim_id = get_dim_id(recon_id, row[0], app_type)
                # 'dim_id': dim_id if dim_id != 'None' else row[0],
                row_object = {
                    'dim_id': dim_id if dim_id != 'None' else None,
                    'source_member': row[1],
                    'flip_sign': row[2],
                    'bridge_member': row[3],
                    'is_invalid': False if dim_id != 'None' else True
                }
                data_object['rows'].append(row_object)

    return data_object


def get_dim_id(recon_id, dim_name, app_type):
    dimension_id = 'None'
    if ReconDimensions.objects.filter(recon_id=recon_id, dimension=dim_name.upper(), app_type=app_type).exists():
        dim_instance = ReconDimensions.objects.filter(recon_id=recon_id, dimension=dim_name.upper(), app_type=app_type)[0]
        dimension_id = dim_instance.dimensions_id

    return dimension_id


def get_bridge_dim_id(recon_id, dim_name):
    dimension_id = []
    if ReconDimensions.objects.filter(recon_id=recon_id, dimension=dim_name, app_type='0').exists():
        dim_instance = ReconDimensions.objects.filter(recon_id=recon_id, dimension=dim_name, app_type='0')[0]
        dimension_id.append(dim_instance.dimensions_id)
    if ReconDimensions.objects.filter(recon_id=recon_id, dimension=dim_name, app_type='1').exists():
        dim_instance = ReconDimensions.objects.filter(recon_id=recon_id, dimension=dim_name, app_type='1')[0]
        dimension_id.append(dim_instance.dimensions_id)

    return dimension_id
