import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { FilterMatchMode, FilterOperator } from 'primereact/api';
import { Button } from "primereact/button";
import { InputText } from 'primereact/inputtext';
import { Dropdown } from 'primereact/dropdown';
import { Dialog } from 'primereact/dialog';
import { confirmPopup, ConfirmPopup } from 'primereact/confirmpopup';
import "./transformation.scss";
import {
    downloadTransformSyncMap, addRowApp2Sync, UPDATE_APP2SYNC,
    updateTransformationSync, deleteTransformSync
} from "../../../../store/sliceReducers/TransformationReducer";


const App2Sync = () => {
    const dispatch = useDispatch();
    const [editingRows, setEditingRows] = useState({});
    const [globalFilterValue3, setGlobalFilterValue3] = useState('');
    const [filters3, setFilters3] = useState(null);
    const [app2SourceSyncDropdown, setApp2SourceSyncDropdown] = useState([]);
    const [selectedapp2flipsign, setSelectedapp2flipsign] = useState(null);
    const [selectedsyncapp2, setSelectedSyncapp2] = useState([]);
    const [selectedProductsapp2, setSelectedProductsapp2] = useState(null);
    const [deleteProductsDialogapp2, setDeleteProductsDialogapp2] = useState(false);
    const [transformationSyncApp2Dialog, setTransformationSyncApp2Dialog] = useState(false);

    const emptyTransformationSync = {
        app2dimension: '',
        app2sourcesync: '',
        app2flipsign: '',
        app2targetsync: ''
    };
    const [transformationSync, setTransformationSync] = useState(emptyTransformationSync);
    const authData = useSelector((state) => state.auth);
    const { data } = authData.data;
    const AccessType = data.access_type.privilege === 0 ? true : false;

    const flipSyncdropdown = [
        { label: 'YES', value: 'YES' },
        { label: 'NO', value: 'NO' }
    ];

    // get selected recon_id from redux state
    const selectedReconId = useSelector(state =>
        state.reconRun.selectedReconRunId
    );

    // get stransformation data from redux state 
    const transformation = useSelector(state =>
        state.transform.transformation
    );

    // set values of transformation received for app2Sync table

    useEffect(() => {
        setSelectedSyncapp2(transformation.app2Sync);
    }, [transformation, transformation.rows]);  // dependency array to re render this component 



    // function to return dimension name by comparing dimension Id
    const getDimensionData = (dimensionList, dimId) => {
        if (!!dimId) {
            const index = dimensionList.findIndex(dim => String(dim.dimensions_id) === String(dimId));
            if (index === -1) {
                return dimId;
            }
            else {
                return dimensionList[index]?.dimension;
            }
        }
        else {
            return "--";
        }
    }
    // download app2Sync file
    const downloadApp2SyncMap = () => {
        dispatch(downloadTransformSyncMap(
            {
                "recon_id": selectedReconId,
                "app_type": "1"
            }));
    }

    const deleteSelectedProductsapp2 = () => {
        let productsapp2 = selectedsyncapp2.filter(val2 => selectedProductsapp2.includes(val2));
        setSelectedSyncapp2(productsapp2);
        setDeleteProductsDialogapp2(false);
        let rows = [];
        for (let i = 0; i < productsapp2.length; i++) {
            rows.push(productsapp2[i].sync_id);
        }
        dispatch(deleteTransformSync(
            {
                "recon_id": selectedReconId,
                "sync_id": rows,
                "appType": 0
            }));
        selectedProductsapp2.length = 0;
    }
    const deleteProductsDialogFooterapp2 = () => {
        return (
            <React.Fragment>
                <Button label="No" icon="pi pi-times" className="p-button-text" onClick={hideDeleteProductsDialogapp2} />
                <Button label="Yes" icon="pi pi-check" className="p-button-text"
                    onClick={deleteSelectedProductsapp2} />
            </React.Fragment>
        )
    };

    const onApp2FlipSignChange = (e) => {
        setSelectedapp2flipsign(e.value);
    }

    const hideDialog2 = () => {
        // setSubmitted(false);
        setTransformationSyncApp2Dialog(false);
    }

    // const transformSyncRowEditValidator = (rowData) => {
    //     if (!rowData['dimensions_id']) {
    //         toast.error("Please select the dimension");
    //         return false;
    //     }
    //     else if (!rowData['source_sync']) {
    //         toast.error("Please fill the source member");
    //         return false;
    //     }
    //     else if (!rowData['flip_sign']) {
    //         toast.error("Please fill the flip sign");
    //         return false;
    //     }
    //     else if (!rowData['target_sync']) {
    //         toast.error("Please fill the target sync");
    //         return false;
    //     }
    //     return true;
    // }


    const transformSyncRowEditValidator = (rowData) => {
        if (!rowData['dimensions_id']) {
            toast.error("Please select the dimension");
            return false;
        }
        else if (!rowData['source_sync']) {
            toast.error("Please fill the source member");
            return false;
        }
        else if (!rowData['flip_sign']) {
            toast.error("Please fill the flip sign");
            return false;
        }
        else if (!rowData['target_sync']) {
            toast.error("Please fill the target sync");
            return false;
        }
        else if (rowData['source_sync'].toUpperCase() === 'YEAR' && !Number.isInteger(rowData['target_sync'])) {
            toast.error("Target sync should be an integer for YEAR source sync");
            return false;
        }
        else if (rowData['source_sync'].toUpperCase() !== 'YEAR' && typeof rowData['target_sync'] !== 'string') {
            toast.error("Target sync should be a string for non-YEAR source sync");
            return false;
        }
        return true;
    }

    // const addRow = () => {
    //     dispatch(addRowApp2Sync(emptyTransformationSync))
    // };

    const addRow = () => {
        // Create a new empty row object
        const newRow = {
            dimensions_id: "",
            source_sync: "",
            flip_sign: "",
            target_sync: "",
        };

        // Add the new row to the state with the added data
        dispatch(addRowApp2Sync(newRow));

        // Get the index of the new row
        const rowIndex = transformation.app2Sync.length - 1;

        // try {
        //     // Call the update API with the new row
        //     dispatch(
        //         updateTransformationSync({
        //             recon_id: selectedReconId,
        //             app_type: "0",
        //             rows: [newRow],
        //         })
        //     );
        // } catch (error) {
        //     toast.info("Empty Row is added Please enter values to the row" + error);
        // }
    };

    const App2TransformSyncRowEditComplete = (e, rowIndex) => {
        const { newData } = e;

        // Update the row in the state
        dispatch(UPDATE_APP2SYNC(newData, rowIndex));

        // Call the update API with the updated row
        dispatch(
            updateTransformationSync({
                recon_id: selectedReconId,
                app_type: "1",
                rows: [newData],
            })
        );
    };

    const openNewApp2 = () => {
        setTransformationSync(emptyTransformationSync)
        setTransformationSyncApp2Dialog(false);
        addRow();
    }
    // function to set selected row to edit
    const onRowEditChange = (e) => {

        if (AccessType === true) {
            setEditingRows(e.data)
        }
        else {
            return
        }
    }

    // Function to call api to update edited values for specific row

    // const App2TransformSyncRowEditComplete = (e) => {
    //     let { newData } = e;
    //     dispatch(updateTransformationSync(
    //         {
    //             recon_id: selectedReconId,
    //             app_type: "1",
    //             rows: [{
    //                 // tfn_id: newData.tfn_id,
    //                 dimensions_id: newData.dimensions_id,
    //                 source_sync: newData.source_sync,
    //                 flip_sign: newData.flip_sign,
    //                 target_sync: newData.target_sync
    //             }]
    //         }));
    // }

    const textEditor = (options) => {
        return <InputText type="text" value={options.value} onChange={(e) => options.editorCallback(e.target.value)} className="w-full" />;
    }

    const app2DimensionNameTemplate = (rowData) => {
        return (
            getDimensionData(transformation.combinations.app2Dimension, rowData.dimensions_id)
        );
    }

    const app2TransformSyncDelete = (rowData) => {
        return (
            <React.Fragment>
                <Button icon="pi pi-trash" disabled={!AccessType}
                    className="p-button-rounded mx-1 bg-primary"
                    onClick={(e) => deleteTransformationSync(rowData.sync_id, e, "1")}
                />
            </React.Fragment>
        );
    }

    const deleteTransformationSync = (sync_id, event, appType) => {
        confirmPopup({
            target: event.currentTarget,
            message: 'Do you want to delete this record?',
            icon: 'pi pi-info-circle',
            acceptClassName: 'p-button-danger',
            accept: () => {
                dispatch(deleteTransformSync(
                    {
                        "recon_id": selectedReconId,
                        "sync_id": [sync_id]
                    }, appType));
            },
            reject: () => {
            }
        });
    }
    const app2FlipsignTemplate = (rowData) => {
        return rowData.flip_sign === "YES" ? "YES" : "NO"
    }

    const app2FlipSign = (options) => {
        return (
            <Dropdown value={options.value} options={flipSyncdropdown} optionLabel="label" optionValue="value"
                onChange={(e) => { options.editorCallback(e.value); }} placeholder="select" />
        );
    }

    const confirmDeleteSelectedapp2 = () => {
        setDeleteProductsDialogapp2(true);
    }

    const hideDeleteProductsDialogapp2 = () => {
        setDeleteProductsDialogapp2(false);
    }

    const onGlobalFilterChange3 = (e) => {
        const value = e.target.value;
        let _filters3 = { ...filters3 };
        _filters3['global'].value = value;

        setFilters3(_filters3);
        setGlobalFilterValue3(value);
    }
    const initFilters3 = () => {
        setFilters3({
            'global': { value: null, matchMode: FilterMatchMode.CONTAINS },
            'dimensions_id': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'source_sync': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'flip_sign': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'target_sync': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
        });
        setGlobalFilterValue3('');
    }

    const clearFilter3 = () => {
        initFilters3();
    }

    const renderHeader3 = () => {
        return (
            <div className="flex justify-content-between">
                <span className="p-input-icon-left">
                    <i className="pi pi-search" />
                    <InputText value={globalFilterValue3} onChange={onGlobalFilterChange3} placeholder="Search" />
                </span>
                <div>
                    <Button type="button"
                        icon="pi pi-filter-slash"
                        title="Clear"
                        className="p-button-rounded  mx-1 bg-primary" onClick={clearFilter3} />
                    <Button icon="pi pi-download"
                        disabled={!AccessType}
                        onClick={downloadApp2SyncMap}
                        className="p-button-rounded  mx-1 bg-primary"
                        title="Download App2 Sync Mapping" />
                    <Button icon="pi pi-plus" disabled={!AccessType}
                        className="p-button-rounded  ml-1 bg-primary"
                        title="Add Transformation Sync"
                        onClick={openNewApp2} />
                    <Button title="Bulk Delete"
                        icon="pi pi-trash"
                        className="p-button-rounded  mx-1 bg-primary"
                        onClick={confirmDeleteSelectedapp2}
                        disabled={!selectedProductsapp2 || !selectedProductsapp2.length || !AccessType} />

                </div>

            </div>
        )
    }

    // sync dimension editor, source sync update
    const app2SourceSyncDropdownUpdate = (dimId) => {
        const rowIndex = transformation.combinations.app2Data.findIndex(t => t.dimensions_id === dimId);
        if (rowIndex !== -1) {
            setApp2SourceSyncDropdown(transformation.combinations.app2Data[rowIndex]?.source_sync);
        }
    }

    const app2CombinationDropdownEditor = (options) => {
        return (
            <Dropdown value={options.value}
                options={transformation.combinations.app2SourceSync}
                onChange={(e) => { options.editorCallback(e.value) }}
                placeholder="select" className="w-full" filter showClear filterBy="source_sync" />
        )
    }

    const app2DropdownEditor = (options) => {
        return (
            <Dropdown value={options.value}
                options={transformation.combinations.app2Dimension}
                optionLabel="dimension" optionValue="dimensions_id"
                onChange={(e) => { options.editorCallback(e.value); app2SourceSyncDropdownUpdate(e.value) }}
                placeholder="select" className="w-full" filter showClear filterBy="dimension" />
        )
    }
    const header3 = renderHeader3();
    const transformationDialogFooter2 = (
        <React.Fragment>
            <Button label="Cancel" icon="pi pi-times" className="p-button-text"
                onClick={hideDialog2} />
            <Button label="Save" icon="pi pi-check" className="p-button-text"
            // onClick={saveProduct} 
            />
        </React.Fragment>
    );
    return (
        <>
            <ConfirmPopup />
            <DataTable id="app2SyncTable"
                className=""
                //  rowClassName={rowClass}
                value={transformation.app2Sync}
                editingRows={editingRows}
                onRowEditChange={onRowEditChange}
                rowEditValidator={transformSyncRowEditValidator}
                onRowEditComplete={App2TransformSyncRowEditComplete}
                editMode="row"
                dataKey="sync_id"
                showGridlines
                scrollHeight="400px"
                sortMode="multiple"
                scrollable
                removableSort
                filterDisplay="menu"
                globalFilterFields={['dimensions_id', 'source_sync', 'flip_sign', 'target_sync']}
                header={header3}
                filters={filters3}
                scrollDirection="both"
                paginator
                paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
                currentPageReportTemplate="Showing {first} to {last} of {totalRecords}"
                rows={10}
                rowsPerPageOptions={[10, 20, 50]}
                selection={selectedProductsapp2} onSelectionChange={(e) => setSelectedProductsapp2(e.value)}>
                {AccessType && <Column selectionMode="multiple"></Column>}
                <Column style={{ width: '20%' }} field="dimensions_id" header={<span className="transformationsync">Dimension</span>} sortable filter body={app2DimensionNameTemplate} editor={(options) => app2DropdownEditor(options)}></Column>
                <Column style={{ width: '23%' }} field="source_sync" header={<span className="transformationsync">Source Sync</span>} sortable filter editor={(options) => app2CombinationDropdownEditor(options)}></Column>
                <Column style={{ width: '20%' }} field="flip_sign" header={<span className="transformationsync">Flip Sign</span>} body={app2FlipsignTemplate} sortable filter
                    // editor={(options) => textEditor(options)} 
                    editor={(options) => app2FlipSign(options)}
                ></Column>
                <Column style={{ width: '18%' }} field="target_sync" header={<span className="transformationsync">Target Sync</span>} sortable filter editor={(options) => textEditor(options)}></Column>
                <Column style={{ width: '13%' }} rowEditor header="Edit"></Column>
                <Column style={{ width: '12%' }} align="center" body={app2TransformSyncDelete} header="Action"></Column>
            </DataTable>

            <Dialog visible={deleteProductsDialogapp2} style={{ width: '460px' }} header="Confirm" modal
                footer={deleteProductsDialogFooterapp2} onHide={hideDeleteProductsDialogapp2}>
                <div className="confirmation-content">
                    <i className="pi pi-exclamation-triangle mr-3" style={{ fontSize: '2rem' }} />
                    {selectedsyncapp2 && <span>Are you sure you want to delete the selected transformation syncs?</span>}
                </div>
            </Dialog>
        </>
    )
}
export default App2Sync;