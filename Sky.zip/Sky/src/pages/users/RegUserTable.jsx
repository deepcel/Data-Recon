import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { deleteUser, getUserlist, updateUser } from '../../store/sliceReducers/UserReducer';
import { getToken } from '../../utils/utils';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Badge } from 'primereact/badge';
import { Dropdown } from 'primereact/dropdown';
import { getEmail } from '../../utils/utils';
import { ConfirmPopup, confirmPopup } from 'primereact/confirmpopup';
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import { FilterMatchMode, FilterOperator } from 'primereact/api';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';
import "../users/userList.scss";
export const RegUserTable = (props) => {
  const dispatch = useDispatch();
  const { data } = useSelector((state) => state.user);
  const [editingRows, setEditingRows] = useState({});
  const [globalFilterValue, setGlobalFilterValue] = useState('');
  const [filters, setFilters] = useState(null);
  const [loggedInUser, setLoggedInUser] = useState('');
  const email = getEmail();
  //  Select table (invited or registered)
  const tableNames = [
    { name: 'Registered users', code: 'reg' },
    { name: 'Invited Users', code: 'inv' },
  ];
  // const email = getEmail();
  const [selectedtable, setSelectedTable] = useState('Registered users')
 
  // function for setting option to select table 
  const selectedtableHandler = (e) => {
    setSelectedTable(e.value);
    props.selectedtableHandler(e.value.name);
  }

  useEffect(() => {
    let userObj = getToken('objUser');
    setLoggedInUser(userObj.email);
    dispatch(getUserlist("general/user/list"))
    initFilters();
   // assignPrivilege();
  }, []);

  // consume response from call get userlist API based on selected option
  const usersList = data.data;
  let updatedList=usersList.map(
    (item)=> (
    {
      ...item, privilege:(item.access_type.privilege?'Read':'Write')
    }
    ))    
  // OnEdit values for status of registered user
  const regUserStatus = [
    { label: 'Active', value: true },
    { label: 'Inactive', value: false },
  ];
  // OnEdit values for role of registered user
  const regUserRole = [
    { label: 'Admin', value: "Admin" },
    { label: 'User', value: "User" },
  ];
  // OnEdit values for access type of registered user  
  const regUserAccess = [
    { label: 'Write', value: { privilege: 0 } },
    { label: 'Read', value: { privilege: 1 } },
  ];
  //its called on clicking clear filters to set default table
  const initFilters = () => {
    setFilters({
      'global': { value: null, matchMode: FilterMatchMode.CONTAINS },
      'first_name': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'email': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'status': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'role': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'privilege': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
    });
    setGlobalFilterValue('');
  }

  const clearFilter = () => {
    initFilters();
  }

  const onGlobalFilterChange = (e) => {
   
    const value = e.target.value;
    let _filters = { ...filters };
    _filters['global'].value = value;
    setFilters(_filters);
    setGlobalFilterValue(value);
  }

  // On edit select role in registered user table
  const roleEditor = (options) => {
    return (
      <Dropdown value={options.value}
        options={regUserRole}
        optionLabel="label"
        optionValue="value"
        onChange={(e) => { options.editorCallback(e.value) }}
        placeholder="select" />
    );
  }
  // On edit select access type in registered user table
  const accessEditor = (options) => {
    return (
      <Dropdown value={options.value}
        options={regUserAccess}
        optionLabel="label"
        optionValue="value"
        onChange={(e) => { options.editorCallback(e.value) }}
        placeholder="select" />
    );
  }

  //On edit select status in registered user table
  const statusRegEditor = (options) => {
    return (
      <Dropdown value={options.value}
        options={regUserStatus}
        optionLabel="label"
        optionValue="value"
        onChange={(e) => { options.editorCallback(e.value) }}
        placeholder="select" />
    );
  }

  const statusregTemplate = (rowData) => {
    return <Badge value={rowData.is_active === true ? 'Active' : 'Inactive'} severity={`${(rowData.is_active === true ? "success" : "info")}`} className="mr-2"></Badge>;
  }

  const roleTemplate = (rowData) => {
    return rowData.role;
  }

 
  const actionBodyTemplate = (rowData) => {
    return (
      <React.Fragment>
        <Button icon="pi pi-trash" className="p-button-rounded p-button-warning mx-1 bg-primary"
          tooltip="delete" tooltipOptions={{ "position": "top" }}
          onClick={(e) => deleteuserRecord(rowData.email, e)}
        />
      </React.Fragment>
    );
  }
  const deleteuserRecord = (email, event) => {
    confirmPopup({
      target: event.currentTarget,
      message: 'Do you want to delete this user?',
      icon: 'pi pi-info-circle',
      acceptClassName: 'p-button-danger',
      accept: () => {
        dispatch(deleteUser(
          {
            "email": email
          }));
      },
      reject: () => {
      }
    });
  }

  const onRowEditChange = (e) => {
    setEditingRows(e.data);
  }
  // call update detail api call using reducer
  const onRowEditComplete = (e) => {
    let { newData } = e;
    dispatch(updateUser(newData));
  }

  // Function returns table header and search field
  const renderHeader1 = () => {
    return (
      <div className="flex justify-content-between"
           style={{display:'inlineFlex'}}>
        
        <span style={{margin:'10px', marginTop:'20px'}}>Registered Users Details</span>
       
        <div style={{margin:'10px'}}>

          <span className="field p-float-label"
                style={{ marginLeft: '10px',float:'left'}}>
                    <Dropdown optionLabel="name"
                              inputId="tabledropdown"
                              style={{ width: '200px' }}
                              value={selectedtable}
                              options={tableNames}
                              onChange={(e) => selectedtableHandler(e)}
                              placeholder={selectedtable} />
                <label htmlFor="tabledropdown">Select Users</label>
          </span>
          
          <span className="p-input-icon-left"
                style={{ marginLeft: '10px' }}>
            <i className="pi pi-search" />
            <InputText value={globalFilterValue} onChange={onGlobalFilterChange} placeholder="Search" />
          </span>     
          <Button type="button" icon="pi pi-filter-slash" 
                  title="Clear" className="p-button-rounded  ml-2 bg-primary"
                  onClick={clearFilter} />
    
        </div>
      </div>
    )
  }

  const header1 = renderHeader1();
  const rowClassName = rowData => {
    if (rowData.email === email) {
      return 'p-disabled';
    }
    return null;
  };
  return (
    <div style={{ fontFamily: "'Open Sans', sans-serif" }}>
      <ConfirmPopup />
      <DataTable value={updatedList}
                 id="userTable"
                 editMode="row"
                 dataKey="email"
        // rowEditValidator={onRowEditValidator}
        rowClassName={rowClassName}
        editingRows={editingRows}
        onRowEditChange={onRowEditChange}
        onRowEditComplete={onRowEditComplete}
        // rowClassName={rowClassName}
        showGridlines
        sortMode="multiple"
        scrollable
        className="mt-6"
        removableSort
        scrollHeight="420px"
        scrollDirection="both"
        paginator
        filterDisplay="menu"
        globalFilterFields={['first_name', 'email', 'is_active', 'role', 'privilege']}
        header={header1}
        paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
        currentPageReportTemplate="Showing {first} to {last} of {totalRecords}"
        rows={5}
        filters={filters}
        responsiveLayout="scroll"
        rowsPerPageOptions={[5, 10, 20, 50]}
        emptyMessage="No data found.">
        <Column style={{ width: '22%' }} field="first_name" header="Firstname" sortable filter ></Column>
        <Column style={{ width: '30%' }} field="email" header="Email" sortable filter ></Column>
        <Column style={{ width: '10%' }}
          field="role"
          align="center" header="Role"
          sortable filter body={roleTemplate}
          editor={(options) => roleEditor(options)} ></Column>
        <Column style={{ width: '10%' }}
          field="privilege"
          align="center"
          header="Access Type"
          editor={(options) => accessEditor(options)} sortable 
        //  body={accessTypeTemplate}
           filter></Column>
        <Column style={{ width: '10%' }}
          body={statusregTemplate} align="center"
          field="is_active"
          editor={(options) => statusRegEditor(options)} header="Status" sortable filter >
        </Column>
        <Column style={{ width: '7%' }} align="left" rowEditor header="Edit" required></Column>
        <Column style={{ width: '10%' }} align="left" body={actionBodyTemplate} header="Action" ></Column>
      </DataTable>
    </div>
  )
}

