import { createSlice } from "@reduxjs/toolkit";
import { toast } from "react-toastify";
import {
  makeGetAPICall,
  makePostAPICall,
  makePutAPICall,
  makePutAPIFormData,
  makePostAPICallFileDownload,
  makeDeleteBodyParamAPICall,
  makeGetAPICallFileDownload,
} from "../../utils/apiService";
import { redirectToLogin } from "../../utils/utils";
import { enableLoader, hideLoader } from "./LoadReducer";

// Dashboard reducer is used for handle all the steps data
export const bridgeMemberReducer = createSlice({
  name: "bridgeMember",
  initialState: {
    loading: false,
    error: null,
    dimensions: {
      app1Dimension: [],
      app2Dimension: [],
      dimensionsimport: [],
    },
    bridgeMembers: {
      app1Rows: [],
      app2Rows: [],
      comments: [],
      jecomments: [],
    },
  },
  reducers: {
    isLoading: (state, action) => {
      state.loading = true;
    },

    INVALID_SESSION: (state) => {
      state.loading = false;
      state.error = null;
    },

    LOAD_BRIDGE_MEMBERS: (state, action) => {
      state.loading = false;
      state.error = null;
      state.bridgeMembers.app1Rows = [...action.payload.response.app1_rows];
      state.bridgeMembers.app2Rows = [...action.payload.response.app2_rows];
    },

    LOAD_COMMENTS: (state, action) => {
      state.loading = false;
      state.error = null;
      state.bridgeMembers.comments = [...action.payload.response.rows];
    },

    LOAD_JE_COMMENTS: (state, action) => {
      state.loading = false;
      state.error = null;
      state.bridgeMembers.jecomments = [...action.payload.response.rows];
    },

    RECON_IMPORT_COMMENTS: (state, action) => {
      state.loading = false;
      state.error = null;
      state.bridgeMembers.comments = [...action.payload.response.rows];
    },

    RECON_IMPORT_JE_COMMENTS: (state, action) => {
      state.loading = false;
      state.error = null;
      state.bridgeMembers.jecomments = [...action.payload.response.rows];
    },

    RECON_IMPORT_BRIDGE_MEMBERS: (state, action) => {
      state.loading = false;
      state.error = null;
      if (action.payload.response.app_type === "0") {
        state.bridgeMembers.app1Rows = [...action.payload.response.rows];
      } else if (action.payload.response.app_type === "1") {
        state.bridgeMembers.app2Rows = [...action.payload.response.rows];
      }
    },

    RECON_LOAD_DIMENSION_MEMBERS: (state, action) => {
      state.loading = false;
      state.error = null;
      state.dimensions.app1Dimension = [
        ...action.payload.response.app_01_dimension,
      ];
      state.dimensions.app2Dimension = [
        ...action.payload.response.app_02_dimension,
      ];
    },

    UPDATE_BRIDGE_MEMBERS: (state, action) => {
      state.loading = false;
      state.error = null;
      if (action.payload.response.app_type === "0") {
        state.bridgeMembers.app1Rows = [...action.payload.response.rows];
      } else if (action.payload.response.app_type === "1") {
        state.bridgeMembers.app2Rows = [...action.payload.response.rows];
      }
    },

    DELETE_INVALID_COMMENTS: (state, action) => {
      state.loading = false;
      state.error = null;
      state.bridgeMembers.comments = state.bridgeMembers.comments.filter(
        (item) => item.bridge_id !== action.payload
      );
    },

    DELETE_INVALID_JE_COMMENTS: (state, action) => {
      state.loading = false;
      state.error = null;
      state.bridgeMembers.jecomments = state.bridgeMembers.jecomments.filter(
        (item) => item.bridge_id !== action.payload
      );
    },

    DELETE_BRIDGE_MEMBER: (state, action) => {
      state.loading = false;
      state.error = null;
      if (action.payload.response.appType === "0") {
        state.bridgeMembers.app1Rows = state.bridgeMembers.app1Rows.filter(
          (item) => item.bridge_id !== action.payload.response.bridgeId
        );
      } else if (action.payload.response.appType === "1") {
        state.bridgeMembers.app2Rows = state.bridgeMembers.app2Rows.filter(
          (item) => item.bridge_id !== action.payload.response.bridgeId
        );
      }
    },
  },
});

export const {
  isLoading,
  INVALID_SESSION,
  LOAD_BRIDGE_MEMBERS,
  LOAD_COMMENTS,
  LOAD_JE_COMMENTS,
  RECON_LOAD_DIMENSION_MEMBERS,
  RECON_IMPORT_BRIDGE_MEMBERS,
  RECON_IMPORT_COMMENTS,
  RECON_IMPORT_JE_COMMENTS,
  UPDATE_BRIDGE_MEMBERS,
  DELETE_BRIDGE_MEMBER,
  DELETE_INVALID_JE_COMMENTS,
  DELETE_INVALID_COMMENTS,
} = bridgeMemberReducer.actions;

export const defaultAPIcall = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePostAPICall("bridge/default", payload);
    if (response.status === 200) {      
       toast.success("Source members are defaulted to bridge members");
      dispatch(listBridgeMembers(payload.recon_id));
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const downloadJECommentsFile = (payload) => async (dispatch) => {
  try {
    dispatch(isLoading({ loading: true }));
    const response = await makeGetAPICallFileDownload(
      "bridge/comments/je/export/",
      payload
    );
    if (response.status === 200) {
      toast.success("Download triggered successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const jecommentsImport = (formData) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPIFormData(
      "bridge/comments/je/import",
      formData
    );
    if (response.status === 200) {
      dispatch(
        RECON_IMPORT_JE_COMMENTS({
          response: response,
        })
      );
      toast.success("File imported successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

// Delete jecomments
export const deleteJEComments = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makeDeleteBodyParamAPICall(
      "bridge/comments/je/delete",
      payload
    );
    if (response.status === 200) {
      dispatch(deleteInvalidJEComments(payload.bridge_id));
      toast.success("JE comment is deleted successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const updateJECommentBridge = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPICall("bridge/comments/je/update", payload);
    if (response.status === 200) {
      dispatch(
        LOAD_JE_COMMENTS({
          response: response,
        })
      );
      toast.success("JE comment updated successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const updateCommentBridge = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPICall("bridge/comments/update", payload);
    if (response.status === 200) {
      dispatch(
        LOAD_COMMENTS({
          response: response,
        })
      );
      toast.success("Bridge members updated successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};
export const listComments = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makeGetAPICall("bridge/comments/list/" + payload);
    if (response.status === 200) {
      dispatch(
        LOAD_COMMENTS({
          response: response,
        })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

//Display je comments in bridge member tab
export const listJEComments = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makeGetAPICall("bridge/comments/je/list/" + payload);
    if (response.status === 200) {
      dispatch(
        LOAD_COMMENTS({
          response: response,
        })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const updateBridgeMember = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPICall("bridge/update", payload);
    if (response.status === 200) {
      dispatch(
        UPDATE_BRIDGE_MEMBERS({
          response: response,
        })
      );
      toast.success("Bridge members updated successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const deleteComments = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makeDeleteBodyParamAPICall(
      "bridge/comments/delete",
      payload
    );
    if (response.status === 200) {
      dispatch(deleteInvalidComments(payload.bridge_id));
      toast.success("Comment is deleted successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const downloadCommentsFile = (payload) => async (dispatch) => {
  try {
    dispatch(isLoading({ loading: true }));
    const response = await makeGetAPICallFileDownload(
      "bridge/comments/export/",
      payload
    );
    if (response.status === 200) {
      toast.success("Download triggered successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const listDimension = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makeGetAPICall("bridge/dimension/list/" + payload);
    if (response.status === 200) {
      dispatch(
        RECON_LOAD_DIMENSION_MEMBERS({
          response: response,
        })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const deleteBridgeMember = (payload, appType) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makeDeleteBodyParamAPICall("bridge/delete", payload);
    if (response.status === 200) {
      dispatch(
        DELETE_BRIDGE_MEMBER({
          response: {
            appType: appType,
            bridgeId: payload.bridge_id,
          },
        })
      );

      toast.success("Recon bridge member is deleted successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const deleteInvalidComments = (payload) => async (dispatch) => {
  dispatch(DELETE_INVALID_COMMENTS(payload));
};

export const deleteInvalidJEComments = (payload) => async (dispatch) => {
  dispatch(DELETE_INVALID_JE_COMMENTS(payload));
};
export const listBridgeMembers = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makeGetAPICall("bridge/list/" + payload);
    if (response.status === 200) {
      dispatch(
        LOAD_BRIDGE_MEMBERS({
          response: response,
        })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};
export const downloadBridgeMember = (payload) => async (dispatch) => {
  try {
    dispatch(isLoading({ loading: true }));
    const response = await makePostAPICallFileDownload(
      "bridge/export",
      payload
    );
    if (response.status === 200) {
      // dispatch(RUN_IMPORT_UPDATE({
      //     response: response,
      //     appType: appType
      // }));
      toast.success("Download triggered successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const bridgeMemberImport = (formData, appType) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPIFormData(
      "bridge/import",
      formData,
      appType
    );
    if (response.status === 6002) {
      toast.error(response.message);
    } else if (response.status === 200) {
      dispatch(
        RECON_IMPORT_BRIDGE_MEMBERS({
          response: response,
        })
      );
      toast.success("File imported successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const commentsImport = (formData) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPIFormData(
      "bridge/comments/import",
      formData
    );
    if (response.status === 200) {
      dispatch(
        RECON_IMPORT_COMMENTS({
          response: response,
        })
      );
      toast.success("File imported successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};



export default bridgeMemberReducer.reducer;
