import React,{useState} from "react";
import {
    getDirectConnectSourceData,DCDialogApp2
} from "../../../../store/sliceReducers/DirectConnectReducer";
import { useDispatch, useSelector } from "react-redux";
import "./runImport.scss";
import { Button } from "primereact/button";
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';
import { useFormik } from 'formik';
import { classNames } from 'primereact/utils';
import { InputText } from 'primereact/inputtext';
import { getEmail } from '../../../../utils/utils';
import { Dialog } from 'primereact/dialog';
import DirectConnectTableApp2 from "../direct connect/DirectConnectTableApp2";

const App2Job = () => {
    const dispatch = useDispatch();
    const authData = useSelector((state) => state.auth);
    let { data } = authData.data;
    const AccessType = data.access_type.privilege === 0 ? true : false;
    
    const email = getEmail();

    const selectedReconId = useSelector(state =>
        state.reconRun.selectedReconRunId
    );

    const app2_Import_type=useSelector(state =>
        state.dimField.reconDetails.app2_import_type
    );
    const DC=useSelector(state =>
        state.DirectConnect
      );
    const reconForm2 = useFormik({
        initialValues: {
            app2jobname:''
        },
        validate: (data) => {
            let errorss = {};

            if (!data.app2jobname) {
                errorss.app2jobname = 'app2 job name is required.';
            }
            return errorss;
        },
        onSubmit: (data) => {
            
            
            dispatch(getDirectConnectSourceData({
                "recon_id": selectedReconId,
                "jobname": data.app2jobname,
                "appType": 1,
                "max_rows": 5000,
                "page_number": 1,
                "email": email
            }));
            data.app2jobname='';
            //setviewDCDataApp2(!viewDCDataApp2)
        }
    });

    const isFormFieldValid2 = (name) => !!(reconForm2.touched[name] && reconForm2.errors[name]);
    const getFormErrorMessage2 = (name) => {
        return isFormFieldValid2(name) && <small className="p-error">{reconForm2.errors[name]}</small>;
    };

    return (
        <>
          <p className="mt-0 ml-2">App2 Extract Data:</p>
          <form onSubmit={reconForm2.handleSubmit} className="p-fluid">
             <div className="field p-2">
                <div className="formgrid grid">
                   <div className="col-8">
                      <span className="p-float-label p-input-icon-right">
                         <InputText id="app2jobname"
                                    value={reconForm2.values.app2jobname}
                                    disabled={!AccessType}
                                    onChange={reconForm2.handleChange}
                                    className={classNames({ 'p-invalid': isFormFieldValid2('app2jobname') })} placeholder="App2 Jobname" />
                        <label htmlFor="app2jobname" className={classNames({ 'p-error': isFormFieldValid2('app2jobname') })}>App2 Jobname*</label>
                      </span>
                      {getFormErrorMessage2('app2jobname')}
                   </div>
                   <div className="col-4">
                       <Button type="submit"
                               icon="pi pi-save"
                               disabled={(!AccessType)|| (app2_Import_type==='0')}
                               className="mx-1 bg-primary"
                               tooltipOptions={{ "position": "top" }}
                               tooltip="Save Job Details" />
                            </div>
                </div>
             </div>
           </form>
           <Dialog header="Tag Headers to Dimensions" visible={DC.viewDialogApp2}
                   style={{ width: '95vw' }} 
                   onHide={() => dispatch(DCDialogApp2())} >
              <DirectConnectTableApp2/>
           </Dialog>
       </>
    )
}
export default App2Job;