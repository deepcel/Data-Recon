
import React, { useEffect, useState } from "react";
import { Column } from "primereact/column";
import { Card } from "primereact/card";
import { useDispatch, useSelector } from "react-redux";
import JeReport from "./JeReport";
import ConsolReport from "./ConsolReport";
import InitialReport from "./InitialReport";
import VarianceForm from "./Variance_form";
import { toast } from "react-toastify";
import {
  runReportPost, runReportPostFilter, updateColumns, exportrunreport, archiveRunReport
} from "../../../../store/sliceReducers/RunReportReducer";
import { Button } from "primereact/button";
import { InputText } from 'primereact/inputtext';
import { FilterMatchMode, FilterOperator } from 'primereact/api';
import { MultiSelect } from 'primereact/multiselect';
import ArchiveOutlinedIcon from '@mui/icons-material/ArchiveOutlined';
import IconButton from '@mui/material/IconButton';
import { classNames } from 'primereact/utils';
import 'primeicons/primeicons.css';
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';
import './runReport.scss';

const RunReport = () => {
  const dispatch = useDispatch();
  const [reconRunName, setReconRunName] = useState("");
  const [loading1, setLoading1] = useState(false);
  const [filters1, setFilters1] = useState(null);
  const [globalFilterValue1, setGlobalFilterValue1] = useState('');
  const [selectedColumns, setSelectedColumns] = useState([]);
  const authData = useSelector((state) => state.auth);
  let { data } = authData.data;
  const AccessType = data.access_type.privilege === 0 ? true : false;
  const [errMessage, setErrorMessage] = useState("");
  const reconRunList = useSelector(state =>
    state.reconRun.appData[0]
  );

  const selectedReconId = useSelector(state =>
    state.reconRun.selectedReconRunId
  );

  const runReport = useSelector(state =>
    state.runreport.runReport
  );

  const initVariance = useSelector(state =>
    state.dimField.reconDetails.variance_threshold
  );

  const [variance_Threshold, setvariance_Threshold] = useState(initVariance);

  useEffect(() => {
    //dispatch(updateColumns(runReport.fixedheaders));
    setSelectedColumns(runReport.fixedheaders);
    setvariance_Threshold(initVariance)
  }, [runReport.fixedheaders]);

  // const dynamicColumns = runReport.headers?.map((col, i) => {
  //   return <Column field={col} style={{ "width": "17%" }} header={<div>{col}</div>} sortable filter />;
  // });

  useEffect(() => {
    let filteredRecon = reconRunList.find(run => run.recon_id === selectedReconId)
    if (filteredRecon) {
      setReconRunName(filteredRecon.name)
    }

    if (selectedReconId) {
      // dispatch(updateColumns(runReport.fixedheaders));
      dispatch(runReportPost({
        recon_id: selectedReconId,
        max_rows: 5000,
        page_number: 1,
        colList: runReport.fixedheaders,
        sp_flag: false,
        variance_threshold: initVariance,
      }));
    }
    initFilters1();
  }, [])

  const zipRunReport = () => {
    dispatch(archiveRunReport(selectedReconId))
  }

  const onGlobalFilterChange1 = (e) => {
    const value = e.target.value;
    let _filters1 = { ...filters1 };
    _filters1['global'].value = value;
    setFilters1(_filters1);
    setGlobalFilterValue1(value);
  }

  const initFilters1 = () => {
    setFilters1({
      'global': { value: null, matchMode: FilterMatchMode.CONTAINS },
      'bridgesync-Account-ACCT': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-ENTITY-ENTITY': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-ACCOUNT-ACCOUNT': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-VIEW-VIEW': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Scenario-Scenario': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Census-Dim17': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Customer-U6': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-DataSource-U1': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Dim8-Origin': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Dim12-Function': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Dim13-U4': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Dim16-U7': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Dim18-U8': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Flows-Flow': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Geography-U5': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-ICP-IC': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Segment-U2': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Value-Cons': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-VIEW-VIEW': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Journal Comments': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Comments': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      '2022Jan': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      '2019Jan': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      '2019Feb': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      '2019Mar': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      '2019Apr': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      '2019May': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      '2019Jun': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      '2019Jul': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      '2019Aug': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      '2019Sep': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      '2019Oct': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      '2019Nov': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      '2019Dec': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Grand Absolute Total': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
    });
    setGlobalFilterValue1('');
  }

  const clearFilter1 = () => {
    initFilters1();
  }

  const onLoadingClick1 = () => {
    setLoading1(true);
    dispatch(runReportPost(
      {
        "recon_id": selectedReconId,
        "max_rows": 5000,
        "page_number": 1,
        "colList": "",
        "sp_flag": true,
        "variance_threshold": initVariance,
      }));
    setTimeout(() => {
      setLoading1(false);
    }, 2000);
  }

  const handleChange = (event) => {

    // let orderedSelectedColumns = [];

    if ((event.value).includes('Grand Absolute Total')) {

      // the valid one
      let orderedSelectedColumns = runReport.fixedheaders.filter((headers) => {
        return (event.value).includes(headers)
      });
      // console.log(orderedSelectedColumns)
      //dispatch(updateColumns(orderedSelectedColumns));
      setSelectedColumns(orderedSelectedColumns)

      if (selectedReconId) {
        dispatch(runReportPostFilter({
          recon_id: selectedReconId,
          max_rows: 5000,
          page_number: 1,
          colList: orderedSelectedColumns,
          sp_flag: false,
          variance_threshold: variance_Threshold,
        }));
      }

    }
    else {
      toast.info('Grand Absolute total is a required field')
    }
  }

  const downloadRunReport = () => {
    dispatch(exportrunreport(
      {
        "recon_id": selectedReconId,
        "colList": selectedColumns,
      }));
  }

  const header = (
    <div className="flex justify-content-end">
      <MultiSelect value={selectedColumns}
        options={runReport.fixedheaders}
        onChange={(e) => { handleChange(e) }}
        style={{ width: '17%' }}
        placeholder="Select dimension" />&nbsp;&nbsp;
      <span className="p-input-icon-left">
        <i className="pi pi-search" />
        <InputText value={globalFilterValue1}
          onChange={onGlobalFilterChange1} placeholder="Search" />
      </span>
      <Button type="button"
        icon="pi pi-filter-slash"
        title="Clear"
        disabled={(selectedReconId === '' || !AccessType ? true : false)}
        className="p-button-rounded  ml-1 bg-primary"
        onClick={clearFilter1} />
    </div>
  );

  const columnComponents = selectedColumns?.map(col => {
    return <Column field={col} style={{ "width": "19%" }} header={<div>{col}</div>} sortable filter />;
  });

  const handleThreshold = (value) => {
    setvariance_Threshold(value)
  }

  return (
    <React.Fragment>
      <Card className="shadow-5">
        <div className="card pt-0">
          {!reconRunName && <div className="text-center text-pink-500">
            Please select recon and click run transformation tab
          </div>}
          {
            !!reconRunName && <React.Fragment>
              <div className="field " style={{ marginTop: '-8px' }}>
                Recon RunName: <span className="font-bold">{reconRunName} </span>
              </div>
              <div className="formgrid grid">
                <div className="col-4">
                  <Button label="Refresh Data"
                    icon="pi pi-refresh"
                    className="mt-3 mb-4 bg-primary"
                    // disabled={!AccessType}
                    loading={loading1}
                    onClick={onLoadingClick1} /><br></br>
                </div>
              </div>
              <div className="field p-2 text-right">
                <Button icon="pi pi-download" onClick={downloadRunReport} disabled={!AccessType}
                  className="p-button-rounded  mx-1 bg-primary" title="Download Run Report" />
                <IconButton size="large" disabled={!AccessType}
                  className="p-button-rounded  mx-2 bg-primary" onClick={zipRunReport} title="Archive Run Report">
                  <ArchiveOutlinedIcon />
                </IconButton>
              </div><br></br>
              <VarianceForm loading={loading1}
                selctedColumns={selectedColumns}
                varThreshold={variance_Threshold}
                setvarThreshold={handleThreshold}
              />
              <br></br>
              <div className="formgrid grid">
                <div className="col-12">
                  <h2>Initial Report</h2>
                  {
                    !!runReport &&
                    <InitialReport header={header}
                      filters1={filters1}
                      vt={variance_Threshold}
                      columnComponents={columnComponents} />
                  }
                </div>
              </div><br></br><br></br><br></br>
              <div className="formgrid grid">
                <div className="col-12">
                  <h2>Journal Entry Report</h2>
                  {
                    !!runReport &&
                    <JeReport header={header}
                      filters1={filters1}
                      columnComponents={columnComponents} />
                  }
                </div>
              </div><br></br><br></br><br></br>
              <div className="formgrid grid">
                <div className="col-12">
                  <h2>Consolidated Report</h2>
                  {
                    !!runReport &&
                    <ConsolReport header={header}
                      filters1={filters1}
                      columnComponents={columnComponents} />
                  }
                </div>
              </div>
              <br />
            </React.Fragment>
          }
        </div>
      </Card>
    </React.Fragment>
  )
}

export default RunReport;