import "./select.scss";
import { createReconRun } from "../../../../store/sliceReducers/ReconRunReducer";
import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { useFormik } from 'formik';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { InputTextarea } from 'primereact/inputtextarea';
import { classNames } from 'primereact/utils';
import { initDimension } from './initDimension';
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';
import './createRecon.scss';

const CreateRecon = () => {
    const dispatch = useDispatch();
    const authData = useSelector((state) => state.auth);
    let { data } = authData.data;
    const AccessType = data.access_type.privilege === 0 ? true : false;
    const reconBaseForm = useFormik({
        initialValues: {
            name: '',
            description: ''
        },
        validate: (data) => {
            let errors = {};

            if (!data.name) {
                errors.name = 'Reconciled Run name is required.';
            }
            return errors;
        },
        onSubmit: (data) => {
            dispatch(createReconRun({
                "name": data.name,
                "description": data.description,
                "dimensions": initDimension
            }));
            reconBaseForm.resetForm();
        }
    });

    const isFormFieldValid = (name) => !!(reconBaseForm.touched[name] && reconBaseForm.errors[name]);
    const getFormErrorMessage = (name) => {
        return isFormFieldValid(name) && <small className="p-error">{reconBaseForm.errors[name]}</small>;
    };

    return (
        <form onSubmit={reconBaseForm.handleSubmit} 
              className="flex justify-content-center">
            <div className="flex-item col-4" >
                <span className="p-float-label p-input-icon-right w-full">
                    <InputText id="reconRunName" name="name" value={reconBaseForm.values.name}
                        disabled={!AccessType}
                        onChange={(e) => { reconBaseForm.handleChange(e); }}
                        className={classNames({ 'p-invalid': isFormFieldValid('name') }) + " w-full"} />
                    <label htmlFor="name" className={classNames({ 'p-error': isFormFieldValid('name') })}>Reconciled Run Name*</label>
                </span>
                {getFormErrorMessage('name')}
            </div>
            <div className="flex-item col-6">
                <span className="p-float-label">
                    <InputTextarea id="description" name="description" value={reconBaseForm.values.description} onChange={(e) => { reconBaseForm.handleChange(e); }}
                        disabled={!AccessType}
                        className={classNames({ 'p-invalid': isFormFieldValid('description') }) + " w-full"} />
                    <label htmlFor="description" className={classNames({ 'p-error': isFormFieldValid('description') })}>Description</label>
                </span>
            </div>
            <div className="flex-item col-1">
                <Button type="submit"
                    disabled={!AccessType}
                    label="Submit" className="mt-2 bg-primary" />
            </div>
        </form>

    );
}
export default CreateRecon;