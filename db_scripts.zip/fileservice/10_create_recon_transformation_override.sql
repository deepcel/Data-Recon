-- SEQUENCE: fileservice.recon_transformation_override_id_seq

DROP SEQUENCE if exists fileservice.recon_transformation_override_id_seq CASCADE;

CREATE SEQUENCE fileservice.recon_transformation_override_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE fileservice.recon_transformation_override_id_seq
    OWNER TO "user_dataRecon_file";

GRANT ALL ON SEQUENCE fileservice.recon_transformation_override_id_seq TO postgres;

GRANT ALL ON SEQUENCE fileservice.recon_transformation_override_id_seq TO "user_dataRecon_file";


-- Table: fileservice.recon_transformation_override

DROP TABLE if exists fileservice.recon_transformation_override CASCADE;

CREATE TABLE fileservice.recon_transformation_override
(
    id bigint NOT NULL DEFAULT nextval('fileservice.recon_transformation_override_id_seq'::regclass),
    recon_id int8 NULL,
	app_id int8 NULL,
	tfn_id int8 NULL,
	source_sync varchar NULL,
	target_sync varchar NULL,
	flip_sign bool NULL,
	CONSTRAINT pk_recon_trans_override_id PRIMARY KEY (id),
	CONSTRAINT "unique_tfnId_SourceSync" UNIQUE (tfn_id, source_sync)
)

TABLESPACE tbsp_data_recon;

ALTER TABLE fileservice.recon_transformation_override
    OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE fileservice.recon_transformation_override TO postgres;

GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.recon_transformation_override TO "user_dataRecon_file";