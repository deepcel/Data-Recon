-- Drop table
DROP TABLE if exists "admin".auth_user cascade;

CREATE TABLE "admin".auth_user (
	id serial4 NOT NULL,
	"password" varchar(128) NOT NULL,
	last_login timestamptz NULL,
	is_superuser bool NOT NULL,
	username varchar(150) NOT NULL,
	first_name varchar(150) NOT NULL,
	last_name varchar(150) NOT NULL,
	email varchar(254) NOT NULL,
	is_staff bool NOT NULL,
	is_active bool NOT NULL,
	date_joined timestamptz NOT NULL,
	uuid uuid NULL,
	"role" varchar(50) NULL,
	access_type jsonb NULL,
	"DC_Url" varchar(50) NULL,
	"DC_Username" varchar(50) NULL,
	"DC_Password" bytea NULL,
	tag bytea NULL,
	nonce bytea NULL,
	admin_tag varchar(50) NULL,
	onestream bool NULL,
	CONSTRAINT auth_user_pkey PRIMARY KEY (id),
	CONSTRAINT auth_user_username_key UNIQUE (username)
);
CREATE INDEX auth_user_username_6821ab7c_like ON admin.auth_user USING btree (username varchar_pattern_ops);