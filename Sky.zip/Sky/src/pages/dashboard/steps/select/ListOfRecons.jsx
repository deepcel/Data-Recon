import "./select.scss";
import React, { useEffect, useState } from "react";
import {
    listReconRun, deleteReconRun, updateReconRun,
    updateSelectedReconRunId, listReconRunDimension
} from "../../../../store/sliceReducers/ReconRunReducer";
import { useDispatch, useSelector } from "react-redux";
import { toast } from 'react-toastify';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { Badge } from 'primereact/badge';
import { InputSwitch } from "primereact/inputswitch";
import { InputTextarea } from 'primereact/inputtextarea';
import { ConfirmPopup, confirmPopup } from 'primereact/confirmpopup';
import { FilterMatchMode, FilterOperator } from 'primereact/api';
import { reconsHarddeleteAPIcall } from "../../../../store/sliceReducers/DashboardReducer";
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';
import './select.scss';

const ListOfRecons = (props) => {
    const dispatch = useDispatch();
    const authData = useSelector((state) => state.auth);
    let { data } = authData.data;
    const AccessType = data.access_type.privilege === 0 ? true : false;
    const [editingRows, setEditingRows] = useState({});
    const [globalFilterValue1, setGlobalFilterValue1] = useState('');
    const [filters1, setFilters1] = useState(null);
    const [checked, setChecked] = useState(false);

    const reconRunList = useSelector(state =>
        state.reconRun.appData[0]
    );

    useEffect(() => {
        dispatch(listReconRun());
        initFilters1();
    }, []);

    const handleChange = (e) => {
        const newChecked = e.value;
        setChecked(newChecked);
        dispatch(reconsHarddeleteAPIcall({ "autoRun": newChecked }));
    };

    const clearFilter1 = () => {
        initFilters1();
    }

    const onGlobalFilterChange1 = (e) => {
        const value = e.target.value;
        let _filters1 = { ...filters1 };
        _filters1['global'].value = value;

        setFilters1(_filters1);
        setGlobalFilterValue1(value);
    }

    const initFilters1 = () => {
        setFilters1({
            'global': { value: null, matchMode: FilterMatchMode.CONTAINS },
            'name': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'description': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'status': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'execution_date': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'created_by': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'created_date': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'last_modified_by': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'last_modified_date': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
        });
        setGlobalFilterValue1('');
    }

    const renderHeader1 = () => {
        return (
            <div className="flex justify-content-end" style={{ alignItems: 'center' }}>
                <span className="p-input-icon-left">
                    <i className="pi pi-search" />
                    <InputText value={globalFilterValue1}
                        onChange={onGlobalFilterChange1}
                        placeholder="Search" />
                </span>
                <Button type="button"
                    icon="pi pi-filter-slash"
                    title="Clear"
                    className="p-button-rounded  ml-1 bg-primary"
                    onClick={clearFilter1} /> &nbsp;&nbsp;&nbsp;&nbsp;
                <label htmlFor="myInputSwitch">Enable Auto Delete</label>&nbsp;&nbsp;
                <InputSwitch
                    id="myInputSwitch"
                    checked={checked}
                    onChange={handleChange}
                />
            </div>
        )
    }

    const deleteRecon = (recon_id, event) => {
        confirmPopup({
            target: event.currentTarget,
            message: 'Do you want to delete this record ?',
            icon: 'pi pi-info-circle',
            acceptClassName: 'p-button-danger',
            accept: () => {
                dispatch(deleteReconRun(recon_id));
            },
            reject: () => { }
        });
    }

    const actionBodyTemplate = (rowData) => {
        return (
            <React.Fragment>
                <Button icon="pi pi-eye" className="p-button-rounded p-button-warning mx-1 bg-primary" tooltip="view"
                    tooltipOptions={{ "position": "top" }} onClick={() => viewReconDetails(rowData)} />

                <Button icon="pi pi-trash" disabled={!AccessType}
                    className="p-button-rounded mx-1 bg-primary" tooltip="delete"
                    tooltipOptions={{ "position": "top" }} onClick={(e) => deleteRecon(rowData.recon_id, e)} />
            </React.Fragment>
        );
    }

    const executedOnTemplate = (rowData) => {
        return !!rowData.execution_date ? rowData.execution_date : "--";
    }

    const modifiedByTemplate = (rowData) => {
        return !!rowData.last_modified_by ? rowData.last_modified_by : "--";
    }

    const modifiedOnTemplate = (rowData) => {
        return !!rowData.last_modified_date ? rowData.last_modified_date : "--";
    }

    const onRowEditValidator = (rowData) => {
        if (!rowData['name']) {
            toast.error("Please fill the run name");
            return false;
        }
        return true;
    }

    const viewReconDetails = (rowData) => {
        dispatch(updateSelectedReconRunId(rowData.recon_id));
        dispatch(listReconRunDimension(rowData.recon_id));
        props.setWiz();
    }

    const onRowEditComplete = (e) => {
        let { newData } = e;
        dispatch(updateReconRun(
            {
                recon_id: newData.recon_id,
                name: newData.name,
                description: newData.description,
                dimensions: []
            }));
    }

    const onRowEditChange = (e) => {
        if (AccessType) {
            setEditingRows(e.data)
        }
    }

    const textEditor = (options) => {
        return <InputText className="w-full" type="text" value={options.value}
            onChange={(e) => options.editorCallback(e.target.value)} />;
    }

    const textArea = (options) => {
        return <InputTextarea type="text" value={options.value} onChange={(e) => options.editorCallback(e.target.value)} className="w-full" />;
    }

    const statusTemplate = (rowData) => {
        return <Badge value={rowData.status} severity={`${(rowData.status === 'Completed' ? "success" : "info")}`} className="mr-2"></Badge>;
    }

    const header1 = renderHeader1();

    return (
        <div className="card">
            <ConfirmPopup />
            <DataTable
                value={reconRunList}
                id="reconTable"
                editMode="row"
                dataKey="recon_id"
                rowEditValidator={onRowEditValidator}
                editingRows={editingRows}
                onRowEditChange={onRowEditChange}
                onRowEditComplete={onRowEditComplete}
                showGridlines
                sortMode="multiple"
                scrollable
                className="mt-3"
                removableSort
                scrollHeight="420px"
                scrollDirection="both"
                paginator
                filterDisplay="menu"
                globalFilterFields={['name', 'description', 'status', 'execution_date', 'created_by', 'created_date', 'last_modified_by', 'last_modified_date']}
                header={header1}
                paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
                currentPageReportTemplate="Showing {first} to {last} of {totalRecords}"
                rows={10}
                filters={filters1}
                responsiveLayout="scroll"
                rowsPerPageOptions={[10, 20, 50]}
                emptyMessage="No data found."
            >
                <Column style={{ width: '10.8%' }} field="name" header={<span className="run-name-header">Run Name</span>} sortable filter editor={(options) => textEditor(options)}></Column>
                <Column style={{ width: '12.4%', WordBreak: "break-word" }} className="ellipsify" field="description" header={<span className="description-header">Description</span>} sortable filter editor={(options) => textArea(options)}></Column>
                <Column style={{ width: '9.6%' }} field="status" align="center" header={<span className="status-header">Status</span>} sortable body={statusTemplate} filter></Column>
                <Column style={{ width: '11.8%' }} body={executedOnTemplate} align="center" field="execution_date"
                    header={<span className="executed-on">Executed On</span>} sortable filter ></Column>
                <Column style={{ width: '12%' }} field="created_by"
                    header={<span className="created">Created</span>} sortable filter ></Column>
                <Column style={{ width: '11%' }} field="created_date"
                    header={<span className="createdon">Created On</span>} sortable filter></Column>
                <Column style={{ width: '11.3%' }} body={modifiedByTemplate} align="center"
                    header={<span className="modified">Modified</span>} field="last_modified_by" sortable filter ></Column>
                <Column style={{ width: '11%' }} body={modifiedOnTemplate} align="center" field="last_modified_date"
                    header={<span className="modifiedon">Modified On</span>} sortable filter ></Column>
                <Column style={{ width: '5%' }} align="center" rowEditor header="Edit" required></Column>
                <Column style={{ width: '10.6%' }} align="center" field="name" body={actionBodyTemplate} header="Action" ></Column>
            </DataTable>
        </div>
    );
}
export default ListOfRecons;