from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from . import views

urlpatterns = [
    path('auth', views.user_login, name='userLogin'),
    path('logout', views.user_logout, name='userLogout'),
    path('list', views.user_list, name='userList'),
]

urlpatterns = format_suffix_patterns(urlpatterns)
