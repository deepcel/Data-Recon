ALTER TABLE IF EXISTS fileservice.recon_bridge_mapping
    ADD COLUMN is_invalid boolean;