import { createSlice } from "@reduxjs/toolkit";
import { toast } from "react-toastify";
import { makeGetAPICall, makePutAPICall, makePutAPIFormData,
         makePostAPICallFileDownload, makeDeleteBodyParamAPICall } from "../../utils/apiService";
  import { redirectToLogin } from "../../utils/utils";
  import { enableLoader, hideLoader } from "./LoadReducer";
  
  // Dashboard reducer is used for handle all the steps data
  export const transformationReducer= createSlice({
    name: "transformation",
    initialState: {
        loading: false,
        error: null,
        appData: [],
        transformation: {
          rows: [],
          app1Sync: [],
          app2Sync: [],
          combinations: {
            app1Dimension: [],
            app2Dimension: [],
            app1SourceSync:[],
            app2SourceSync:[],
            app1Data: [],
            app2Data: [],
          },
        },

    },
    reducers: {
      
        isLoading: (state, action) => {
          state.loading = true;
        },

        INVALID_SESSION: (state) => {
            state.loading = false;
            state.error = null;
          },
        LOAD_TRANSFORMATION_MEMBERS: (state, action) => {
            state.loading = false;
            state.error = null;
            state.transformation.rows = [...action.payload.response.rows];
          },
          LOAD_TRANSFORMATION_SYNC: (state, action) => {
            state.loading = false;
            state.error = null;            
            state.transformation.app1Sync = [...action.payload.response.app1_rows];
            state.transformation.app2Sync = [...action.payload.response.app2_rows];
            state.transformation.combinations.app1SourceSync = [...action.payload.response.app1_all_sync];
            state.transformation.combinations.app2SourceSync = [...action.payload.response.app2_all_sync];
          },

          RECON_IMPORT_TRANSFORM_MAPPINGS: (state, action) => {
            state.loading = false;
            state.error = null;
            if (action.payload.response.app_type === "0") {
              state.transformation.app1Sync = [...action.payload.response.rows];
            } else if (action.payload.response.app_type === "1") {
              state.transformation.app2Sync = [...action.payload.response.rows];
            }
          },
          UPDATE_TRANSFORMATION_MEMBERS: (state, action) => {
            state.loading = false;
            state.error = null;
            state.transformation.rows = [...action.payload.response.rows];
          },
          UPDATE_TRANSFORMATION_SYNC_MEMBERS: (state, action) => {
            state.loading = false;
            state.error = null;
            if (action.payload.response.app_type === "0") {
              state.transformation.app1Sync = [...action.payload.response.rows];
            } else if (action.payload.response.app_type === "1") {
              state.transformation.app2Sync = [...action.payload.response.rows];
            }
          },
          UPDATE_APP1SYNC:(state, action)=>{
            state.transformation.app1Sync=[action.payload, ...state.transformation.app1Sync];
          },

          UPDATE_APP2SYNC:(state, action)=>{
            state.transformation.app2Sync=[action.payload,...state.transformation.app2Sync  ];
          },


          TRANSFORM_LOAD_COMBINATIONS: (state, action) => {
              state.loading = false;
              state.error = null;  
          
              state.transformation.combinations.app1Dimension = [
                  ...action.payload.response.app1_dimensions,
               ];
              state.transformation.combinations.app2Dimension = [
                     ...action.payload.response.app2_dimensions,
                 ];
              state.transformation.combinations.app1Data = [
                     ...action.payload.response.app1_data,
                 ];
              state.transformation.combinations.app2Data = [
                    ...action.payload.response.app2_data,
                ];
             
              },
          
          DELETE_TRANSFORM_SYNC: (state, action) => {
            state.loading = false;
            state.error = null;
            if (action.payload.response.appType === "0") {
              state.transformation.app1Sync = state.transformation.app1Sync.filter(
                (item) => item.sync_id !== action.payload.response.syncId
              );
            } else if (action.payload.response.appType === "1") {
              state.transformation.app2Sync = state.transformation.app2Sync.filter(
                (item) => item.sync_id !== action.payload.response.syncId
              );
            }
          },
    },
});

export const {
    isLoading,
    INVALID_SESSION,
    LOAD_TRANSFORMATION_MEMBERS,
    LOAD_TRANSFORMATION_SYNC,
    RECON_IMPORT_TRANSFORM_MAPPINGS,
    TRANSFORM_LOAD_COMBINATIONS,
    UPDATE_APP1SYNC,
    UPDATE_APP2SYNC,
    UPDATE_TRANSFORMATION_MEMBERS,
    UPDATE_TRANSFORMATION_SYNC_MEMBERS,
    DELETE_TRANSFORM_SYNC
  } = transformationReducer.actions;

export const addRowApp1Sync= (payload)=> async (dispatch) =>{
  dispatch(UPDATE_APP1SYNC(payload))
}

export const addRowApp2Sync= (payload)=> async (dispatch) =>{
  dispatch(UPDATE_APP2SYNC(payload))
}
  // Get Recon transformation details
export const listTransformation = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makeGetAPICall("transformation/list/" + payload);
    if (response.status === 200) {
      dispatch(
        LOAD_TRANSFORMATION_MEMBERS({
          response: response,
        })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const updateTransformationMember = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPICall("transformation/update", payload);
    if (response.status === 200) {
      dispatch(
        UPDATE_TRANSFORMATION_MEMBERS({
          response: response,
          recon_id: payload.recon_id,
        })
      );
      dispatch(listTransformationSync(payload.recon_id));
      dispatch(listtransformationSyncCombination(payload.recon_id));
      toast.success("Transformation members updated successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};



export const downloadTransformSyncMap = (payload) => async (dispatch) => {
  try {
    dispatch(isLoading({ loading: true }));
    const response = await makePostAPICallFileDownload(
      "transformation/sync/export",
      payload
    );
    if (response.status === 200) {
      toast.success("Download triggered successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};
  export const transformSyncImport = (formData, appType) => async (dispatch) => {
    try {
      dispatch(enableLoader());
      const response = await makePutAPIFormData(
        "transformation/sync/import",
        formData
      );
      if (response.status === 200) {
        dispatch(
          RECON_IMPORT_TRANSFORM_MAPPINGS({
            response: response,
          })
        );
        // dispatch(listTransformationSync());
        toast.success("File imported successfully");
      } else if (response.status === 401) {
        dispatch(INVALID_SESSION(response));
        redirectToLogin();
      } else {
        toast.error(response.message);
      }
      dispatch(hideLoader());
    } catch (err) {
      dispatch(hideLoader());
    }
  };
  export const listTransformationSync = (payload) => async (dispatch) => {
    try {
      dispatch(enableLoader());
      const response = await makeGetAPICall(
        "transformation/sync/list/" + payload
      );
      if (response.status === 200) {
        dispatch(
          LOAD_TRANSFORMATION_SYNC({
            response: response,
          })        
        );
      } else if (response.status === 401) {
        dispatch(INVALID_SESSION(response));
        redirectToLogin();
      } else {
        toast.error(response.message);
      }
      dispatch(hideLoader());
    } catch (err) {
      dispatch(hideLoader());
    }
  };
  
  export const updateTransformationSync = (payload) => async (dispatch) => {
    try {
      dispatch(enableLoader());
      const response = await makePutAPICall(
        "transformation/sync/update",
        payload
      );
      if (response.status === 200) {
        dispatch(
          UPDATE_TRANSFORMATION_SYNC_MEMBERS({
            response: response,
          })
        );
        dispatch(listTransformationSync(payload.recon_id));
        toast.success("Transformation Sync updated successfully");
      } else if (response.status === 401) {
        dispatch(INVALID_SESSION(response));
        redirectToLogin();
      } else {
        toast.error(response.message);
      }
      dispatch(hideLoader());
    } catch (err) {
      dispatch(hideLoader());
    }
  };
  
  export const listtransformationSyncCombination =
    (payload) => async (dispatch) => {
      try {
        dispatch(enableLoader());
        const response = await makeGetAPICall(
          "transformation/sync/combinations/" + payload
        );
        if (response.status === 200) {
          dispatch(TRANSFORM_LOAD_COMBINATIONS({ response: response }));
        } else if (response.status === 401) {
          dispatch(INVALID_SESSION(response));
          redirectToLogin();
        } else {
          toast.error(response.message);
        }
        dispatch(hideLoader());
      } catch (err) {
        dispatch(hideLoader());
      }
    };
  
  // Delete transform sync based on reconid
  export const deleteTransformSync = (payload, appType) => async (dispatch) => {
    try {
      dispatch(enableLoader());
      const response = await makeDeleteBodyParamAPICall(
        "transformation/sync/delete",
        payload
      );
      if (response.status === 200) {
        dispatch(
          DELETE_TRANSFORM_SYNC({
            response: {
              appType: appType,
              syncId: payload.sync_id,
            },
          })
        );
        dispatch(listTransformationSync(payload.recon_id));
        toast.success("Transformation sync deleted successfully");
      } else if (response.status === 401) {
        dispatch(INVALID_SESSION(response));
        redirectToLogin();
      } else {
        toast.error(response.message);
      }
      dispatch(hideLoader());
    } catch (err) {
      dispatch(hideLoader());
    }
  };
  
  
export default transformationReducer.reducer;