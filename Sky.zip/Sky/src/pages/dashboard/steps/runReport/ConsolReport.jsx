import React from "react";
import { DataTable } from "primereact/datatable";
import { useSelector } from "react-redux";
import 'primeicons/primeicons.css';
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';
import './runReport.scss';

const ConsolReport = (props) => {
  const runReport = useSelector(state =>
    state.runreport.runReport
  );

  return (
    <DataTable id="runReportTable"
      value={runReport.final_report}
      responsiveLayout="scroll"
      scrollable
      scrollDirection="both"
      showGridlines
      removableSort
      filterDisplay="menu"
      globalFilterFields={[
        'bridgesync-Account-ACCT',
        'bridgesync-ENTITY-ENTITY',
        'bridgesync-VIEW-VIEW',
        'bridgesync-ACCOUNT-ACCOUNT',
        'bridgesync-Census-Dim17',
        'bridgesync-Customer-U6',
        'bridgesync-DataSource-U1',
        'bridgesync-Dim8-Origin',
        'bridgesync-Dim12-Function',
        'bridgesync-Dim13-U4',
        'bridgesync-Dim16-U7',
        'bridgesync-Dim18-U8',
        'bridgesync-Flows-Flow',
        'bridgesync-Geography-U5',
        'bridgesync-ICP-IC',
        'bridgesync-Segment-U2',
        'bridgesync-Value-Cons',
        'bridgesync-VIEW-VIEW',
        'Comments',
        '2022Jan',
        '2019Jan',
        '2019Feb',
        '2019Mar',
        '2019Apr',
        '2019May',
        '2019Jun',
        '2019Jul',
        '2019Aug',
        '2019Sep',
        '2019Oct',
        '2019Nov',
        '2019Dec',
        'Grand Absolute Total']}
      header={props.header}
      filters={props.filters1}
      sortMode="multiple"
      paginator
      scrollHeight="480px"
      paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
      currentPageReportTemplate="Showing {first} to {last} of {totalRecords}"
      rows={10}
      rowsPerPageOptions={[10, 20, 50]}
      emptyMessage="No data found.">
      {/* {dynamicColumns} */}
      {props.columnComponents}
    </DataTable>
  )
}

export default ConsolReport;