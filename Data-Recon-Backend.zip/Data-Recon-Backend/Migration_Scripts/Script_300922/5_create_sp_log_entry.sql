create or replace
procedure fileservice.sp_log_entry(
in app_id integer,
in status text,
in recon_id integer default null,
in table_name text default null
)
language 'plpgsql'
as $BODY$
declare
s_schema_name text := 'fileservice';
s_tracker_table text := 'track_app_data_table';
var_script text := '';
begin 

--	raise notice 'Log1: % % % %',app_id, status, recon_id, table_name;

	if (recon_id is null) and (table_name is null)
		then
			var_script = 'insert into ' || s_schema_name || '.' || s_tracker_table || ' (application_id, table_status, created_date)';
			var_script = var_script || 'values (' || app_id || ',' || status || ',''' ||localtimestamp||'''::timestamp);';	
	elsif (app_id is null) and (table_name is null)
		then
			var_script = 'insert into ' || s_schema_name || '.' || s_tracker_table || '(recon_id, table_status, created_date)';
			var_script = var_script || ' values (' || recon_id || ',' || status || ', ''' || localtimestamp || '''::timestamp);';
	elsif (app_id is null) 
		then 
			var_script = 'insert into ' || s_schema_name || '.' || s_tracker_table || ' (recon_id,  table_name, table_status, created_date)';
			var_script = var_script || ' values (' || recon_id || ',''' || table_name || ''', '||status||',''' || localtimestamp || '''::timestamp);';
	else
			var_script = 'insert into ' || s_schema_name || '.' || s_tracker_table || ' (recon_id, application_id, table_name, table_status, created_date)';
			var_script = var_script || ' values (' || recon_id || ',' || app_id || ',''' || table_name || ''', '||status||',''' || localtimestamp || '''::timestamp);';
	end if;
	
--	raise notice 'log2: %', var_script;
-- Run insert into trakcer table
	execute var_script;
	commit;
end;

$BODY$
