import React,{useState} from "react";
import { useDispatch, useSelector } from "react-redux";
import "./runImport.scss";
import { Button } from "primereact/button";
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';
import { useFormik } from 'formik';
import { classNames } from 'primereact/utils';
import { InputText } from 'primereact/inputtext';
import { Dialog } from 'primereact/dialog';
import OneStreamApp2 from "../direct connect/OneStreamApp2";
const OSExtracApp2 = () => {
   
    const [visibleApp2, setApp2Visible] = useState(false);

    // const app1_Import_type=useSelector(state =>
    //     state.dimField.reconDetails.app1_import_type
    // );

    // const app2_Import_type=useSelector(state =>
    //     state.dimField.reconDetails.app2_import_type
    // );

    // let showJob1=app1_Import_type==='0'?false:true;
    // let showJob2=app2_Import_type==='0'?false:true;
    const hideApp2dialogue=()=>{
        setApp2Visible(false)
    }
    return (
        <>
        <p className="mt-0 ml-2">App2 Extract Data:</p>
            <Button type="button" id="ExtractApp2" label="Extract App2"
                    className="bg-primary mx-2"
                    onClick={()=>{setApp2Visible(true)}}/>
                <Dialog visible={visibleApp2}
                        header="App2 OneStream extraction"
                        className="center-header"
                        style={{ width: '60vw',height:'80vh' }} 
                        onHide={hideApp2dialogue}>
                            <OneStreamApp2/>
                </Dialog> 
          
        </>
    )
}
export default OSExtracApp2;