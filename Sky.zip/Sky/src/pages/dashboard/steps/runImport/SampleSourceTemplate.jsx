import React from "react";
import { saveAs } from "file-saver";
import { Button } from "primereact/button";
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';
import "./runImport.scss";
import Paper from '@mui/material/Paper';

const SampleSourceTemplate = () => {
 
    const handleDownload = () => {
        const csvData = 'YEAR,PERIOD,VIEW,Entity,Account,AMOUNT\n2019,Jan,YTD,E_MHICompanies,CashTot,1556372950'; // Replace this with your CSV data
        const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
        saveAs(blob, 'Runimporttemplate.txt');
    };

 return (
    <>     
     <Paper variant="outlined" className="mt-4">
             <div className="card flex justify-content-start ml-2 mt-1 pb-0">
                <span style={{fontSize: '1.02rem'}}>Download and view source template </span>
             </div>
             
             <Button icon="pi pi-download"  
                     label="Source Template"
                     title="Download source file template"
                     className="p-button-success m-2  bg-primary" 
                     onClick={handleDownload} />             
           
      </Paper>       
    </>
  )
}

export default SampleSourceTemplate;