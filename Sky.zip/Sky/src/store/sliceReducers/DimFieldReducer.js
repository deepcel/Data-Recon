import { createSlice } from "@reduxjs/toolkit";
  
  // Dimension field reducer is used for handle all the steps data
  export const DimFieldReducer = createSlice({
    name: "dimField",
    initialState: {
        reconDetails :{
          recon_id:"",
          app1_delimiter:"",
          app1_has_header:"",
          app1_import_type:"",
          app1_currency_symbol:"",
          app2_delimiter:"",
          app2_has_header:"",
          app2_import_type:"",
          app2_currency_symbol:"",
          variance_threshold:"",          
          dimensions:[],
        },
        isFieldEdit:false,
    },
    reducers: {
      
        INIT_RECON_DETAILS: (state, action) => {
            // state.reconDetails.recon_id=action.payload.recon_id;           
            // state.reconDetails.app1_delimiter=action.payload.app1_delimiter;
            // state.reconDetails.app1_has_header=action.payload.app1_has_header;
            // state.reconDetails.app1_import_type=action.payload.app1_import_type;
            // state.reconDetails.app1_currency_symbol=action.payload.app1_currency_symbol;
            // state.reconDetails.app2_delimiter=action.payload.app2_delimiter;
            // state.reconDetails.app2_has_header=action.payload.app2_has_header;
            // state.reconDetails.app2_import_type=action.payload.app2_import_type;
            // state.reconDetails.app2_currency_symbol=action.payload.app2_currency_symbol;
            // state.reconDetails.variance_threshold=action.payload.variance_threshold;
            Object.assign(state.reconDetails,action.payload)
         },

        UPDATE_RECON_DETAILS: (state, action) => {          
             Object.assign(state.reconDetails,action.payload);
             state.isFieldEdit=true;          
         },
         UPDATE_ISFIELD_EDIT:(state) => { 
          state.isFieldEdit=false;          
      },
    },
});

export const {
    UPDATE_RECON_DETAILS,
    UPDATE_ISFIELD_EDIT,
    INIT_RECON_DETAILS
} = DimFieldReducer.actions;

export const fieldEditStatus=()=>async (dispatch) => {
  dispatch(UPDATE_ISFIELD_EDIT());
};
export const saveDimFields = (payload) => async (dispatch) => {
  dispatch(UPDATE_RECON_DETAILS(payload));
};

export const initDimFields = (payload) => async (dispatch) => {
    dispatch(INIT_RECON_DETAILS(payload));
  };
  
export default DimFieldReducer.reducer;