import { toast } from "react-toastify";
import { persistor } from "../store/index";
// Keep token in session storage
export const updateToken = (responseData) => {
  // Put the object into storage
  sessionStorage.setItem("profile", JSON.stringify(responseData.accessToken));
  sessionStorage.setItem("objUser", JSON.stringify(responseData));
  sessionStorage.setItem("email", JSON.stringify(responseData.data.email));
};

export const getToken = (type) => {
  //retrieve the object from storage
  var retrievedObject = sessionStorage.getItem(type);
  return !!retrievedObject ? JSON.parse(retrievedObject) : null;
};

// This method will return logged in username
export const getUserName = (type) => {
  const retrievedObj = getToken("objUser");
  return retrievedObj.first_name?.charAt(0);
};
//This method will return logged in email
export const getEmail = (type) => {
  if (sessionStorage.getItem("profile")) {
    let id = sessionStorage.getItem("email");
    return JSON.parse(id);
  }
};
// Clear session storage and redirect to login
export const redirectToLogin = () => {
  clearSession();
  persistor.purge();
  window.location = process.env.REACT_APP_URI;
};

// Get token from session storage and added as Bearer Authorization header
export const getAuthorizationHeaders = () => {
  if (!sessionStorage.getItem("profile")) {
    redirectToLogin();
    return;
  }
  const token = JSON.parse(sessionStorage.getItem("profile"));
  return { headers: { Authorization: `Bearer ${token}` } };
};

// Utility to validate whether user is logged in or not
export const isUserLoggedIn = () => {
  let response = false;
  if (sessionStorage.getItem("profile")) {
    response = true;
  }
  return response;
};

// Clear data from session storage
export const clearSession = () => {
  persistor.purge();
  sessionStorage.setItem("profile", "");
  sessionStorage.setItem("objUser", []);
  sessionStorage.setItem("email", "");
};

function padTo2Digits(num) {
  return num.toString().padStart(2, "0");
}

// format date
export const formatDate = (date) => {
  return [
    padTo2Digits(date.getMonth() + 1),
    padTo2Digits(date.getDate()),
    date.getFullYear(),
  ].join("/");
};

export const showTostify = (responce, message) => {
  //tosrify error / success alert
  if (responce.status === 200) {
    message = message ? message : "Success";
    toast.success(message);
  } else if (responce.status === 403) {
    let msg = !!responce.message
      ? responce.message
      : "Your session expired please try login";
    toast.info(msg);
    setTimeout(() => {
      redirectToLogin("/");
    }, 1000);
  } else {
    toast.info("success");
  }
};
