import json
import pandas as pd
from . get_headers import get_headers


'''
<!---------- Method to read the cache file and give back the section
             data as a response ----------!>
'''


def get_cache_data(recon_id, source_cache_path, max_rows, section_number):

    # Getting the combinations
    combinations = get_headers(recon_id)

    # Getting the cache data
    cache_source = pd.read_pickle(source_cache_path)

    # Restrict max rows
    number_of_rows = len(cache_source)
    if number_of_rows % max_rows == 0:
        number_of_sections = int(number_of_rows / max_rows)
    else:
        number_of_sections = int(number_of_rows / max_rows) + 1

    # Getting the from and to based on section
    start_point = (section_number - 1) * max_rows
    end_point = section_number * max_rows
    section_data_frame = cache_source.iloc[start_point:end_point]

    # Getting the section JSON
    json_rows = section_data_frame.to_json(orient='records')
    json_rows = json.loads(json_rows)

    response_data = {
        'status': 200,
        'current_page': section_number,
        'total_pages': number_of_sections,
        'headers': combinations,
        'rows': json_rows,
        'message': 'Source file data retrieved successfully!'
    }

    return response_data
