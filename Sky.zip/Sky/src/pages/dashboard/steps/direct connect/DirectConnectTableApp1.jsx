import React, { useState, useEffect } from 'react';
import { useDispatch,useSelector  } from "react-redux";
import { toast } from "react-toastify";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from "primereact/button";
import { Dropdown } from 'primereact/dropdown'; 
import { updateApp1Dimension,initApp1Dimension} from '../../../../store/sliceReducers/DirectConnectReducer';
import {  updateDimensions } from '../../../../store/sliceReducers/RunImportReducer';
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';
let itemsTofilter=[];
const CustomDropdown = ({ index, rowData, field, options, dropdownOptions}) => {
 console.log(options,index)
  const [selectedOption, setSelectedOption] = useState([]);
  const dispatch = useDispatch();
  const onOptionChange = (e) => {
    if (e.value !== 'NOT APPLICABLE') {
      if(itemsTofilter.includes(e.value))
      {
        let toaststr= e.value + ' is already tagged'
        toast.info(toaststr)
      }
      else
      {
        setSelectedOption(e.value);
   
        itemsTofilter[index]=e.value;
        
         let payload={index:index, value:e.value}
         dispatch(updateApp1Dimension(payload))
      }
    }
    else
    {
      setSelectedOption(e.value);
      itemsTofilter[index]=e.value;
      let payload={index:index, value:e.value}
      dispatch(updateApp1Dimension(payload))
    }
    
  };
  
  return (
    <Dropdown value={selectedOption} 
              id={"dropdown"+index}
              style={{width:"150px"}}
              options={options}             
              onChange={(e)=>{onOptionChange(e);console.log(options);}} />
  );
};

function DirectConnectTableApp1(props) {

  const dispatch = useDispatch();
  const authData = useSelector((state) => state.auth);
  let { data } = authData.data;
  const [disabled, setDisabled] = useState(false);
  const AccessType = data.access_type.privilege === 0 ? true : false; 
  const [dropdownOptions, setDropdownOptions] = useState({});

 
  const selectedReconId = useSelector(state =>
      state.reconRun.selectedReconRunId
    );


  const dim=useSelector(state =>
    state.reconRun.dimensions.dimensionsimport
  );
  
  let dimensiontoSend=useSelector(state =>
    state.DirectConnect.DCApp1Dimensions
  );

  const DCData=useSelector(state =>
    state.DirectConnect.DCDataApp1
  );

  const headers=useSelector(state =>
    state.DirectConnect.App1Headers
  );
  
  const fname=useSelector(state =>
    state.DirectConnect.App1file
  );

  let app1dimensions= dim.map((item)=>{
    return (item.app1_is_active? item.app1_dimension.toUpperCase():'')
   });

  app1dimensions=app1dimensions.filter(item=>item);//remove empty strings
  app1dimensions.push('NOT APPLICABLE');

  useEffect(()=>{
   dispatch(initApp1Dimension(app1dimensions))
   for(let i =0;i<=headers.length;i++)
   {
    itemsTofilter[i]='';
   }
   const options = {};
   headers.forEach((col) => {
     options[col] = app1dimensions.filter((dim) => !itemsTofilter.includes(dim));
   });
   setDropdownOptions(options);
  },[])

  

const saveDimension=()=>{
 
  if((dimensiontoSend.includes('YEAR'))&& (dimensiontoSend.includes('PERIOD'))&&(dimensiontoSend.includes('AMOUNT')))
  {
     setDisabled(true);
     dispatch(updateDimensions({
              "recon_id":selectedReconId,
              "appType":'0',  
              "max_rows":5000,  
              "page_number":1,
              "headers":dimensiontoSend,
              "files":fname}));
     setTimeout(() => {
                setDisabled(false);
              }, 10000); // set timeout for 3 seconds
  }
  else
  {
    toast.info('YEAR, PERIOD, AMOUNT is a required dimension')
  }
}

const renderHeader2 = () => {
  return (
      <div className="flex justify-content-end">
          <Button type="submit" label="Save Dimensions"
                  icon="pi pi-save"
                  className="p-button-success  mx-1 mb-2 bg-primary"
                  disabled={disabled}
                  tooltipOptions={{ "position": "top" }} tooltip="Save dimension changes"
                  onClick={saveDimension} />
      </div>
  )
}

const header2 = renderHeader2();
  return (
   <DataTable id="DirectConnectTable"
              value={DCData}
              header={header2}
              column
              dataKey="index"
              showGridlines
              scrollable
              scrollDirection="both"
              sortMode="multiple"
              scrollHeight="500px"
              rows={5}
              filterDisplay="menu"
              removableSort>
    {      
       headers?.map((col, i) => {
        return (<Column field={col} 
                        header={(rowData) => <CustomDropdown index={i} style={{width:'100%'}}
                                                      rowData={rowData} field={col} 
                                                      dropdownOptions={dropdownOptions}
                                                      options={app1dimensions} />} 
                        key={i}
                 style={{ "width": "11%" }}
                 headerStyle={{margin:'0', padding:'5px 2px',width:'11%'}}
                 className="ellipsify" />);
})}
</DataTable>
    )
}
export default DirectConnectTableApp1;