import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Button } from "primereact/button";
import { classNames } from 'primereact/utils';
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';
import Paper from '@mui/material/Paper';
import { useFormik } from 'formik';
import ArchiveOutlinedIcon from '@mui/icons-material/ArchiveOutlined';
import IconButton from '@mui/material/IconButton';
import {
  exportrunreport, archiveRunReport, runReportPostFilter, runReportPost
} from "../../../../store/sliceReducers/RunReportReducer";
import { InputText } from "primereact/inputtext";

const VarianceForm = (props) => {
  const dispatch = useDispatch();
  const [errMessage, setErrorMessage] = useState("");
  const authData = useSelector((state) => state.auth);
  let { data } = authData.data;
  const AccessType = data.access_type.privilege === 0 ? true : false;
 
  const selectedReconId = useSelector(state =>
    state.reconRun.selectedReconRunId
  );

  const runReport = useSelector(state =>
    state.runreport.runReport
  );
  useEffect(() => {
    let initvalues = {
      variance_threshold: props.varThreshold,
    }
    varianceForm.setValues(initvalues)
  }, [props.loading])

  const varianceForm = useFormik({
    initialValues: {
    },
    validate: (data) => {
      let errors = {};

      if (!data.variance_threshold) {

        errors.variance_threshold = 'Variance Threshold is required.';
      }
      else if (!/^[1-9]\d*$/i.test(data.variance_threshold)) {
        errors.variance_threshold = 'Invalid value';
      }

      return errors;
    },
    onSubmit: (data) => {

    },
  });

  const isFormFieldValid = (name) => !!(varianceForm.touched[name] && varianceForm.errors[name]);
  const getFormErrorMessage = (name) => {

    //  setErrorMessage((isFormFieldValid(name) && <small className="p-error">{inviteForm.errors[name]}</small>))
    return isFormFieldValid(name) && <small className="p-error block">{varianceForm.errors[name]}</small>;
  };
  const removeErrorMessage = () => {
    if (errMessage && errMessage.length > 0) {
      setErrorMessage("");
    }
  }

  let cols = props.selctedColumns;

  // const downloadRunReport = () => {
  //   dispatch(exportrunreport(
  //     {
  //       "recon_id": selectedReconId,
  //       "colList": cols.selctedColumns,
  //     }));
  // }

  const zipRunReport = () => {
    dispatch(archiveRunReport(selectedReconId))
  }

  const handleThresChange = (e) => {
    e.preventDefault();
    if (selectedReconId && (e.target.value)) {
      props.setvarThreshold(e)
      Object.assign(varianceForm.values, { variance_threshold: e.target.value })
      dispatch(runReportPostFilter({
        recon_id: selectedReconId,
        max_rows: 5000,
        page_number: 1,
        colList: cols,
        sp_flag: false,
        variance_threshold: varianceForm.values.variance_threshold,
      }));
    }
  }

  return (
    <>
      <Paper variant="outlined" className="mb-4">
        <div className="card flex justify-content-start ml-2 mt-2 mb-3 pb-0">
          <span style={{ fontSize: '1.02rem' }}>Variance Threshold Details </span>
        </div>
        <form className="formgroup-inline formgrid grid">
          <div className="field col-2">
            <span className="p-float-label p-input-icon-right">
              {/* <i className="pi pi-envelope" /> */}
              <InputText
                id="variance_threshold"
                style={{ width: '260px', marginLeft:"15px" }}
                name="variance_threshold"
                value={!!varianceForm.values.variance_threshold ? varianceForm.values.variance_threshold : ""}
                placeholder="Variance Threshold"
                className={classNames({ 'p-invalid': isFormFieldValid('variance_threshold') })}
                onChange={(e) => { varianceForm.handleChange(e); handleThresChange(e); removeErrorMessage(); }} />
              <small className="p-error block">{getFormErrorMessage('variance_threshold')}</small>
              <label htmlFor="variance_threshold">
                Variance Threshold
              </label>
            </span>
          </div>

          <div className="field col-4 ml-3">
          </div>
          {/* <div className="field">
                      <Button type="submit" label="Submit" className="bg-primary" />
                    </div> */}

          <div className="col-5 text-right" style={{ marginTop: '-30px' }}>
            {runReport &&

              <p className="mt-0">Variance Percentage: <span className="font-bold" style={{ fontColor: "#333366" }}>
                {runReport.variance_percentage} </span> </p>
            }
            {/* <Button icon="pi pi-download" onClick={downloadRunReport} disabled={!AccessType}
              className="p-button-rounded  mx-1 bg-primary" title="Download Run Report" />
            <IconButton size="large" disabled={!AccessType}
              className="p-button-rounded  mx-2 bg-primary" onClick={zipRunReport} title="Archive Run Report">
              <ArchiveOutlinedIcon />
            </IconButton> */}
          </div>
        </form>
      </Paper>
    </>
  )
}
export default VarianceForm;