from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from . import views


urlpatterns = [
    path('file/import', views.import_source_file, name='import_source_file'),
    path('data', views.get_source_data, name='get_source_data'),
    path('export', views.export_source_data, name='export_source_data'),
    path('file/je/import', views.import_je_file, name='import_je_file'),
    path('je/data', views.get_je_data, name='get_je_data'),
    path('je/export/<int:recon_id>', views.export_je_data, name='export_je_data'),
    path('dc/import', views.direct_connect, name='direct_connect'),
    path('dc/dimtag', views.dim_tag, name='dim_tag'),
    path('je/update', views.je_update, name='je_update'),
    path('je/delete', views.je_delete, name='je_delete'),

]

urlpatterns = format_suffix_patterns(urlpatterns)

