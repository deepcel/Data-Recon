import React, { useEffect, useState } from "react";
import { Card } from "primereact/card";
import { useDispatch, useSelector } from "react-redux";
import "./transformation.scss";
import {
    listDimension
} from '../../../../store/sliceReducers/BridgeMemberReducer';
import {
    listTransformation,
    listTransformationSync,
    listtransformationSyncCombination,
} from "../../../../store/sliceReducers/TransformationReducer";
import SampleTransTemplate from "./SampleTransTemp";
import TransTable from "./TransTable";
import App1Sync from "./App1Sync";
import App2Sync from "./App2Sync";
import TransformFiles from "./TransformFiles";

const Transformation = () => {

    const dispatch = useDispatch();
    const [reconRunName, setReconRunName] = useState("");

    const reconRunList = useSelector(state =>
        state.reconRun.appData[0]
    );

    const selectedReconId = useSelector(state =>
        state.reconRun.selectedReconRunId
    );
    useEffect(() => {
        let filteredRecon = reconRunList.find(run => run.recon_id === selectedReconId)
        if (filteredRecon) {
            setReconRunName(filteredRecon.name)
            dispatch(listDimension(selectedReconId));
            dispatch(listTransformation(selectedReconId));
            dispatch(listTransformationSync(selectedReconId));
            dispatch(listtransformationSyncCombination(selectedReconId));
        }
        //  initFilters1();
    }, [])

    return (
        <React.Fragment>
            <Card className="shadow-5">
                <div className="card pt-0">
                    {
                        !reconRunName && <div className="text-center text-pink-500">
                            Please select recon and click transformation tab
                        </div>
                    }
                    {
                        !!reconRunName && <React.Fragment>
                            <TransTable reconRunName={reconRunName} />
                            <br></br><br></br>
                            <SampleTransTemplate/>
                            <div className="field p-2">
                                <TransformFiles />
                            </div>
                           
                            <div className="formgrid grid p-2">
                                <div className="col-6">
                                    <App1Sync />
                                </div>
                                <div className="col-6 text-right">
                                    <App2Sync />
                                </div>
                            </div>
                        </React.Fragment>
                    }
                </div>
            </Card>
        </React.Fragment>
    )
}
export default Transformation;

