import React,{useState} from 'react';
import { Button } from 'primereact/button';
import { Grid } from '@material-ui/core';
import { Password } from 'primereact/password';
import Footer from '../../../components/footer/Footer';
import { resetPassword } from '../../../store/sliceReducers/AuthReducer';
import { useDispatch, useStore } from 'react-redux';
import { useNavigate } from 'react-router-dom';
 
const ResetPassword = () => {
    const [password, setPassword] = useState("");
    const [rePassword, setRepassword] = useState("");
    const [error, setError] = useState({message:null});
    const dispatch = useDispatch();
    const store = useStore();
    const navigate = useNavigate();

    const [disable, setDisable] = useState(false);

    const resetInputField = () => {
        setPassword("");
        setRepassword("");
    }

    const handleStateChange = () => {
        const authDetails = store.getState().auth;
        if(authDetails.error == null && !authDetails.loading){
            navigate("/");
        }else{
            setError({message:"Failed to update"});
        }
    };

    const handleReset = (e) => {
        e.preventDefault();
        var params = new window.URLSearchParams(window.location.search);
        if (password == rePassword && password.length >5) {
            dispatch(resetPassword({
                email: params.get('email'),
                password: password,
                token: params.get('token')
            },
                () => { handleStateChange() }, "User password reset successfully"));
            resetInputField();
            setDisable(true);
        }
        else {
            let errorMsg = password != rePassword ? "Please re-enter the same password" : password.length < 6 || rePassword.length < 6  ? "Password should contain more than 5 characters" : "Please re-enter the same password";
            setError({message:errorMsg})
        }
    };

    return (
        <React.Fragment>
            <div className="content grid grid-nogutter surface-section text-800">
                <div className="col-12 md:col-6 overflow-hidden">
                {/* <span>Data Recon Automation...</span> */}
                    <img src="assets/images/reset.svg" alt="hero-1" className="md:ml-auto block md:h-full" style={{ clipPath: 'polygon(8% 0, 100% 0%, 100% 100%, 0 100%)', width: "99%",marginRight:"-15px" }} />
                </div>
                <div className="col-12 md:col-6 flex align align-items-center justify-content-center overflow-hidden">
                    <div className="surface-card m-4 p-4 shadow-2 border-round w-full lg:w-6">
                        <div className="text-center">
                            <div className="text-900 text-3xl font-medium mb-5">Reset Your Password</div>
                        </div>
                        <form className="p-fluid" onSubmit={(e) => handleReset(e)}>
                            <div className="field mb-5">
                            {error.message !=null && <Grid align='center'><div className="errorMsg">{error.message}</div></Grid>}<br></br>
                                <span className="p-float-label">
                                    <Password id="password" name="password"
                                        toggleMask
                                        required
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                        panelClassName="hidden" />
                                    <label htmlFor="password"
                                    >Password*</label>
                                </span>
                                <small id="password" className="block">Password should contain more than 5 characters</small>
                            </div>
                            <div className="field mb-5">
                                <span className="p-float-label">
                                    <Password id="retype-password" name="retype-password"
                                        toggleMask
                                        required
                                        value={rePassword}
                                        onChange={(e) => setRepassword(e.target.value)}
                                        panelClassName="hidden" />
                                    <label htmlFor="retype-password"
                                    >Re-Type Password*</label>
                                </span>
                            </div>
                            <Button type="submit" label="Submit" className="mt-2 bg-primary" />
                        </form>
                    </div>
                </div>
            </div>
            <Footer />
        </React.Fragment>
    )
}
export default ResetPassword