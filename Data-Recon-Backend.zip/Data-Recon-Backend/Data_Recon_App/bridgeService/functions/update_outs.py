from ...models import ReconBridgeMapping

'''
<!---------- Method to update kick outs
             and return response ----------!>
'''


def update_outs(recon_id, kick_out_rows):
    for i in range(0, len(kick_out_rows)):
        app_type = '0' if kick_out_rows[i]['app1_app2'] == 'App1' else '1'
        if ReconBridgeMapping.objects \
                .filter(recon_id=recon_id, source_member=kick_out_rows[i]['bridge_member'],
                        app_type=app_type).exists():
            instance = ReconBridgeMapping.objects \
                .filter(recon_id=recon_id, source_member=kick_out_rows[i]['bridge_member'],
                        app_type=app_type)[0]
            instance.source_member = kick_out_rows[i]['source_member']
            instance.save()

            response_data = {
                'status': 200,
                'message': 'Kick outs updated successfully!'
            }
        else:
            response_data = {
                'status': 6002,
                'message': 'Invalid bridge member!'
            }

    return response_data
