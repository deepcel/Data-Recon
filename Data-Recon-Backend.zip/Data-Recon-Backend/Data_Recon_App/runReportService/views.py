import io
from datetime import datetime
from django.http import HttpResponse
from rest_framework import status
from rest_framework.decorators import permission_classes, api_view, renderer_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.renderers import JSONRenderer
from rest_framework.response import Response
from ..models import Recon, ReconDimensions
from .functions.execute_report import execute_report
from .functions.export_report_run import export_report_run
import zipfile
from django.conf import settings
import os
from .functions.get_all_paths import get_all_paths
from ..reconService.functions.export_store import export_store
from ..reconService.functions.get_dim_export import get_dim_export
from ..bridgeService.functions.get_export_data import get_export_data, \
    get_comment_export_data, get_kick_out_export_data, get_run_bridge_export_data
from ..runImportService.functions.export_data import export_data
from ..transformationService.functions.export_sync_data import export_sync_data
from ..transformationService.functions.export_trans_run import export_trans_run
from .functions.in_recon_dims import in_recon_dims
from ..utils.user_permissions import is_write_permitted
from ..runReportService.functions.run_export_report import run_export_report
from .functions.getReport import getReport as gR
import base64
import requests
from ..utils.run_export_script import run_export_script
from ..utils.export_query import dim_query, bridge_query, comment_query, bridge_kick_out_query, \
    run_bridge_export_query, export_source_data_query, run_trans_export_query


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def run_report(request):
    # Getting the data from request
    recon_id = request.data['recon_id']
    max_rows = request.data['max_rows']
    page_number = request.data['page_number']
    variance = request.data['variance_threshold']


    if(request.data['colList']):
        colList = request.data['colList']
    else:
        colList = '*'
    
    if(request.data['sp_flag']):
        sp_flag = request.data['sp_flag']
    else:
        sp_flag = False

    if is_write_permitted(request.user.email):
        # Checking if recon exists or not deleted
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            response_data = execute_report(recon_id, max_rows, page_number, colList, sp_flag, variance_threshold=variance)
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            response_data = execute_report(recon_id, max_rows, page_number, colList, sp_flag=False, variance_threshold=variance)
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def run_report_export(request):
    recon_id = request.data['recon_id']
    if is_write_permitted(request.user.email):
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            variance = Recon.objects.get(recon_id=recon_id, is_deleted=False).variance_threshold
            # report_type = request.data['report_type']
            #report_type = 'variance'
            report_type=''

            if(request.data['colList']):
                colList = request.data['colList']
            else:
                colList = '*'
            
            # Call export function
            response_data = run_export_report(colList,recon_id,variance,report_type)
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)

@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def getReport(request, recon_id):
    if is_write_permitted(request.user.email):
        response = HttpResponse(gR(recon_id))
        response['Content-Disposition'] = f'attachment; filename= Report.zip'
        response['Access-Control-Expose-Headers'] = 'Content-Disposition'
        return response
    else:
        response = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }
    return Response(response, status=status.HTTP_200_OK)

@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def archived_files(request, recon_id):
    if is_write_permitted(request.user.email):
        # archiving export files
        objs = {
            "Dimension_export.csv": dim_query(recon_id),
            "App1_Bridge_Export.csv": bridge_query(recon_id, 0),
            "App2_Bridge_Export.csv": bridge_query(recon_id, 1),
            "Bridge_Comments_Export.csv": comment_query(recon_id),
            "Bridge_Kick_out_Export.csv": bridge_kick_out_query(recon_id, False),
            "JE_Bridge_Kick_out_Export.csv": bridge_kick_out_query(recon_id, True),
            "Run_bridge_Export.csv": run_bridge_export_query(recon_id, False),
            "JE_Run_bridge_Export.csv": run_bridge_export_query(recon_id, True),
            "Source_Data_Export.csv": export_source_data_query(recon_id, False),
            "JE_Source_Data_Export.csv": export_source_data_query(recon_id, True),
            "Run_transformation_Export.csv": run_trans_export_query(recon_id),
        }

        for file_name, query in objs.items():
            run_export_script(recon_id, file_name, query)

        sync_objs = {
            "Sync_Mapping_app1_": export_sync_data(recon_id, 0),
            "Sync_Mapping_app2_": export_sync_data(recon_id, 1)
        }
        for obj, fun in sync_objs.items():
            export_store(recon_id, fun.getvalue(), obj)

        run_export_report("*", recon_id)

        # zipping the archived files
        # zip_file = 'archive_files' + datetime.now().time().strftime("%H:%M:%S") + '.zip'
        # response = HttpResponse(content_type='application/zip')
        # actual_file = io.BytesIO

        zpath = os.path.join(settings.MEDIA_ROOT, str(recon_id) + "archive.zip")

        with zipfile.ZipFile(zpath, 'w') as my_zip:
            archive_path = os.path.join(settings.MEDIA_ROOT, str(recon_id))
            file_paths = get_all_paths(archive_path)
            for file in file_paths:
                my_zip.write(file, os.path.basename(file))

        zpath = os.path.join(settings.MEDIA_ROOT, str(recon_id) + "archive.zip")
        zip_file = open(zpath, 'rb')

        response = HttpResponse(zip_file.read(), content_type='application/zip')
        response['Content-Disposition'] = f'attachment; filename= {str(recon_id)}_Archive.zip'
        response['Access-Control-Expose-Headers'] = 'Content-Disposition'
        return response
    else:
        response = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }
    return Response(response, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def dim_view(request):
    # recon_id = request.data['recon_id']
    # dim_id_lst = request.data['dimensions_id']
    #
    # if is_write_permitted(request.user.email):
    #     if recon_id != '' and ReconDimensions.objects.filter(recon_id=recon_id, is_deleted=False).exists():
    #         ReconDimensions.objects.filter(recon_id=recon_id).update(in_recon=False)
    #         for dim_id in dim_id_lst:
    #             if ReconDimensions.objects.filter(recon_id=recon_id, dimensions_id=dim_id).exists():
    #                 for i in range(len(ReconDimensions.objects.filter(recon_id=recon_id, dimensions_id=dim_id))):
    #                     instance = ReconDimensions.objects.filter(recon_id=recon_id, dimensions_id=dim_id)[i]
    #                     ReconDimensions.objects.filter(recon_id=recon_id,
    #                                                    turn_on_define_order=instance.turn_on_define_order)\
    #                         .update(in_recon=True)
    #             else:
    #                 response_data = {
    #                     'status': 403,
    #                     'message': 'Invalid Dimension id'
    #                 }
    #                 return Response(response_data)
    #             response_data = {
    #                 'status': 200,
    #                 'in_recon_dims': in_recon_dims(recon_id),
    #                 'message': 'Success'
    #             }
    #     else:
    #         response_data = {
    #             'status': 403,
    #             'message': 'No recon found with the specified id!'
    #         }
    # else:
    #     response_data = {
    #         'status': 6002,
    #         'message': 'Un-authorized action detected!'
    #     }
    # return Response(response_data, status=status.HTTP_200_OK)

    # import requests
    # import base64  # OneStream REST API endpoint
    url = "https://onestream.donyati.com/onestreamapi/api/Authentication/LogonAndReturnCookie?api-version=5.2.0"  # Base64-encoded username and password
    username = "epmvelocity@donyati.com"
    password = "Alw@ys+ve21"
    auth_string = base64.b64encode(f"{username}:{password}".encode()).decode()  # HTTP request with Basic Authentication
    headers = {
        "Authorization": f"Basic {auth_string}",
        "Content-Type": "application/json"
    }
    response = requests.post(url, headers=headers)  # Process the response
    # print(response.content)
    # response = {
    #     'status': 200,
    #     'message': 'Request made'
    # }
    return Response(response.content, status=status.HTTP_200_OK)
