import React, { useState, useEffect } from 'react';
import { useDispatch,useSelector  } from "react-redux";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from "primereact/button";
import { Dropdown } from 'primereact/dropdown';   
import { toast } from "react-toastify";
import { updateApp2Dimension, initApp2Dimension, updateinitApp2Dimension } from '../../../../store/sliceReducers/DirectConnectReducer';
import {  updateDimensions } from '../../../../store/sliceReducers/RunImportReducer';
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';
let itemsTofilter=[];
const CustomDropdown = ({ index, rowData, field, options }) => {
  const [selectedOption, setSelectedOption] = useState([]);
  const dispatch = useDispatch();
  const [disabled, setDisabled] = useState(false);
 
  const onOptionChange = (e) => {
    if (e.value !== 'NOT APPLICABLE') {
      if(itemsTofilter.includes(e.value))
      {
        let toaststr= e.value + ' is already tagged'
        toast.info(toaststr)
      }
      else
      {
        setSelectedOption(e.value);
   
        itemsTofilter[index]=e.value;
        
         let payload={index:index, value:e.value}
         dispatch(updateApp2Dimension(payload))
      }
    }
    else
    {
      setSelectedOption(e.value);
      itemsTofilter[index]=e.value;
      let payload={index:index, value:e.value}
      dispatch(updateApp2Dimension(payload))
    }
    
  };
 
  return (
    <Dropdown value={selectedOption} 
              id={"dropdown"+index}
              style={{width:"150px"}}
              options={options} 
              onChange={(e)=>{onOptionChange(e);console.log(options);}} />
  );
};

function DirectConnectTableApp2(props) {

  const dispatch = useDispatch();
  const [disabled, setDisabled] = useState(false);
  const authData = useSelector((state) => state.auth);
  let { data } = authData.data;
  const AccessType = data.access_type.privilege === 0 ? true : false;
  const [dropdownOptions, setDropdownOptions] = useState({});

  const selectedReconId = useSelector(state =>
      state.reconRun.selectedReconRunId
    );


  const dim=useSelector(state =>
    state.reconRun.dimensions.dimensionsimport
  );

  let dimensiontoSend=useSelector(state =>
    state.DirectConnect.DCApp2Dimensions
  );
  
  const DCData=useSelector(state =>
    state.DirectConnect.DCDataApp2
  );
  const fname=useSelector(state =>
    state.DirectConnect.App2file
  );
  const headers=useSelector(state =>
    state.DirectConnect.App2Headers
  );


  let app2dimensions=dim.map((item)=>{
    return (item.app2_is_active? item.app2_dimension.toUpperCase():'')
  })
  app2dimensions=app2dimensions.filter(item=>item);
  app2dimensions.push('NOT APPLICABLE');
  
  useEffect(()=>{
    dispatch(initApp2Dimension(app2dimensions))
    for(let i =0;i<=headers.length;i++)
   {
    itemsTofilter[i]='';
   }
   const options = {};
   headers.forEach((col) => {
     options[col] = app2dimensions.filter((dim) => !itemsTofilter.includes(dim));
   });
   setDropdownOptions(options);
   },[])
  

const saveDimension=()=>{
  
  if((dimensiontoSend.includes('YEAR'))&& (dimensiontoSend.includes('PERIOD'))&&(dimensiontoSend.includes('AMOUNT')))
  {
     setDisabled(true);
     dispatch(updateDimensions({
              "recon_id":selectedReconId,
              "appType":'1',  
              "max_rows":5000,  
              "page_number":1,
              "headers":dimensiontoSend,
              "files":fname}));
     setTimeout(() => {
                setDisabled(false);
              }, 10000); // set timeout for 3 seconds
  }
  else
  {
    toast.info('YEAR, PERIOD, AMOUNT is a required dimension')
  }
}

const renderHeader2 = () => {
  return (
      <div className="flex justify-content-end">
          <Button type="submit" label="Save Dimensions"
                        icon="pi pi-save"
                        className="p-button-success  mx-1 mb-2 bg-primary"
                        tooltipOptions={{ "position": "top" }} tooltip="Save dimension changes"
                        onClick={saveDimension} />
      </div>
  )
}

const header2 = renderHeader2();
  return (
    <DataTable id="DirectConnectTable"
               value={DCData}
               header={header2}
               column
               dataKey="index"
               showGridlines
               scrollable
               scrollDirection="both"
               sortMode="multiple"
               scrollHeight="500px"
              rows={10}
              filterDisplay="menu"
              removableSort
              rowsPerPageOptions={[10, 20, 50]}>
            { 
               headers?.map((col, i) => { 
                    return (<Column field={col} 
                                    header={(rowData) => <CustomDropdown index={i} style={{width:'100%'}}
                                                             rowData={rowData} field="field1"
                                                             options={app2dimensions} />} 
                                    key={i}
                                    style={{ "width": "11%" }}
                                    headerStyle={{margin:'0', padding:'5px 2px',width:'11%'}}
                                    className="ellipsify" />);
})
            }   
</DataTable>
  )
}
export default DirectConnectTableApp2;