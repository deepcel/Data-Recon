import React, { useEffect, useState, useRef } from "react";
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { Dropdown } from 'primereact/dropdown';
import { classNames } from 'primereact/utils';
import { Checkbox } from 'primereact/checkbox';
import { Dialog } from 'primereact/dialog';
import { useFormik } from 'formik';
import { saveDimFields, initDimFields } from '../../../../store/sliceReducers/DimFieldReducer';
import {
    setSelectedReconRunId, listReconRun, listReconRunDimension,
    updateReconRun
} from "../../../../store/sliceReducers/ReconRunReducer";
import { useDispatch, useSelector } from "react-redux";
import DirectLogin from "../direct connect/DirectLogin";
import "./dimensionLinking.scss";

const DimFields = () => {

    const dispatch = useDispatch();
    const isChangeinForm = useRef(false);

    const authData = useSelector((state) => state.auth);
    let { data } = authData.data;
    const AccessType = data.access_type.privilege === 0 ? true : false;
    const [selectedDirConOption, setSelectedDirConOption] = useState(null);
    const [visible, setVisible] = useState(false);
    const selectedImport=useRef(0);
    // state variable to track the visibility of the login screen

  
    const hideLoginScreen = () => {
        setVisible(!visible);
    };

    const importTypeItems = [
        {
            label: 'Source File',
            code: 'File',
            imgsrc: 'assets/images/file-icon.png',
            items: [
                { label: 'File Upload', value: '0' },
            ]
        },
        {
            label: 'Direct Connect',
            code: 'Direct',
            imgsrc: 'assets/images/database-file-icon.webp',
            items: [
                { label: 'FCCS', value: '1' },
                { label: 'PBCS', value: '2' },
                { label: 'OneStream', value: '3' },
                { label: 'HFM', value: '4' }
            ]
        },
    ];
    const groupedImportTypeTemplate = (option) => {
        return (
            <div className="flex align-items-center">
                <img
                    alt={option.label}
                    src={option.imgsrc}
                    className="mr-2 "
                    style={{ width: "18px" }}
                />
                <div>{option.label}</div>
            </div>
        );
    }
    const DirectConnectoptions = [
        { label: 'FCCS', value: 'FCCS' },
        { label: 'PBCS', value: 'PBCS' },
        { label: 'OneStream', value: 'OneStream' },
        { label: 'HFM', value: 'HFM' }
    ];

   
    const reconRunList = useSelector(state =>
        state.reconRun.appData[0]
    );

    const selectedReconId = useSelector(state =>
        state.reconRun.selectedReconRunId
    );

    // const [values, setValues] = React.useState({});

    useEffect(() => {
        if (!reconRunList) {
            dispatch(listReconRun());
        }

        let filteredRecon = reconRunList.find(run => run.recon_id === selectedReconId)
        if (filteredRecon) {
            let clonedRecon = { ...filteredRecon }
            clonedRecon.app1_import_type = !!filteredRecon.app1_import_type ? filteredRecon.app1_import_type : "0";
            clonedRecon.app2_import_type = !!filteredRecon.app2_import_type ? filteredRecon.app2_import_type : "0";
            reconForm.setValues({ ...clonedRecon });
            dispatch(initDimFields({ ...clonedRecon }))
        }

    }, [reconRunList]);

    const reconForm = useFormik({
        initialValues: {},
        validate: (data) => {
            let errors = {};

            if (!data.recon_id) {
                errors.recon_id = 'Recon run name is required.';
            }

            if (!data.app1_import_type) {
                errors.app1_import_type = 'App1 import Type is required.';
            }

            if (!data.app2_import_type) {
                errors.app2_import_type = 'App2 Import Type is required.';
            }

            if (!data.app1_delimiter) {
                errors.app1_delimiter = 'App1 delimiter is required.';
            }

            if (!data.app2_delimiter) {
                errors.app2_delimiter = 'App2 delimiter is required.';
            }

            if (!data.variance_threshold) {
                errors.variance_threshold = 'Variance Threshold is required.';
            }

            if (!data.app1_import_type) {
                errors.app1_import_type = 'App1 import Type is required.';
            }
            return errors;
        },

        onSubmit: (data) => {
            let reconDetails = {
                recon_id: data.recon_id,
                app1_delimiter: data.app1_delimiter,
                app2_delimiter: data.app2_delimiter,
                variance_threshold: data.variance_threshold,
                app1_has_header: data.app1_has_header,
                app2_has_header: data.app2_has_header,
                app1_import_type: data.app1_import_type,
                app2_import_type: data.app2_import_type,
                app1_currency_symbol: data.app1_currency_symbol,
                app1_currency_delimiter: data.app1_currency_delimiter,
                app2_currency_symbol: data.app2_currency_symbol,
                app2_currency_delimiter: data.app2_currency_delimiter,
                dimensions: []
            }
            dispatch(updateReconRun(reconDetails));
            isChangeinForm.current = false;
            reconForm.resetForm();
        }
    });

    const isFormFieldValid = (name) => !!(reconForm.touched[name] && reconForm.errors[name]);
    const getFormErrorMessage = (name) => {
        return isFormFieldValid(name) && <small className="p-error">{reconForm.errors[name]}</small>;
    };

     const ondirConDropdownChange = (e) => {
        setSelectedDirConOption(e.value);
        if(selectedImport.current===1)
        {
            if(e.value==='FCCS')
            {
                reconForm.values.app1_import_type='1'
            }
            else if(e.value==='PBCS')
            {
                reconForm.values.app1_import_type='2'
            }
            else if(e.value==='OneStream')
            {
                reconForm.values.app1_import_type='3'
            }
            else if(e.value==='HFM')
            {
                reconForm.values.app1_import_type='4'
            }
        }
        else {
            if(e.value==='FCCS')
            {
                reconForm.values.app2_import_type='1'
            }
            else if(e.value==='PBCS')
            {
                reconForm.values.app2_import_type='2'
            }
            else if(e.value==='OneStream')
            {
                reconForm.values.app2_import_type='3'
                setVisible(false);
            }
            else if(e.value==='HFM')
            {
                reconForm.values.app2_import_type='4'
                setVisible(false);
            }
        }
       
    }

    const handleFields = (e) => {

        let name = e.target.name;
        let value = e.target.value;
        if (value === 'FCCS' || value === 'PBCS') {
            setSelectedDirConOption(value)
            setVisible(true)
        }
        const data = {
            [name]: value
        }
        dispatch(saveDimFields(data))
        //   dispatch(updateReconRun(savedFields))
    }

    const updateSelectedReconId = (e) => {
        dispatch(setSelectedReconRunId(e.target.value));
        dispatch(listReconRunDimension(e.target.value));
    }

    return (
     <>
       <form onSubmit={reconForm.handleSubmit} className="p-fluid">
          <div className="field p-2 pt-0">
            <div className="formgrid grid">
               <div className="col-6">
                <span className="p-float-label p-input-icon-right">
                 <Dropdown className={classNames({ 'p-invalid': isFormFieldValid('recon_id') }) + " full-width"}
                           optionLabel="name"
                           disabled={!AccessType}
                           name="recon_id"
                           optionValue="recon_id"
                           value={reconForm.values.recon_id}
                           options={reconRunList}
                           onChange={(e) => {reconForm.handleChange(e); updateSelectedReconId(e);}}
                           placeholder="Select Recon RunName"/>
                    <label htmlFor="recon_id" 
                           className={classNames({ 'p-error': isFormFieldValid('recon_id') })}>
                           Select Recon RunName*</label>
                 </span>
               {getFormErrorMessage('recon_id')}
              </div>
              <div className="col-6">
                  <span className="p-float-label p-input-icon-right">
                       <InputText id="variance_threshold" 
                                  name="variance_threshold"
                                  value={!!reconForm.values.variance_threshold ? reconForm.values.variance_threshold : ""}
                                  onChange={(e)=>{reconForm.handleChange(e);handleFields(e)}}
                                  disabled={!AccessType}
                                  className={classNames({ 'p-invalid': isFormFieldValid('variance_threshold') })} placeholder="" />
                     <label htmlFor="variance_threshold" className={classNames({ 'p-error': isFormFieldValid('variance_threshold') })}>Variance Threshold*</label>
                   </span>
                   {getFormErrorMessage('variance_threshold')}
               </div>
             </div>
          </div>
             
          <div className="field p-2 pt-0">
              <div className="formgrid grid">
                  <div className="col-6">
                      <span className="p-float-label p-input-icon-right">
                          <Dropdown className={classNames({ 'p-invalid': isFormFieldValid('app1_import_type') }) + " full-width"}
                                    disabled={!AccessType}
                                    name="app1_import_type"
                                    optionLabel="label"
                                    optionValue="value"
                                    optionGroupLabel="label"
                                    optionGroupChildren="items"
                                    optionGroupTemplate={groupedImportTypeTemplate}
                                    value={reconForm.values.app1_import_type}
                                    options={importTypeItems}
                                    // onChange={(e) => { reconForm.handleChange(e); showLoginScreen(e);handleFields(e) }}
                                    onBlur={(e) => { handleFields(e); }}
                                    onChange={(e) => {
                                        reconForm.handleChange(e);
                                        selectedImport.current=1;
                                        handleFields(e);
                                        if ((e.value === '1') || (e.value === '2')) {
                                           setVisible(true)
                                        }
                                    }}
                                    placeholder="Select App1 Import Type" />
                                <label htmlFor="app1_import_type" className={classNames({ 'p-error': isFormFieldValid('app1_import_type') })}>App1 Import Type*</label>
                            </span>
                            {getFormErrorMessage('app1_import_type')}
                            <Dialog header="Direct Connect" visible={visible}
                                onHide={hideLoginScreen} style={{ width: '28vw' }}>
                                <div className="flex justify-content-center">
                                    <div className="card" style={{ width: '40vw' }}>
                                        <Dropdown options={DirectConnectoptions}
                                            disabled={!AccessType}
                                            value={selectedDirConOption}
                                            onChange={(e) => { reconForm.handleChange(e); ondirConDropdownChange(e) }} placeholder="Select an option" />
                                        <DirectLogin connectOption={selectedDirConOption}
                                                     apptype={selectedImport.current}
                                                     visiblity={hideLoginScreen} />
                                    </div>
                                </div>
                            </Dialog>
                        </div>
                        <div className="col-6">
                            <span className="p-float-label p-input-icon-right">
                                <Dropdown className={classNames({ 'p-invalid': isFormFieldValid('app2_import_type') }) + " full-width"}
                                    name="app2_import_type"
                                    optionLabel="label"
                                    optionValue="value"
                                    optionGroupLabel="label"
                                    optionGroupChildren="items"
                                    optionGroupTemplate={groupedImportTypeTemplate}
                                    disabled={!AccessType}
                                    value={reconForm.values.app2_import_type}
                                    options={importTypeItems}
                                    // onChange={(e) => { reconForm.handleChange(e); showLoginScreen(e);handleFields(e) }}
                                    onBlur={(e) => { handleFields(e); }}
                                    onChange={(e) => {
                                        reconForm.handleChange(e);
                                        selectedImport.current=2;
                                        handleFields(e);
                                        if ((e.value === '1') || (e.value === '2')) {
                                            setVisible(true)
                                        }
                                    }}
                                    placeholder="Select App2 Import Type" />
                                <label htmlFor="app2_import_type" className={classNames({ 'p-error': isFormFieldValid('app2_import_type') })}>App2 Import Type*</label>
                            </span>
                            {getFormErrorMessage('app2_import_type')}
                        </div>
                    </div>
          </div>
          <div className="field p-2">
                    <div className="formgrid grid">
                        <div className="col-6">
                            <span className="p-float-label p-input-icon-right">
                                <InputText id="app1_delimiter"
                                    name="app1_delimiter"
                                    disabled={!AccessType}
                                    value={!!reconForm.values.app1_delimiter ? reconForm.values.app1_delimiter : ""}
                                    onChange={(e) => { reconForm.handleChange(e); handleFields(e) }}
                                    className={classNames({ 'p-invalid': isFormFieldValid('app1_delimiter') })} placeholder="App1 Delimiter" />
                                <label htmlFor="app1_delimiter" className={classNames({ 'p-error': isFormFieldValid('app1_delimiter') })}>App1 Delimiter*</label>
                            </span>
                            {getFormErrorMessage('app1_delimiter')}
                        </div>
                        <div className="col-6">
                            <span className="p-float-label p-input-icon-right">
                                <InputText id="app2_delimiter"
                                    name="app2_delimiter"
                                    disabled={!AccessType}
                                    value={!!reconForm.values.app2_delimiter ? reconForm.values.app2_delimiter : ""}
                                    onChange={(e) => { reconForm.handleChange(e); handleFields(e) }}
                                    className={classNames({ 'p-invalid': isFormFieldValid('app2_delimiter') })} placeholder="App2 Delimiter" />
                                <label htmlFor="app2_delimiter" className={classNames({ 'p-error': isFormFieldValid('app2_delimiter') })}>App2 Delimiter*</label>
                            </span>
                            {getFormErrorMessage('app2_delimiter')}
                        </div>
                    </div>
          </div>
          <div className="field p-2">
                    <div className="formgrid grid">
                        <div className="col-6">
                            <span className="p-float-label p-input-icon-right">
                                <InputText id="app1_currency_symbol"
                                    name="app1_currency_symbol"
                                    disabled={!AccessType}
                                    value={!!reconForm.values.app1_currency_symbol ? reconForm.values.app1_currency_symbol : ""}
                                    onChange={(e) => { reconForm.handleChange(e); handleFields(e) }}
                                    className={classNames({ 'p-invalid': isFormFieldValid('app1_currency_symbol') })} placeholder="Remove app1 currency symbol" multiple="true" delimiter="," />
                                <label htmlFor="app1_currency_symbol" className={classNames({ 'p-error': isFormFieldValid('app1_currency_symbol') })}>Remove app1 currency symbol*</label>
                            </span>
                            {getFormErrorMessage('app1_currency_symbol')}
                        </div>
                        <div className="col-6">
                            <span className="p-float-label p-input-icon-right">
                                <InputText id="app2_currency_symbol"
                                    name="app2_currency_symbol"
                                    disabled={!AccessType}
                                    value={!!reconForm.values.app2_currency_symbol ? reconForm.values.app2_currency_symbol : ""}
                                    onChange={(e) => { reconForm.handleChange(e); handleFields(e) }}
                                    className={classNames({ 'p-invalid': isFormFieldValid('app2_currency_symbol') })} placeholder="Remove app2 currency symbol" multiple="true" delimiter="," />
                                <label htmlFor="app2_currency_symbol" className={classNames({ 'p-error': isFormFieldValid('app2_currency_symbol') })}>Remove app2 currency symbol*</label>
                            </span>
                            {getFormErrorMessage('app2_currency_symbol')}
                        </div>
                    </div>
          </div>
          <div className="field p-2">
                    <div className="formgrid grid">
                        <div className="col-6">
                            <span className="p-float-label p-input-icon-right">
                                <InputText id="app1_currency_delimiter"
                                    name="app1_currency_delimiter"
                                    disabled={!AccessType}
                                    value={!!reconForm.values.app1_currency_delimiter ? reconForm.values.app1_currency_delimiter : ""}
                                    onChange={(e) => { reconForm.handleChange(e); handleFields(e) }}
                                    className={classNames({ 'p-invalid': isFormFieldValid('app1_currency_delimiter') })} placeholder="Remove app1 currency delimiter" />
                                <label htmlFor="app1_currency_delimiter" className={classNames({ 'p-error': isFormFieldValid('app1_currency_delimiter') })}>Remove app1 currency delimiter*</label>
                            </span>
                            {getFormErrorMessage('app1_currency_delimiter')}
                        </div>
                        <div className="col-6">
                            <span className="p-float-label p-input-icon-right">
                                <InputText id="app2_currency_delimiter"
                                    name="app2_currency_delimiter"
                                    disabled={!AccessType}
                                    value={!!reconForm.values.app2_currency_delimiter ? reconForm.values.app2_currency_delimiter : ""}
                                    onChange={(e) => { reconForm.handleChange(e); handleFields(e) }}
                                    className={classNames({ 'p-invalid': isFormFieldValid('app2_currency_delimiter') })} placeholder="Remove app2 currency delimiter" />
                                <label htmlFor="app2_currency_delimiter" className={classNames({ 'p-error': isFormFieldValid('app2_currency_delimiter') })}>Remove app2 currency delimiter*</label>
                            </span>
                            {getFormErrorMessage('app2_currency_delimiter')}
                        </div>
                    </div>
          </div>
          <div className="field p-2">
                    <div className="formgrid grid">
                        <div className="col-6">
                            <label className="mb-2">APP 1 Has Header</label>
                            <Checkbox className="ml-2" name="app1_has_header"
                                disabled={!AccessType}
                                onChange={(e) => { reconForm.handleChange(e); handleFields(e) }}
                                checked={reconForm.values.app1_has_header}></Checkbox>
                        </div>
                        <div className="col-6">
                            <label className="mb-3 pr-2">APP 2 Has Header</label>
                            <Checkbox className="ml-2" name="app2_has_header"
                                disabled={!AccessType}
                                onChange={(e) => { reconForm.handleChange(e); handleFields(e) }}
                                checked={reconForm.values.app2_has_header}></Checkbox>
                        </div>
                    </div>
          </div>
          <div className="field p-2 ">
              <div className="formgrid grid">
                   <div className=" col-offset-10 col-2 ">
                                        <Button type="submit" label="Save Recon Details"
                                            disabled={!AccessType} 
                                            className="p-button-success  bg-primary" 
                                            tooltipOptions={{ "position": "top" }} 
                                            tooltip="Save Recon Details" />
                   </div>
               </div>
         </div>
       </form>
     </>  
    );
}
export default DimFields;