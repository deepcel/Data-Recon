import { createSlice } from "@reduxjs/toolkit";
import { toast } from "react-toastify";
import {
  makePostAPICall,
  makePutAPICall,
  makePutAPIFormData,
  makePostAPICallFileDownload,
} from "../../utils/apiService";
import { redirectToLogin } from "../../utils/utils";
import { enableLoader, hideLoader } from "./LoadReducer";

// Dashboard reducer is used for handle all the steps data
export const runBridgeReducer = createSlice({
  name: "runBridge",
  initialState: {
    loading: false,
    error: null,
    runBridge: {
      headers: [],
      rows: [],
      unMapped: [],
      jeheaders: [],
      jerows: [],
      unMappedJE: [],
    },
  },
  reducers: {
    isLoading: (state) => {
      state.loading = true;
    },
    INVALID_SESSION: (state) => {
      state.loading = false;
      state.error = null;
    },
    RECON_LOAD_RUN_BRIDGE: (state, action) => {
      state.loading = false;
      state.error = null;
      state.runBridge.headers = [...action.payload.response.headers];
      state.runBridge.rows = [...action.payload.response.rows];
    },
    RECON_LOAD_RUN_BRIDGE_JE: (state, action) => {
      state.loading = false;
      state.error = null;
     
        state.runBridge.jeheaders = [...action.payload.response.headers];
        state.runBridge.jerows = [...action.payload.response.rows];
     
     
      
    },
    RECON_LOAD_BRIDGE_UNMAPPED: (state, action) => {
      state.loading = false;
      state.error = null;
      state.runBridge.unMapped = [...action.payload.response.rows];
    },
    RECON_LOAD_BRIDGE_UNMAPPED_JE: (state, action) => {
      state.loading = false;
      state.error = null;
      state.runBridge.unMappedJE = [...action.payload.response.rows];
    },
    RECON_REMOVE_UNMAPPED_ITEM: (state, action) => {
      state.loading = false;
      state.error = null;
      state.runBridge.unMapped = state.runBridge.unMapped.filter(
        (item) => item.out_id !== action.payload.response.rows[0].out_id
      );
    },
    RECON_REMOVE_UNMAPPEDJE_ITEM: (state, action) => {
      state.loading = false;
      state.error = null;
      state.runBridge.unMappedJE = state.runBridge.unMappedJE.filter(
        (item) => item.out_id !== action.payload.response.rows[0].out_id
      );
    },
  },
});

export const {
  isLoading,
  INVALID_SESSION,
  RECON_LOAD_RUN_BRIDGE,
  RECON_LOAD_RUN_BRIDGE_JE,
  RECON_LOAD_BRIDGE_UNMAPPED,
  RECON_LOAD_BRIDGE_UNMAPPED_JE,
  RECON_REMOVE_UNMAPPED_ITEM,
  RECON_REMOVE_UNMAPPEDJE_ITEM,
} = runBridgeReducer.actions;

export const updateUnMappedBridge = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPICall("bridge/outs/update", payload);
    if (response.status === 200) {
      dispatch(
        RECON_REMOVE_UNMAPPED_ITEM({
          response: payload,
        })
      );
      dispatch(
        bridgeRun({
          recon_id: payload.recon_id,
          max_rows: 100,
          page_number: 1,
          je_flag: false,
        })
      );
      toast.success("Unmapped kickouts updated successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const updateUnMappedBridgeJE = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPICall("bridge/outs/update", payload);
    if (response.status === 200) {
      dispatch(
        RECON_REMOVE_UNMAPPEDJE_ITEM({
          response: payload,
        })
      );
      dispatch(
        bridgeRun({
          recon_id: payload.recon_id,
          max_rows: 100,
          page_number: 1,
          je_flag: true,
        })
      );
      toast.success("Unmapped kickouts updated successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

// export const exportrunbridge = (payload) => async (dispatch) => {
//   try {
//     dispatch(isLoading({ loading: true }));
//     const response = await makePostAPICallFileDownload(
//       "bridge/run/export/",
//       payload
//     );
//     if (response.status === 200) {
//       toast.success("Download triggered successfully");
//     } else if (response.status === 401) {
//       dispatch(INVALID_SESSION(response));
//       redirectToLogin();
//     } else {
//       toast.error(response.message);
//     }
//     dispatch(hideLoader());
//   } catch (err) {
//     dispatch(hideLoader());
//   }
// };

export const unMappedKickoutImport =
  (formData, reconId) => async (dispatch) => {
    try {
      dispatch(enableLoader());
      const response = await makePutAPIFormData("bridge/outs/import", formData);
      if (response.status === 200) {
        dispatch(
          bridgeRun({
            recon_id: reconId,
            max_rows: 100,
            page_number: 1,
            je_flag: false,
          })
        );
        toast.success("File imported successfully");
      } else if (response.status === 401) {
        dispatch(INVALID_SESSION(response));
        redirectToLogin();
      } else {
        toast.error(response.message);
      }
      dispatch(hideLoader());
    } catch (err) {
      dispatch(hideLoader());
    }
  };

export const unMappedKickoutImportJE =
  (formData, reconId) => async (dispatch) => {
    try {
      dispatch(enableLoader());
      const response = await makePutAPIFormData("bridge/outs/import", formData);
      if (response.status === 200) {
        dispatch(
          bridgeRunJE({
            recon_id: reconId,
            max_rows: 100,
            page_number: 1,
            je_flag: true,
          })
        );
        toast.success("File imported successfully");
      } else if (response.status === 401) {
        dispatch(INVALID_SESSION(response));
        redirectToLogin();
      } else {
        toast.error(response.message);
      }
      dispatch(hideLoader());
    } catch (err) {
      dispatch(hideLoader());
    }
  };

export const downloadUnMappedKickoutFile = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePostAPICallFileDownload(
      "bridge/outs/export",
      payload
    );
    if (response.status === 200) {
      toast.success("Download triggered successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const downloadRunBridge = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePostAPICallFileDownload(
      "bridge/run/export/",
      payload
    );
    if (response.status === 200) {
      // dispatch(RUN_IMPORT_UPDATE({
      //     response: response,
      //     appType: appType
      // }));
      toast.success("Download triggered successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const listBridgeUnMapped = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePostAPICall("bridge/outs", payload);
    if (response.status === 200) {
      dispatch(RECON_LOAD_BRIDGE_UNMAPPED({ response: response }));
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const listBridgeUnMappedJE = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePostAPICall("bridge/outs", payload);
    if (response.status === 200) {
      dispatch(RECON_LOAD_BRIDGE_UNMAPPED_JE({ response: response }));
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const bridgeRun = (payload) => async (dispatch) => {
  try {
    
    const response = await makePostAPICall("bridge/run", payload);
    dispatch(enableLoader());
    if (response.status === 200) {
      dispatch(RECON_LOAD_RUN_BRIDGE({ response: response }));
      dispatch(
        listBridgeUnMapped({ recon_id: payload.recon_id, je_flag: false })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

//JE Runbridge
export const bridgeRunJE = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePostAPICall("bridge/run", payload);
    if (response.status === 200) {
      dispatch(RECON_LOAD_RUN_BRIDGE_JE({ response: response }));
      dispatch(
        listBridgeUnMappedJE({ recon_id: payload.recon_id, je_flag: true })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export default runBridgeReducer.reducer;
