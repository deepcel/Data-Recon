import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
    defaultAPIcall,
    listBridgeMembers, listComments, listJEComments, listDimension
} from "../../../../store/sliceReducers/BridgeMemberReducer";
import SampleBridgeTemplate from "./SampleBridgeTemplate";
import SampleCommentsTemplate from "./SampleCommentsTemplate";
import BridgeFile from "./BridgeFile";
import CommentsFile from "./CommentsFile";
//import JECommentsFile from "./JECommentFiles";
import BridgeApp1Table from "./BridgeApp1Table";
import BridgeApp2Table from "./BridgeApp2Table";
import CommentsTable from "./CommentsTable";
//import JECommentsTable from "./JECommentsTable";
import { Button } from "primereact/button";
import { Card } from "primereact/card";
import { Message } from 'primereact/message';
import IconButton from '@mui/material/IconButton';
import InfoIcon from '@mui/icons-material/Info';
import "./bridgeMembers.scss";

const BridgeMember = () => {

    const dispatch = useDispatch();
    const [reconRunName, setReconRunName] = useState("");
    const [ShowMessage, setShowMessage] = useState(false);
    const [loading1, setLoading1] = useState(false);
    const authData = useSelector((state) => state.auth);
    let { data } = authData.data;
    const AccessType = data.access_type.privilege === 0 ? true : false;


    const onLoadingClick1 = () => {
        setLoading1(true);
        dispatch(defaultAPIcall(
            {
                "recon_id": selectedReconId,
            }));
        setTimeout(() => {
            setLoading1(false);
        }, 2000);
    }

    const reconRunList = useSelector(state =>
        state.reconRun.appData[0]
    );

    const selectedReconId = useSelector(state =>
        state.reconRun.selectedReconRunId
    );

    useEffect(() => {
        let filteredRecon = reconRunList.find(run => run.recon_id === selectedReconId)
        if (filteredRecon) {
            setReconRunName(filteredRecon.name)
            dispatch(listBridgeMembers(selectedReconId));
            dispatch(listDimension(selectedReconId));
            dispatch(listComments(selectedReconId));
            dispatch(listJEComments(selectedReconId));
        }
    }, [])

    const MessageContent = () => {
        return (
            <React.Fragment>
                <span>Files delimited with (,), (;), (|) in .csv or .txt format accepted for import</span>
            </React.Fragment>
        )
    }

    return (
        <React.Fragment>
            <Card className="shadow-5">
                <div className="card pt-0">
                    {
                        !reconRunName && <div className="text-center text-pink-500">
                            Please select recon and click bridge members tab
                        </div>
                    }
                    {
                        !!reconRunName && <React.Fragment>

                            <div className="formgrid grid" style={{ marginTop: '-8px' }}>
                                <div className="col-6">
                                    Recon RunName: <span className="font-bold">{reconRunName} </span><br></br>
                                </div>

                                <div className="col-5 card flex justify-content-end mt-2">
                                    {ShowMessage && <Message style={{ marginTop: '-28px' }} text={MessageContent} />}
                                </div>

                                <div className="col-1 text-right">
                                    <IconButton aria-label="delete"
                                        sx={{ marginTop: '-10px', color: '#ef5350' }}
                                        onClick={() => setShowMessage(!ShowMessage)}>
                                        <InfoIcon />
                                    </IconButton>
                                </div>

                            </div>
                            <div className="formgrid grid">
                                <div className="col-6">
                                    <Button label="Default source members to bridge members" icon="pi pi-copy"
                                        disabled={!AccessType}
                                        loading={loading1}
                                        onClick={onLoadingClick1}
                                        className="my-3 bg-primary"
                                        title="pull in the source members to the bridge members" />
                                    {/* <label htmlFor="binary">&nbsp;Default source members to bridge members</label> */}
                                </div>
                            </div>
                            <SampleBridgeTemplate />
                            <div className="field p-2">
                                <BridgeFile />
                            </div>
                            <div className="formgrid grid p-2">
                                <div className="col-6">
                                    <BridgeApp1Table />
                                </div>
                                <div className="col-6 text-right">
                                    <BridgeApp2Table />
                                </div>
                            </div>
                            <br />
                            <br />
                            <div className="field p-2">
                                <div className="field">
                                    <span className="font-bold">ADD COMMENTS TO SOURCE MEMBERS</span>
                                </div>
                                <SampleCommentsTemplate />
                                <CommentsFile />
                                <CommentsTable />
                            </div>

                            {/* <div className="field p-2">
                                <div className="field">
                                    <span className="font-bold">ADD JOURNAL ENTRY COMMENTS TO SOURCE MEMBERS</span>
                                </div>
                                <JECommentsFile/>          
                                <JECommentsTable/>
                               
                            </div> */}
                        </React.Fragment>
                    }
                </div>
            </Card>

        </React.Fragment>
    )
}
export default BridgeMember;