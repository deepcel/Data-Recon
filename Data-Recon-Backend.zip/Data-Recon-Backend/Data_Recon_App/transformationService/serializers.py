from rest_framework import serializers
from .. models import ReconTransformation, \
    ReconTransformationOverride, ReconDimensions, ReconBridgeMapping


class TransformationSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReconTransformation
        fields = ['id', 'recon_id', 'app_id', 'dim_id', 'tgt_concat_dimid',
                  'tgt_concat_dimname', 'concat_delimiter', 'apply_all_members']


class TransOverrideSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReconTransformationOverride
        fields = ['id', 'recon_id', 'app_id', 'tfn_id',
                  'source_sync', 'target_sync', 'flip_sign']


class DimIdCombinations(serializers.ModelSerializer):
    class Meta:
        model = ReconDimensions
        fields = ['turn_on_define_order', 'dimensions_id']

    def to_representation(self, instance):
        return {
            instance.turn_on_define_order: instance.dimensions_id,
            'app_type': instance.app_type
        }


class BridgeSourceSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReconBridgeMapping
        fields = ['source_member']


class DimensionNameSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReconDimensions
        fields = ['dimensions_id', 'dimension']
