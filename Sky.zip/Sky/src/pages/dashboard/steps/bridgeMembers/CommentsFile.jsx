import React, { useState,useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Button } from "primereact/button";
import { FileUpload } from 'primereact/fileupload';
import { toast } from "react-toastify";
import { commentsImport } from "../../../../store/sliceReducers/BridgeMemberReducer";
import {
  getExtension, chooseOptions,
  uploadOptions, cancelOptions
} from "../../../../utils/fileutils";
import "./bridgeMembers.scss";

const CommentsFile = (props) => {

  const dispatch = useDispatch();
  const authData = useSelector((state) => state.auth);
  let { data } = authData.data;
  const fileUploadRef = useRef(null);
  const AccessType = data.access_type.privilege === 0 ? true : false;

  const [totalSizecomment, setTotalSizecomment] = useState(0);

  const selectedReconId = useSelector(state =>
    state.reconRun.selectedReconRunId
  );

  const onTemplateRemovecomment = (file, callback) => {
    setTotalSizecomment(totalSizecomment - file.size);
    callback();
  };

  const itemTemplatecomment = (file, props) => {
    return (
      <div className="flex justify-content-between ">
        <div className="flex align-items-center" style={{ width: "40%" }}>
          <span className="flex flex-column text-left ml-3">{file.name}</span>
        </div>
        <Button
          icon="pi pi-times"
          className="p-button-secondary"
          onClick={() => onTemplateRemovecomment(file, props.onRemove)} />
      </div>
    );
  };

  const commentFile = (files) => {
    const supportedFileFormat = ["csv", "txt"];
    const [file] = files;
    if (file) {
      if (!supportedFileFormat.includes(getExtension(file.name))) {
        toast.error("Unsupported file format, Please upload valid files(.csv,.txt)");
        return;
      }
    }
    const fileReader = new FileReader();
    fileReader.onload = (e) => {
      let formData = new FormData();
      formData.append('comments_file', file);
      formData.append('recon_id', selectedReconId);
      dispatch(commentsImport(formData));
      fileUploadRef.current.clear(); 
    };
    fileReader.readAsDataURL(file);
  }

  const commentsFileUpload = ({ files }) => {
    commentFile(files);
  };

  return (
    <>
      <div className="col-12">
        <FileUpload accept=".csv, .txt"
        ref={fileUploadRef}
          disabled={!AccessType}
          maxFileSize={100000000}
          customUpload
          chooseOptions={chooseOptions}
          uploadOptions={uploadOptions}
          cancelOptions={cancelOptions}
          itemTemplate={itemTemplatecomment}
          uploadHandler={commentsFileUpload}
          emptyTemplate={<p className="m-0">Drag and drop files to here to upload.</p>} />
      </div>
    </>
  )
}
export default CommentsFile;