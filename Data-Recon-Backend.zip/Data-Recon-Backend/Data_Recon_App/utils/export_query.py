from django.db import connections


def dim_query(recon_id):
    query = "SELECT ROW_NUMBER() OVER (ORDER BY q.turn_on_define_order) -1 AS serial_no, q.dimension1, q.dim1_in_file, q.yes_type_field1," \
            " q.no_type_field2, q.is_active1, q.dimension2, q.dim2_in_file, q.yes_type_field2, q.no_type_field2, q.is_active2 " \
            "FROM (SELECT DISTINCT rd1.dimension AS dimension1, rd1.dim_in_file AS dim1_in_file, rd1.type_field AS yes_type_field1," \
            "CASE WHEN rd1.type_field IS NOT NULL THEN rd1.top_member ELSE NULL END AS no_type_field1," \
            "CASE WHEN rd1.is_active THEN 'TRUE' ELSE 'FALSE' END AS is_active1, rd2.dimension AS dimension2, " \
            "rd2.dim_in_file AS dim2_in_file, rd2.type_field AS yes_type_field2, CASE WHEN rd2.type_field IS NOT NULL " \
            "THEN rd2.top_member ELSE NULL END AS no_type_field2, CASE WHEN rd2.is_active THEN 'TRUE' ELSE 'FALSE' END AS is_active2," \
            " rd1.turn_on_define_order::integer FROM  fileservice.recon_dimensions rd1 INNER JOIN fileservice.recon_dimensions rd2 " \
            " ON rd1.recon_id = rd2.recon_id AND rd1.app_type = '0' AND rd2.app_type = '1' AND rd1.turn_on_define_order = rd2.turn_on_define_order  WHERE " \
            "rd1.recon_id = "+str(recon_id)+" AND rd1.is_active AND rd2.is_active AND NOT rd1.is_deleted AND NOT rd2.is_deleted ORDER BY " \
            "rd1.turn_on_define_order::integer) q"

    return query


def bridge_query(recon_id, app_type):
    query = "select rd.dimension,rbm.source_member,case when rbm.flip_sign then 'YES' " \
                    "else 'NO' end as flip_sign,rbm.bridge_member from fileservice.recon_bridge_mapping" \
                    " rbm inner join fileservice.recon_dimensions rd on rbm.recon_id = rd.recon_id and" \
                    " rbm.app_id = rd.recon_app_id and rbm.dim_id = rd.dimensions_id where" \
                    " rbm.recon_id = "+str(recon_id)+" and rd.app_type = '"+str(app_type)+"' and not rbm.is_deleted and not rbm.is_invalid"
    return query


def comment_query(recon_id):
    query = "select app_type, dimension, source_member, user_comment from (select \'BRIDGE\'" \
                " as app_type, rd.dimension, rbm.source_member, rbm.dim_comment as user_comment" \
                " from fileservice.recon_bridge_mapping rbm inner join fileservice.recon_dimensions" \
                " rd on rbm.recon_id = rd.recon_id and rbm.app_id = rd.recon_app_id and" \
                " rbm.dim_id = rd.dimensions_id where rbm.recon_id = "+str(recon_id)+" and" \
                " (rbm.dim_comment <> \'\' or rbm.dim_comment is not null)" \
                " and not rbm.is_deleted and not rbm.is_invalid union select case when" \
                " rd.app_type = \'0\' then \'APP1\' else \'APP2\' end as app_type,rd.dimension,rbm.source_member," \
                "rbm.bridge_comment as user_comment from fileservice.recon_bridge_mapping rbm" \
                " inner join fileservice.recon_dimensions rd on rbm.recon_id = rd.recon_id and" \
                " rbm.app_id = rd.recon_app_id and rbm.dim_id = rd.dimensions_id where" \
                " rbm.recon_id = "+str(recon_id)+" and (rbm.bridge_comment <> \'\' or rbm.bridge_comment" \
                " is not null) and not rbm.is_deleted and not rbm.is_invalid)q"
    return query


def bridge_kick_out_query(recon_id, je_flag):
    if je_flag:
        query = "select case when app_id=0 then \'APP1\' else \'APP2\' end as APP_TYPE,source_member," \
                        " \'\' as bridge_member from fileservice.view_bridge_je_" + str(recon_id) + "_kickout"
    else:
        query = "select case when app_id=0 then \'APP1\' else \'APP2\' end as APP_TYPE,source_member," \
                        " \'\' as bridge_member from fileservice.view_bridge_" + str(recon_id) + "_kickout"
    return query

def run_bridge_export_query(recon_id, je_flag):
    #Constructing headers for query
    ini_query = "select string_agg('\"' || c.column_name || '\"', ',') from information_schema.\"columns\"" \
                " c where c.table_schema = 'fileservice' and c.table_name = 'bridge_' ||" \
                " case when " + str(je_flag) + " then 'je_' else '' end || '" + str(recon_id) + "' and c.column_name" \
                                                                                                " not in ('kickout','app_id', 'file_name', 'file_id', case when " + str(
        je_flag) + " then" \
                   " 'je_comment' else 'user_comment' end)"
    cursor = connections['Recon'].cursor()
    cursor.execute(ini_query)
    cursor = cursor.fetchone()
    cursor = ','.join(map(str, cursor)).split(",")
    headers = ""
    for x in range(len(cursor)):
        headers += "\\\"" + cursor[x] + "\\\""
        if x < len(cursor) - 1:
            headers += ","

    query = "select case when ra.app_name ='0' then 'APP1' else 'APP2' end as " + headers + " from fileservice.bridge_" + str(
        recon_id) + \
            " b inner join fileservice.recon_applications ra on b.app_id = ra.recon_app_id"
    return query

def export_source_data_query(recon_id, je_flag):
    ini_query = "select string_agg(col, ',') from (select '\"'||rd1.dimension||'-'||rd2.dimension||'\"'" \
                " as col from fileservice.recon_dimensions rd1 inner join fileservice.recon_dimensions" \
                " rd2 on rd1.turn_on_define_order =rd2.turn_on_define_order and rd1.recon_id=rd2.recon_id and" \
                " rd2.app_type ='1' where rd1.recon_id =" + str(
        recon_id) + " and rd1.app_type ='0' and rd1.is_active and not" \
                    " rd1.is_deleted order by rd1.type_field ::integer)q"

    cursor = connections['Recon'].cursor()
    cursor.execute(ini_query)
    cursor = cursor.fetchone()
    cursor = ','.join(map(str, cursor)).split(",")
    headers = ""

    for x in range(len(cursor)):
        headers += "\\\"" + cursor[x] + "\\\""
        if x < len(cursor) - 1:
            headers += ","

    if je_flag:
        query = "select " + headers + " from fileservice.view_je_" + str(recon_id)
    else:
        query = "select " + headers + " from fileservice.view_" + str(recon_id)
    return query

def run_trans_export_query(recon_id):
    ini_query = "select string_agg('\"' || c.column_name || '\"', ',') from information_schema.\"columns\"" \
                " c where c.table_schema = 'fileservice' and c.table_name = 'bridgesync_' || '" + str(recon_id) \
                + "' and c.column_name not in ('kickout','app_id', 'file_name', 'file_id')"
    cursor = connections['Recon'].cursor()
    cursor.execute(ini_query)
    cursor = cursor.fetchone()
    cursor = ','.join(map(str, cursor)).split(",")
    headers = ""
    for x in range(len(cursor)):
        headers += "\\\"" + cursor[x] + "\\\""
        if x < len(cursor) - 1:
            headers += ","

    query = "select case when ra.app_name ='0' then 'APP1' else 'APP2' end as " + headers + \
            " from fileservice.bridgesync_" + str(recon_id) + " b inner join fileservice.recon_applications" \
                                                              " ra on b.app_id = ra.recon_app_id"
    return query