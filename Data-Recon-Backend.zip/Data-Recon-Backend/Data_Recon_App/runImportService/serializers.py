from rest_framework import serializers
from .. models import ReconDimensions


class DimensionCombinations(serializers.ModelSerializer):
    class Meta:
        model = ReconDimensions
        fields = ['turn_on_define_order', 'dimension']

    def to_representation(self, instance):
        return {
            instance.turn_on_define_order: instance.dimension,
            'app_type': instance.app_type
        }


class DimensionNameSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReconDimensions
        fields = ['dimension', 'type_field']
