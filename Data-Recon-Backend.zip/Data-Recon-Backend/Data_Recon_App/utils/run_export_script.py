from django.conf import settings
import subprocess
import shlex
import os


def run_export_script(recon_id, file_name, query):

    # creating the folder if it does not exist
    folder_path = os.path.join(settings.MEDIA_ROOT, str(recon_id))
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)

    export_path = folder_path + "/export"
    if not os.path.exists(export_path):
        os.makedirs(export_path)

    # print(os.name)
    if os.name=='nt':
        # print('Windows')
        query = query.replace('"','\\\"')
        args_in = shlex.split('psql -U user_dataRecon_file -d db_dataRecon -c "copy ('+query+') to \''+os.path.join(settings.MEDIA_ROOT,str(recon_id)+'\\export\\'+file_name)+'\' with delimiter \',\' NULL \'\' csv HEADER"')
        # Calling the Shell script
        subprocess.run(args_in,shell=True,capture_output=False)
    else:
        # print('Not Windows')
        #query = query.replace('"','\\\"')
        #print(query)
        # Changing the permissions for the file
        subprocess.call(["chmod 777 " + settings.MEDIA_ROOT + "/" + str(recon_id) + "/export"], shell=True)
        # Calling the Shell script
        p = subprocess.Popen([settings.MEDIA_ROOT + '/run_all_scripts.sh -u postgres -f /home/ubuntu/Recon_Files/media/' + str(recon_id) + '/export/' + file_name + ' -e -q "' + str(query) + '"'], shell=True)
        p.wait()
    
    # print('Success') if p==0 else print('Failed')
