import React,{useState} from "react";
import {
    getDirectConnectSourceData,DCDialogApp1
} from "../../../../store/sliceReducers/DirectConnectReducer";
import { useDispatch, useSelector } from "react-redux";
import "./runImport.scss";
import { Button } from "primereact/button";
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';
import { useFormik } from 'formik';
import { classNames } from 'primereact/utils';
import { InputText } from 'primereact/inputtext';
import { Dialog } from 'primereact/dialog';
import { getEmail } from '../../../../utils/utils';
import App2Job from "./App2job";
import OSExtracApp2 from "./OsExtractApp2";
import App2FileUpload from "./App2FileUpload";
import DirectConnectTableApp1 from "../direct connect/DirectConnectTableApp1";

const App2SourceFile = () => {
   
    const app2_Import_type=useSelector(state =>
        state.dimField.reconDetails.app2_import_type
      );
    
    let showfileUpload1=app2_Import_type==='0'?true:false;
    let showJob1=((app2_Import_type==='1') ||(app2_Import_type==='2')) ?true:false;
    let showOneStream1=app2_Import_type==='3'?true:false;
    return (
        <>
          {showfileUpload1 && <App2FileUpload/>}
           {showJob1 && <App2Job/>}
           {showOneStream1 &&<OSExtracApp2/>} 
        </>
    )
}
export default App2SourceFile;