DROP DATABASE if exists db_dataRecon;
CREATE DATABASE "db_dataRecon"
    WITH 
    OWNER = postgres
    ENCODING = 'UTF8'
    LC_COLLATE = 'English_United States.1252'
    LC_CTYPE = 'English_United States.1252'
    TABLESPACE = tbsp_data_recon
    CONNECTION LIMIT = -1;