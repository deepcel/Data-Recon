from django.template.loader import get_template
from django.core.mail import EmailMessage
from django.conf import settings


def send_mail(mail, subject, content):
    message = get_template('mail_template.html').render(content)
    msg = EmailMessage(
        subject,
        message,
        settings.EMAIL_HOST_USER,
        [mail],
    )
    msg.content_subtype = "html"
    msg.send()
