import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import {
    updateBridgeMember, deleteBridgeMember, downloadBridgeMember
} from "../../../../store/sliceReducers/BridgeMemberReducer";
import { Button } from "primereact/button";
import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { ConfirmPopup, confirmPopup } from 'primereact/confirmpopup';
import { InputText } from 'primereact/inputtext';
import { Dropdown } from 'primereact/dropdown';
import { FilterMatchMode, FilterOperator } from 'primereact/api';
import "./bridgeMembers.scss";

const BridgeApp2Table = () => {
    
    const dispatch = useDispatch();
    const [editingRows, setEditingRows] = useState({});
    const [globalFilterValue2, setGlobalFilterValue2] = useState('');
    const [filters2, setFilters2] = useState(null);

    const authData = useSelector((state) => state.auth);
    let { data } = authData.data;
    const AccessType = data.access_type.privilege === 0 ? true : false; 

    const applyFligSign = [
        { label: 'YES', value: "YES" },
        { label: 'NO', value: "NO" }
    ];

    const selectedReconId = useSelector(state =>
        state.reconRun.selectedReconRunId
    );

    const bridgeMembers = useSelector(state =>
        state.bridgeMember.bridgeMembers
    );

    const dimensions = useSelector(state =>
        state.bridgeMember.dimensions
    );

    const rowClassApp2 = (data) => {
        return {
            'bg-red-100': validateInValidDimension(data.dim_id, dimensions.app2Dimension, false)
        }
    }
   
    const validateInValidDimension = (dimId, dimension, isFromComment) => {
        if (dimId === null || !dimId) {
            return true;
        }
        else if (!!dimId) {
            if (isFromComment) {
                const app1DimensionIndex = dimensions.app1Dimension.findIndex(dim => dim.dimensions_id === dimId);
                const app2DimensionIndex = dimensions.app2Dimension.findIndex(dim => dim.dimensions_id === dimId);
                if (app1DimensionIndex > -1 || app2DimensionIndex > -1) {
                    return false;
                }
                else {
                    return true;
                }
            }
            else {
                const dimensionIndex = dimension.findIndex(dim => dim.dimensions_id === dimId);
                if (dimensionIndex > -1) {
                    return false;
                }
                else {
                    return true;
                }
            }
        }
    }

    const app2bridgeMemberRowEditComplete = (e) => {
        let { newData } = e;
        dispatch(updateBridgeMember(
            {
                recon_id: selectedReconId,
                app_type: "1",
                rows: [{
                    bridge_id: newData.bridge_id,
                    dim_id: newData.dim_id,
                    source_member: newData.source_member,
                    flip_sign: newData.flip_sign,
                    bridge_member: newData.bridge_member
                }]
            }));
    }

    const deleteBridge = (bridge_id, event, appType) => {
        confirmPopup({
            target: event.currentTarget,
            message: 'Do you want to delete this record?',
            icon: 'pi pi-info-circle',
            acceptClassName: 'p-button-danger',
            accept: () => {
                dispatch(deleteBridgeMember(
                    {
                        "recon_id": selectedReconId,
                        "bridge_id": bridge_id
                    }, appType));
            },
            reject: () => {
            }
        });
    }

    const initFilters2 = () => {
        setFilters2({
            'global': { value: null, matchMode: FilterMatchMode.CONTAINS },
            'dimension': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'source_member': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'flip_sign': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'bridge_member': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
        });
        setGlobalFilterValue2('');
    }

    useEffect(() => {
        initFilters2();
    },[])

    const clearFilter2 = () => {
        initFilters2();
    }

    const downloadApp2BridgeMember = () => {
        dispatch(downloadBridgeMember(
            {
                "recon_id": selectedReconId,
                "app_type": "1"
            }));
    }

    const bridgeMemberRowEditValidator = (rowData) => {
        if (!rowData['dim_id']) {
            toast.error("Please select the dimension");
            return false;
        }
        else if (!rowData['source_member']) {
            toast.error("Please fill the source member");
            return false;
        }
        else if (!rowData['flip_sign']) {
            toast.error("Please fill the flip sign");
            return false;
        }
        else if (!rowData['bridge_member']) {
            toast.error("Please fill the bridge member");
            return false;
        }
        return true;
    }
    const onGlobalFilterChange2 = (e) => {
        const value = e.target.value;
        let _filters2 = { ...filters2 };
        _filters2['global'].value = value;

        setFilters2(_filters2);
        setGlobalFilterValue2(value);
    }

    const onRowEditChange = (e) => {
        if (AccessType === true) {
            setEditingRows(e.data)
        }
        else {
            return
        }
    }

    const textEditor = (options) => {
        return <InputText type="text" value={options.value} onChange={(e) => options.editorCallback(e.target.value)} className="w-full" />;
    }

    
    const app2BridgeMemberDelete = (rowData) => {
        return (
            <React.Fragment>
                <Button icon="pi pi-trash" disabled={!AccessType} className="p-button-rounded  mx-1 bg-primary" onClick={(e) => deleteBridge(rowData.bridge_id, e, "1")} />
            </React.Fragment>
        );
    }

    // const app2DimensionDropdownEditor = (options) => {
    //     return (
    //         <Dropdown value={options.value} options={dimensions.app2Dimension} optionLabel="dimension" optionValue="dimensions_id"
    //             onChange={(e) => { options.editorCallback(e.value) }} placeholder="select" className="w-full" filter showClear filterBy="dimension" />
    //     );
    // }

    const app2FlipSign = (options) => {
        return (
            <Dropdown value={options.value} options={applyFligSign} optionLabel="label" optionValue="value"
                onChange={(e) => { options.editorCallback(e.value); }} placeholder="select" />
        );
    }

    const getDimensionData = (dimensionList, dimId) => {
        if (!!dimId) {
            const index = dimensionList.findIndex(dim => dim.dimension === dimId);
            if (index === -1) {
                return dimId;
            }
            else {
                return dimensionList[index]?.dimension;
            }
        }
        else {
            return "--";
        }
    }

    const app2DimensionTemplate = (rowData) => {
        return (
            getDimensionData(dimensions.app2Dimension, rowData.dimension)
        );
    }

    const renderHeader2 = () => {
        return (
            <div className="flex justify-content-end">
                <span className="p-input-icon-left">
                    <i className="pi pi-search" />
                    <InputText value={globalFilterValue2} 
                    onChange={onGlobalFilterChange2} placeholder="Search" />
                </span>
                <Button type="button" 
                        icon="pi pi-filter-slash" 
                        title="Clear"
                        className="p-button-rounded mx-1 bg-primary" 
                        onClick={clearFilter2} />
                <Button icon="pi pi-download" 
                        onClick={downloadApp2BridgeMember} 
                        disabled={!AccessType}
                        className="p-button-rounded mx-1 bg-primary"
                        title="Download App2 Bridge Members" />              
            </div>
        )
    }

    const header2 = renderHeader2();

    return (
       <>
        <ConfirmPopup />
        <DataTable id="app2BridgeMembersTable"
                   className=""
                   rowClassName={rowClassApp2}
                   value={bridgeMembers.app2Rows}
                   editingRows={editingRows}
                   onRowEditChange={onRowEditChange}
                   rowEditValidator={bridgeMemberRowEditValidator}
                   onRowEditComplete={app2bridgeMemberRowEditComplete}
                   editMode="row"
                   dataKey="bridge_id"
                   showGridlines
                   scrollHeight="400px"
                   sortMode="multiple"
                   scrollable
                   removableSort
                   filterDisplay="menu"
                   globalFilterFields={['dimension', 'source_member', 'flip_sign', 'bridge_member']}
                   header={header2}
                   filters={filters2}
                   scrollDirection="both"
                   paginator
                   paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
                   currentPageReportTemplate="Showing {first} to {last} of {totalRecords}"
                   rows={10}
                   rowsPerPageOptions={[10, 20, 50]}>
            <Column style={{ width: '23.2%' }} field="dimension"
                    header="Dimension Name" sortable filter 
                    body={app2DimensionTemplate} ></Column>
                    
                    {/* editor={(options) => app2DimensionDropdownEditor(options)} */}
            <Column style={{ width: '22.3%' }} field="source_member" 
                    header="Source Members" sortable filter></Column>
                     
                     {/* editor={(options) => textEditor(options)} */}

            <Column style={{ width: '22%' }} field="flip_sign" header="Flip Sign"
                    sortable filter
                    // editor={(options) => textEditor(options)} 
                    editor={(options) => app2FlipSign(options)}></Column>
            <Column style={{ width: '22.2%' }} field="bridge_member"
                    header="Bridge Members" sortable filter 
                    editor={(options) => textEditor(options)}></Column>
            <Column style={{ width: '12%' }} rowEditor header="Edit"></Column>
            <Column style={{ width: '13.4%' }} align="center"
                    body={app2BridgeMemberDelete} header="Action" ></Column>
        </DataTable>
       </>
    )
}
export default BridgeApp2Table;