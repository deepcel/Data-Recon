from ... models import ReconDimensions, ReconApplications
import json
import pandas as pd
from django.conf import settings
from . get_headers import get_headers
from ... utils.get_recon import get_recon


'''
<!---------- Method to read the source file and give back the section
             data as a response ----------!>
'''


def get_data(app_file_path, recon_id, app_type,
             app_source_file, max_rows, section_number):

    # Get recon details from DB
    recon_instance = get_recon(recon_id)
    app_delimiter = recon_instance['app1_delimiter'] if app_type == '0' else recon_instance['app2_delimiter']
    app_has_header = recon_instance['app1_has_header'] if app_type == '0' else recon_instance['app2_has_header']
    skip_rows = 1 if app_has_header else 0

    # Getting the combinations
    combinations = get_headers(recon_id)

    # Getting the app type name
    app_key = 'App1' if app_type == '0' else 'App2'

    '''
    <!---------- Validating the delimiter of app
                 starts here ----------!>
    '''
    # Getting the first line
    f = open(app_file_path, 'r')
    if app_has_header:
        f.readline()
    first_line = f.readline()

    error_msg = 'not found' if not app_delimiter else 'mismatch'
    if not app_delimiter or app_delimiter not in first_line:
        response_data = {
            'status': 6002,
            'message': 'Delimiter ' + error_msg + ' in ' + app_key + ' configuration.'
        }
        return response_data
    else:
        if app_type == '0':
            ReconApplications.objects.filter(recon_id=recon_id, app_name='0')\
                .update(filename=app_source_file)
        elif app_type == '1':
            ReconApplications.objects.filter(recon_id=recon_id, app_name='1')\
                .update(filename=app_source_file)
        else:
            response_data = {
                'status': 6002,
                'message': 'Invalid app type found in request!'
            }
            return response_data
    '''
        <!---------- Validating the delimiter of app
                     ends here ----------!>
    '''

    # Reading the source file as dataframe
    data_frame = pd.read_csv(app_file_path,
                             sep=app_delimiter, skiprows=skip_rows, header=None)

    # Getting the dimension data as a dataframe
    app_dim_dataframe = pd.DataFrame(
        list(ReconDimensions.objects.filter(recon_id=recon_id, app_type=app_type).values()))

    # Getting the dimensions that is and not in file
    dim_in_file = app_dim_dataframe.loc[app_dim_dataframe['dim_in_file'] == 'YES']
    dim_not_in_file = app_dim_dataframe.loc[app_dim_dataframe['dim_in_file'] != 'YES']

    # Merging the dataframe
    number_of_comb = len(combinations)
    app_dim_list = []
    data_frame[combinations[0]] = app_key
    app_dim_list.append(combinations[0])
    for i in range(1, number_of_comb):
        app_dim = ((combinations[i]).split('-'))[int(app_type)]
        app_dim_list.append(combinations[i])
        df_size = dim_in_file[dim_in_file['dimension'] == app_dim]['type_field'].size
        if df_size > 0:
            df_value = dim_in_file[dim_in_file['dimension'] == app_dim]['type_field'].item()
            data_frame[combinations[i]] = data_frame[int(df_value) - 1]
        else:
            top_member = dim_not_in_file[dim_not_in_file['dimension'] == app_dim]['top_member'].item()
            data_frame[combinations[i]] = top_member

    # Taking only required data
    dim_link_frame = data_frame[app_dim_list]

    # Storing the cache
    source_name = app_source_file.split('.')
    dim_link_frame.to_pickle(settings.MEDIA_ROOT + '\\' + str(recon_id) + '\\' + source_name[0] + '.pkl')

    # Restrict max rows
    number_of_rows = len(dim_link_frame)
    if number_of_rows % max_rows == 0:
        number_of_sections = int(number_of_rows / max_rows)
    else:
        number_of_sections = int(number_of_rows / max_rows) + 1

    # Getting the from and to based on section
    start_point = (section_number - 1) * max_rows
    end_point = section_number * max_rows
    section_data_frame = dim_link_frame.iloc[start_point:end_point]

    # Getting the section JSON
    json_rows = section_data_frame.to_json(orient='records')
    json_rows = json.loads(json_rows)

    response_data = {
        'status': 200,
        'current_page': section_number,
        'total_pages': number_of_sections,
        'headers': combinations,
        'rows': json_rows,
        'message': 'Source file data retrieved successfully!'
    }

    return response_data
