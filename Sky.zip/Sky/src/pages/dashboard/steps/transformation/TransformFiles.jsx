import React, { useState, useRef} from "react";
import { useDispatch, useSelector } from "react-redux";
import { FileUpload } from 'primereact/fileupload';
import { Button } from "primereact/button";
import { toast } from "react-toastify";
import "./transformation.scss";
import { transformSyncImport } from "../../../../store/sliceReducers/TransformationReducer";
import { getExtension, chooseOptions, uploadOptions, cancelOptions } from "../../../../utils/fileutils";

const TransformFiles = () => {
  const dispatch = useDispatch();
  const authData = useSelector((state) => state.auth);
  let { data } = authData.data;
  const AccessType = data.access_type.privilege === 0 ? true : false;
  const fileUploadRef1 = useRef(null);
  const fileUploadRef2 = useRef(null);
  const [totalSizeApp1Sync, setTotalSizeApp1Sync] = useState(0);
  const [totalSizeApp2Sync, setTotalSizeApp2Sync] = useState(0);

  const onTemplateRemoveApp1Sync = (file, callback) => {
    setTotalSizeApp1Sync(totalSizeApp1Sync - file.size);
    callback();
  };

  const onTemplateRemoveApp2Sync = (file, callback) => {
    setTotalSizeApp2Sync(totalSizeApp2Sync - file.size);
    callback();
  };
  const itemTemplateApp1Sync = (file, props) => {
    return (
      <div className="flex justify-content-between ">
        <div className="flex align-items-center" style={{ width: "40%" }}>
          <span className="flex flex-column text-left ml-3">{file.name}</span>
        </div>

        <Button
          icon="pi pi-times"
          className="p-button-secondary"
          onClick={() => onTemplateRemoveApp1Sync(file, props.onRemove)}
        />
      </div>
    );
  };
  
  const itemTemplateApp2Sync = (file, props) => {
    return (
      <div className="flex justify-content-between ">
        <div className="flex align-items-center" style={{ width: "40%" }}>
          <span className="flex flex-column text-left ml-3">{file.name}</span>
        </div>

        <Button
          icon="pi pi-times"
          className="p-button-secondary"
          onClick={() => onTemplateRemoveApp2Sync(file, props.onRemove)}
        />
      </div>
    );
  };
  

  const selectedReconId = useSelector(state =>
    state.reconRun.selectedReconRunId
  );

  const app1TransformationMemberUpload = ({ files }) => {
    fileUpload(files, 0);
  };

  const app2TransformationMemberUpload = ({ files }) => {
    fileUpload(files, 1);
  };

  const fileUpload = (files, appType) => {
    const supportedFileFormat = ["csv", "txt"];
    const [file] = files;
    if (file) {
      if (!supportedFileFormat.includes(getExtension(file.name))) {
        toast.error("Unsupported file format, Please upload valid files(.xlsx,.xls,.csv,.txt)");
        return;
      }
    }
    const fileReader = new FileReader();
    fileReader.onload = (e) => {
      let formData = new FormData();
      formData.append('sync_file', file);
      formData.append('recon_id', selectedReconId);
      formData.append('app_type', appType);
      dispatch(transformSyncImport(formData, appType));
      if(appType===0)
      {
        fileUploadRef1.current.clear();        
      }
      else
      {
        fileUploadRef2.current.clear();
      }
    };
    fileReader.readAsDataURL(file);
  }

  return (
    <>
      <div className="formgrid grid">
        <div className="col-6">
          <label htmlFor="app1FileUpload" className="mb-3">APP1 SYNCHRONIZATION MAPPING:</label>
          <span className="p-float-label p-input-icon-right mt-2 w-full">
            <FileUpload accept=".csv, .txt"
                        ref={fileUploadRef1}
                        disabled={!AccessType}
                        maxFileSize={500000000}
                        chooseOptions={chooseOptions}
                        uploadOptions={uploadOptions}
                        cancelOptions={cancelOptions}
                        itemTemplate={itemTemplateApp1Sync}
                        customUpload
                        uploadHandler={app1TransformationMemberUpload}
                        emptyTemplate={<p className="m-0">Drag and drop files to here to upload.</p>} />
          </span>
        </div>

        <div className="col-6">
          <label htmlFor="app2FileUpload" className="mb-3">APP2 SYNCHRONIZATION MAPPING:</label>
          <span className="p-float-label p-input-icon-right mt-2 w-full">
            <FileUpload accept=".csv, .txt"
                        ref={fileUploadRef2}
                        disabled={!AccessType}
                        maxFileSize={500000000}
                        customUpload
                        chooseOptions={chooseOptions}
                        uploadOptions={uploadOptions}
                        cancelOptions={cancelOptions}
                        itemTemplate={itemTemplateApp2Sync}
                        uploadHandler={app2TransformationMemberUpload}
                        emptyTemplate={<p className="m-0">Drag and drop files to here to upload.</p>} />
          </span>
        </div>
      </div>
    </>
  )
}
export default TransformFiles;