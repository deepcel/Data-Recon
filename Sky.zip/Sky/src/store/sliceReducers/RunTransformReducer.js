import { createSlice } from "@reduxjs/toolkit";
import { toast } from "react-toastify";
import { makePostAPICall, makeGetAPICallFileDownload  } from "../../utils/apiService";
import { redirectToLogin } from "../../utils/utils";
import { enableLoader, hideLoader } from "./LoadReducer";
  
  // Dashboard reducer is used for handle all the steps data
  export const runTransformReducer = createSlice({
    name: "runTransform",
    initialState: {
        loading: false,
        error: null,
        appData: [],
        runTransformation: {
          headers: [],
          rows: [],
        },
    },
    reducers: {
        isLoading: (state, action) => {
          state.loading = true;
        },
        INVALID_SESSION: (state) => {
            state.loading = false;
            state.error = null;
          },
        RECON_LOAD_RUN_TRANSFORMATION: (state, action) => {
             state.loading = false;
             state.error = null;
             state.runTransformation.headers = [...action.payload.response.headers];
             state.runTransformation.rows = [...action.payload.response.rows];
          }, 
    },
});

export const {
    isLoading,
    INVALID_SESSION,
    RECON_LOAD_RUN_TRANSFORMATION,
} = runTransformReducer.actions;
  
  export const runTransform = (payload) => async (dispatch) => {
    try {
      dispatch(enableLoader());
      const response = await makePostAPICall("transformation/run", payload);
      if (response.status === 200) {
        dispatch(
          RECON_LOAD_RUN_TRANSFORMATION({
            response: response,
          })
        );
      } else if (response.status === 401) {
        dispatch(INVALID_SESSION(response));
        redirectToLogin();
      } else {
        toast.info("Please click on the refresh data button");
      }
      dispatch(hideLoader());
    } catch (err) {
      dispatch(hideLoader());
    }
  };
  
  export const exportruntransformation = (payload) => async (dispatch) => {
    try {
      dispatch(isLoading({ loading: true }));
      const response = await makeGetAPICallFileDownload(
        "transformation/run/export/",
        payload
      );
      if (response.status === 200) {
        toast.success("Download triggered successfully");
      } else if (response.status === 401) {
        dispatch(INVALID_SESSION(response));
        redirectToLogin();
      } else {
        toast.error(response.message);
      }
      dispatch(hideLoader());
    } catch (err) {
      dispatch(hideLoader());
    }
  };
  
  export const defaultAPIcall = (payload) => async (dispatch) => {
    try {
      dispatch(isLoading({ loading: true }));
      const response = await makePostAPICall("bridge/default",
        payload
      );
      if (response.status === 200) {
       // dispatch(listBridgeMembers (payload.recon_id));
        toast.success("Source members are defaulted to bridge members");
      } else if (response.status === 401) {
        dispatch(INVALID_SESSION(response));
        redirectToLogin();
      } else {
        toast.error(response.message);
      }
      dispatch(hideLoader());
    } catch (err) {
      dispatch(hideLoader());
    }
  };
  export default runTransformReducer.reducer;