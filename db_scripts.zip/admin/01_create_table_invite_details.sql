DROP SEQUENCE IF EXISTS admin."invitedetails_id_seq" cascade;
CREATE SEQUENCE admin."invitedetails_id_seq"
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 2147483647
    CACHE 1;

ALTER SEQUENCE admin."invitedetails_id_seq"
    OWNER TO "user_dataRecon_admin";

DROP TABLE IF EXISTS admin."invite_details" cascade;
CREATE TABLE admin."invite_details"
(
    id serial NOT NULL,
    email character varying(50),
    role character varying(50),
    "group" character varying(50),
    access_type jsonb,
	status character varying(50),
	created_date timestamp without time zone,
	token character varying,
    CONSTRAINT "invitedetails_pkey" PRIMARY KEY (id)
)

TABLESPACE tbsp_data_recon;

ALTER TABLE admin."invite_details"
    OWNER to "user_dataRecon_admin";

GRANT SELECT ON TABLE admin."invite_details" TO postgres;