import { createSlice } from "@reduxjs/toolkit";

// Load reducer is used for show / hide loader
export const LoadReducer = createSlice({
  name: "loader",
  initialState: {
    loading: false,
  },
  reducers: {
    enableLoader: (state) => {
      state.loading = true;
    },
    hideLoader: (state) => {
      state.loading = false;
    },
  },
});

export const { enableLoader, hideLoader } = LoadReducer.actions;

export default LoadReducer.reducer;
