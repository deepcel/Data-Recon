import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Card } from "primereact/card";
import { Button } from "primereact/button";
import 'primeicons/primeicons.css';
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';
import TransTable from "./TransTable";
import { runTransform } from "../../../../store/sliceReducers/RunTransformReducer";
import './RunTransformation.scss';
const RunTransformationSync = () => {

  const dispatch = useDispatch();
  const [reconRunName, setReconRunName] = useState("");
  const [loading1, setLoading1] = useState(false);
  const reconRunList = useSelector(state =>
    state.reconRun.appData[0]
  );

  const selectedReconId = useSelector(state =>
    state.reconRun.selectedReconRunId
  );

  const runTransformation = useSelector(state =>
    state.runTransform.runTransformation
  );

  useEffect(() => {
    let filteredRecon = reconRunList.find(run => run.recon_id === selectedReconId)
    if (filteredRecon) {
      setReconRunName(filteredRecon.name)
    }
    if (selectedReconId) {
      dispatch(runTransform({
        recon_id: selectedReconId,
        max_rows: 5000,
        page_number: 1,
        sp_flag: false
      }));
    }

  }, [])

  const onLoadingClick1 = () => {
    setLoading1(true);
    dispatch(runTransform(
      {
        "recon_id": selectedReconId,
        "max_rows": 5000,
        "page_number": 1,
        "sp_flag": true
      }));
    setTimeout(() => {
      setLoading1(false);
    }, 2000);
  }

  return (
    <React.Fragment>
      <Card className="shadow-5">
        <div className="card pt-0">
          {!reconRunName && <div className="text-center text-pink-500">
            Please select recon and click run transformation tab
          </div>}
          {
            !!reconRunName && <React.Fragment>
              <div className="field " style={{marginTop:'-10px'}}>
                Recon RunName: <span className="font-bold">{reconRunName} </span>
              </div>
              <div className="field p-2">
                <Button label="Refresh Data"
                  icon="pi pi-refresh"
                  className="mt-2 bg-primary"
                  loading={loading1}
                  onClick={onLoadingClick1} />
              </div>

              <div className="formgrid grid">
                <div className="col-12">
                  {
                    !!runTransformation.rows && <TransTable />
                  }
                </div>
              </div>
              <br />
            </React.Fragment>
          }
        </div>
      </Card>
    </React.Fragment>
  )
}

export default RunTransformationSync;