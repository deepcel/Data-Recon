from datetime import datetime
from rest_framework import status
from django.http import HttpResponse
from rest_framework.decorators import permission_classes, api_view, \
    renderer_classes, parser_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.renderers import JSONRenderer
from rest_framework.response import Response
from rest_framework.parsers import MultiPartParser, FormParser
from ..models import Recon, TrackFileLoadStatus, ReconUser, ReconApplications
from ..utils.get_recon import get_recon
from ..utils.pgsql_conn import call_sp_params
from ..utils.store_file import store_file
from .functions.export_data import export_data
from .functions.is_import_valid import is_import_valid
from .functions.get_view_data import get_view_data
from .functions.is_exists import is_exists
from ..utils.user_permissions import is_write_permitted
from django.conf import settings
from ..utils.run_export_script import run_export_script
import os
import requests
import time
from django.conf import settings
from zipfile import ZipFile
import zipfile
from Crypto.Cipher import AES
# from Crypto.SelfTest.Hash.test_cSHAKE import tag
from django.db import connections
import pandas as pd
import csv
from .functions.direct_connect_operations import pbcs_fccs, onestream
from .functions.ETL import pbcs_fccs_etl
from .functions.tag_dim import tag_dim
from ..utils.pgsql_conn import call_generic_query


@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@parser_classes((MultiPartParser, FormParser))
def import_source_file(request):
    # Getting the data from request
    recon_id = request.data['recon_id']
    app_type = request.data['app_type']
    max_rows = int(request.data['max_rows'])
    page_number = int(request.data['page_number'])
    no_files = int(request.data['num_files'])
    je = request.data['je']
    if je == "True":
        je = True
        fs_table = "je_"
    else:
        je = False
        fs_table = "app_"

    if je:
        file_obj = ["je"]
    else:
        file_obj = []
    for file in range(no_files):
        file_obj.append(request.FILES['source_file[' + str(file) + ']'])
    start_point = (page_number - 1) * max_rows
    end_point = page_number * max_rows

    if is_write_permitted(request.user.email):
        # Checking if recon exists or not deleted
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():

            # Getting the app id
            recon_data = get_recon(recon_id)
            recon_name = recon_data['name']
            app1_id = recon_data['app1_id']
            app2_id = recon_data['app2_id']
            app_id = recon_data['app1_id'] if app_type == '0' else recon_data['app2_id']
            inverse_app_id = recon_data['app2_id'] if app_type == '0' else recon_data['app1_id']

            # Storing file
            save_file = store_file(recon_id, file_obj)
            file_name, file_location = [], []
            for name in range(len(save_file[0])):
                file_name.append(save_file[0][name])
                file_location.append(save_file[1][name])
                file_location[name] = (save_file[1][name]).replace(file_name[name], '')
                # Validating all the pre-requisites
                is_valid = is_import_valid(recon_id, app_type, save_file[1][name]) if not je else is_import_valid(
                    recon_id, app_type, save_file[1][name], "je")

            if is_valid['status'] == 200:
                # Calling the dynamic table create SP
                create_dtable = call_sp_params('fileService.sp_create_dynamic_table', [app_id, je], 2)
                table_exists = is_exists('fileservice', fs_table + str(recon_id) + '_' + str(inverse_app_id))

                # Check if table exists for other app
                if not table_exists['rows'][0]['exists']:
                    call_sp_params('fileService.sp_create_dynamic_table', [inverse_app_id, je], 2)

                if create_dtable['status'] == 200:
                    # Saving the file details in DB
                    for x in range(len(file_location)):
                        file_load = TrackFileLoadStatus(recon_id=recon_id, app_id=app_id,
                                                        file_location=file_location[x], file_name=file_name[x])
                        file_load.save()

                    # Calling the load data SP
                    load_data = call_sp_params('fileService.sp_load_dynamic_table', [app_id, je], 2)

                    if load_data['status'] == 200:
                        create_view = call_sp_params('fileService.sp_create_recon_app_view', [recon_id, je], 2)
                        if create_view['status'] == 200:
                            if not je:
                                view_query = 'SELECT * FROM fileService.view_' + str(recon_id) + \
                                             ' WHERE app_id=' + str(app_id) + ' LIMIT ' + str(end_point) + \
                                             ' OFFSET ' + str(start_point)
                            else:
                                view_query = 'SELECT * FROM fileService.view_je_' + str(recon_id) + \
                                             ' WHERE app_id=' + str(app_id) + ' LIMIT ' + str(end_point) + \
                                             ' OFFSET ' + str(start_point)
                            response_data = get_view_data(view_query, app1_id, app2_id)
                        else:
                            response_data = create_view
                    else:
                        response_data = {
                            'status': 6002,
                            'message': 'The table did not load onto the Database, please contact your Administrator'
                        }
                else:
                    response_data = create_dtable
            else:
                response_data = is_valid
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def get_source_data(request):
    # Getting the data from request
    recon_id = request.data['recon_id']
    max_rows = int(request.data['max_rows'])
    page_number = int(request.data['page_number'])
    start_point = (page_number - 1) * max_rows
    end_point = page_number * max_rows

    # Checking if recon exists or not deleted
    if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
        recon_data = get_recon(recon_id)
        recon_name = recon_data['name']
        app1_id = recon_data['app1_id']
        app2_id = recon_data['app2_id']

        # Check if view exists
        view_exists = is_exists('fileservice', 'view_' + str(recon_id))

        # Check if table exists for other app
        if view_exists['rows'][0]['exists']:
            # Getting both apps data
            view_query = 'SELECT * FROM fileService.view_' + str(recon_id) + \
                         ' LIMIT ' + str(end_point) + \
                         ' OFFSET ' + str(start_point)
            response_data = get_view_data(view_query, app1_id, app2_id)
        else:
            response_data = {
                'status': 200,
                'headers': [],
                'rows': [],
                'message': 'No data found!'
            }

        # response_data = get_apps_data(recon_id, max_rows, page_number)
    else:
        response_data = {
            'status': 403,
            'message': 'No recon found with the specified id!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def export_source_data(request):
    recon_id = request.data['recon_id']
    je_flag = request.data['je_flag']
    if is_write_permitted(request.user.email):
        # Checking if recon exists or not deleted
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            current_time = datetime.now().time().strftime("%H:%M:%S")
            current_date = datetime.now().strftime("%Y-%m-%d")
            modified_date = str(current_date) + '_' + str(current_time)
            file_name = 'Source_Data_Export.csv'
            # export_file = export_data(recon_id, False)

            # Constructing the query
            ini_query = "select string_agg(col, ',') from (select '\"'||rd1.dimension||'-'||rd2.dimension||'\"'" \
                        " as col from fileservice.recon_dimensions rd1 inner join fileservice.recon_dimensions" \
                        " rd2 on rd1.turn_on_define_order =rd2.turn_on_define_order and rd1.recon_id=rd2.recon_id and" \
                        " rd2.app_type ='1' where rd1.recon_id =" + str(
                recon_id) + " and rd1.app_type ='0' and rd1.is_active and not" \
                            " rd1.is_deleted order by rd1.type_field ::integer)q"

            cursor = connections['Recon'].cursor()
            cursor.execute(ini_query)
            cursor = cursor.fetchone()
            cursor = ','.join(map(str, cursor)).split(",")
            headers = ""

            for x in range(len(cursor)):
                headers += "\\\"" + cursor[x] + "\\\""
                if x < len(cursor) - 1:
                    headers += ","

            if je_flag:
                query = "select " + headers + " from fileservice.view_je_" + str(recon_id)
            else:
                query = "select " + headers + " from fileservice.view_" + str(recon_id)

            # Calling the Shell script to create a csv file
            run_export_script(recon_id, file_name, query)

            file_path = os.path.join(settings.MEDIA_ROOT, str(recon_id) + "/export/" + file_name)
            file_path = (str(file_path).replace("\\", "/"))
            if os.path.exists(file_path):
                with open(file_path, 'rb') as fh:
                    response = HttpResponse(fh.read(), content_type="text/csv")
                    response['Content-Disposition'] = 'inline; filename=' + modified_date + os.path.basename(file_path)
                    response['Access-Control-Expose-Headers'] = 'Content-Disposition'
                    return response
            else:
                response = {
                    'status': 6002,
                    'message': 'File Not Found'
                }

            # Setting the download response
            # response_data = HttpResponse(export_file.getvalue(), content_type='text/csv')
            # response_data['Content-Disposition'] = 'attachment; filename=' + file_name
            # response_data['Access-Control-Expose-Headers'] = 'Content-Disposition'
            # return response_data
        else:
            response = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }
    return Response(response, status=status.HTTP_200_OK)


@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@parser_classes((MultiPartParser, FormParser))
def import_je_file(request):
    # Getting the data from request
    recon_id = request.data['recon_id']
    app_type = request.data['app_type']
    max_rows = int(request.data['max_rows'])
    page_number = int(request.data['page_number'])
    no_files = int(request.data['num_files'])
    file_obj = ["je"]
    for file in range(no_files):
        file_obj.append(request.FILES['source_file[' + str(file) + ']'])
    start_point = (page_number - 1) * max_rows
    end_point = page_number * max_rows

    if is_write_permitted(request.user.email):
        # Checking if recon exists or not deleted
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():

            # Getting the app id
            recon_data = get_recon(recon_id)
            recon_name = recon_data['name']
            app1_id = recon_data['app1_id']
            app2_id = recon_data['app2_id']
            app_id = recon_data['app1_id'] if app_type == '0' else recon_data['app2_id']
            inverse_app_id = recon_data['app2_id'] if app_type == '0' else recon_data['app1_id']

            # Storing file
            save_file = store_file(recon_id, file_obj)
            file_name, file_location = [], []
            for name in range(len(save_file[0])):
                file_name.append(save_file[0][name])
                file_location.append(save_file[1][name])
                file_location[name] = (save_file[1][name]).replace(file_name[name], '')
                # Validating all the pre-requisites
                is_valid = is_import_valid(recon_id, app_type, save_file[1][name], "je")

            if is_valid['status'] == 200:
                # Calling the dynamic table create SP
                create_dtable = call_sp_params('fileService.sp_create_dynamic_table', [app_id, True], 2)
                table_exists = is_exists('fileservice', 'je_' + str(recon_id) + '_' + str(inverse_app_id))

                # Check if table exists for other app
                if not table_exists['rows'][0]['exists']:
                    call_sp_params('fileService.sp_create_dynamic_table', [inverse_app_id, True], 2)

                if create_dtable['status'] == 200:
                    # Saving the file details in DB
                    for x in range(len(file_location)):
                        file_load = TrackFileLoadStatus(recon_id=recon_id, app_id=app_id,
                                                        file_location=file_location[x], file_name=file_name[x])
                        file_load.save()

                    # Calling the load data SP
                    load_data = call_sp_params('fileService.sp_load_dynamic_table', [app_id, True], 2)

                    if load_data['status'] == 200:
                        create_view = call_sp_params('fileService.sp_create_recon_app_view', [recon_id, True], 2)
                        if create_view['status'] == 200:
                            view_query = 'SELECT * FROM fileService.view_je_' + str(recon_id) + \
                                         ' WHERE app_id=' + str(app_id) + ' LIMIT ' + str(end_point) + \
                                         ' OFFSET ' + str(start_point)
                            response_data = get_view_data(view_query, app1_id, app2_id)
                        else:
                            response_data = create_view
                    else:
                        response_data = load_data
                else:
                    response_data = create_dtable
            else:
                response_data = is_valid
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def get_je_data(request):
    # Getting the data from request
    recon_id = request.data['recon_id']
    max_rows = int(request.data['max_rows'])
    page_number = int(request.data['page_number'])
    start_point = (page_number - 1) * max_rows
    end_point = page_number * max_rows

    # Checking if recon exists or not deleted
    if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
        recon_data = get_recon(recon_id)
        recon_name = recon_data['name']
        app1_id = recon_data['app1_id']
        app2_id = recon_data['app2_id']

        # Check if view exists
        view_exists = is_exists('fileservice', 'view_je_' + str(recon_id))

        # Check if table exists for other app
        if view_exists['rows'][0]['exists']:
            # Getting both apps data
            view_query = 'SELECT * FROM fileService.view_je_' + str(recon_id) + \
                         ' LIMIT ' + str(end_point) + \
                         ' OFFSET ' + str(start_point)
            response_data = get_view_data(view_query, app1_id, app2_id)
        else:
            response_data = {
                'status': 200,
                'headers': [],
                'rows': [],
                'message': 'No data found!'
            }

        # response_data = get_apps_data(recon_id, max_rows, page_number)
    else:
        response_data = {
            'status': 403,
            'message': 'No recon found with the specified id!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def export_je_data(request, recon_id):
    if is_write_permitted(request.user.email):
        # Checking if recon exists or not deleted
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            current_time = datetime.now().time().strftime("%H:%M:%S")
            current_date = datetime.now().strftime("%Y-%m-%d")
            modified_date = str(current_date) + '_' + str(current_time)
            file_name = 'JE_Source_Data_Export.csv'
            # export_file = export_data(recon_id, True)

            # Calling the Shell script to create a csv file

            query = "select string_agg('"'||c.column_name||'"' ,',')from information_schema.\"columns\" c where c.table_schema ='fileservice'and c.table_name = 'view_89'and c.column_name not in ('app_id','file_name','file_id');"

            query = "select * from fileservice.view_je_" + str(recon_id)
            run_export_script(recon_id, file_name, query)

            file_path = os.path.join(settings.MEDIA_ROOT, str(recon_id) + "/export/" + file_name)
            file_path = (str(file_path).replace("\\", "/"))
            if os.path.exists(file_path):
                with open(file_path, 'rb') as fh:
                    response = HttpResponse(fh.read(), content_type="text/csv")
                    response['Content-Disposition'] = 'inline; filename=' + os.path.basename(modified_date + file_path)
                    return response
            else:
                response = {
                    'status': 6002,
                    'message': 'File Not Found'
                }
        else:
            response = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }
    return Response(response, status=status.HTTP_200_OK)

    # Setting the download response
    #     response_data = HttpResponse(export_file.getvalue(), content_type='text/csv')
    #     response_data['Content-Disposition'] = 'attachment; filename=' + file_name
    #     response_data['Access-Control-Expose-Headers'] = 'Content-Disposition'
    #     return response_data
    # else:
    #     response_data = {
    #         'status': 403,
    #         'message': 'No recon found with the specified id!'
    #     }
    # else:
    #     response_data = {
    #         'status': 6002,
    #         'message': 'Un-authorized action detected!'
    #     }
    # return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def direct_connect(request):
    recon_id = request.data['recon_id']
    app_type = request.data['appType']
    app_type = 0 if app_type == "0" else 1

    if is_write_permitted(request.user.email):

        # Retrieving job from cloud and saving the file
        instance = ReconApplications.objects.filter(recon_id=recon_id, app_name=app_type)
        if int(instance[0].import_type) == 1:
            res = pbcs_fccs(request)
        elif int(instance[0].import_type) == 3:
            res = onestream(request)
        elif int(instance[0].import_type) == 4:
            res = "Undefined for HFM"  # HFM
        else:
            res = {
                'status': 6002,
                'message': 'Unsupported import type selected'
            }
        # etl = []

        if type(res) is list:
            for i in range(len(res[0])):
                file_name = res[0][i]

                # Performing pbcs/fccs ETL
                etl = (pbcs_fccs_etl(recon_id, file_name))

            response_data = {
                'status': 200,
                'headers': etl,
                'files': res[0],
            }
        else:
            response_data = res
    else:
        response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }

    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def dim_tag(request):
    recon_id = request.data['recon_id']
    app_type = request.data['appType']

    max_rows = int(request.data['max_rows'])
    page_number = int(request.data['page_number'])
    start_point = (page_number - 1) * max_rows
    end_point = page_number * max_rows

    recon_data = get_recon(recon_id)
    recon_name = recon_data['name']
    app1_id = recon_data['app1_id']
    app2_id = recon_data['app2_id']
    app_id = recon_data['app1_id'] if app_type == '0' else recon_data['app2_id']
    inverse_app_id = recon_data['app2_id'] if app_type == '0' else recon_data['app1_id']

    if is_write_permitted(request.user.email):
        file_names = request.data['files']
        headers = request.data['headers']

        for i in range(len(file_names)):
            file = file_names[i]
            filepath = str(settings.MEDIA_ROOT + "/" + str(recon_id) + "/" + file)
            file_location = filepath.replace(file, '')

            # Tagging headers to dimensions
            tag_dim(recon_id, filepath, headers, app_type)

            # Validating all the pre-requisites
            is_valid = is_import_valid(recon_id, app_type, filepath)

            if is_valid['status'] == 200:
                # Calling the dynamic table create SP
                create_dtable = call_sp_params('fileService.sp_create_dynamic_table', [app_id, False], 2)
                table_exists = is_exists('fileservice', 'app_' + str(recon_id) + '_' + str(inverse_app_id))

                # Check if table exists for other app
                if not table_exists['rows'][0]['exists']:
                    call_sp_params('fileService.sp_create_dynamic_table', [inverse_app_id, False], 2)

                if create_dtable['status'] == 200:
                    # Saving the file details in DB
                    file_load = TrackFileLoadStatus(recon_id=recon_id, app_id=app_id,
                                                    file_location=file_location, file_name=file)
                    file_load.save()

                    # Calling the load data SP
                    load_data = call_sp_params('fileService.sp_load_dynamic_table', [app_id, False], 2)

                    if load_data['status'] == 200:
                        create_view = call_sp_params('fileService.sp_create_recon_app_view', [recon_id, False], 2)
                        if create_view['status'] == 200:
                            view_query = 'SELECT * FROM fileService.view_' + str(recon_id) + \
                                         ' WHERE app_id=' + str(app_id) + ' LIMIT ' + str(end_point) + \
                                         ' OFFSET ' + str(start_point)
                            response_data = get_view_data(view_query, app1_id, app2_id)
                        else:
                            response_data = create_view
                    else:
                        response_data = load_data
                else:
                    response_data = create_dtable
            else:
                response_data = is_valid
    else:
        response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }

    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def je_update(request):
    # Getting the data from request
    recon_id = request.data['recon_id']
    app_type = request.data['app_type']
    new_rows = request.data['rows']

    # Checking if recon exists or not deleted
    if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
        recon_data = get_recon(recon_id)
        app_id = recon_data['app1_id'] if app_type == '0' else recon_data['app2_id']

        if is_write_permitted(request.user.email):
            je_table_name = 'je_' + str(recon_id) + '_' + str(app_id)
            for row in new_rows:
                row_headers = ['app_id']
                row_headers.extend(list(row.keys()))
                row_headers = '","'.join(row_headers)
                row_headers = '"' + row_headers + '"'
                row_values = [app_id]
                row_values.extend(list(row.values()))
                row_values = [str(x) for x in row_values]
                row_values = "','".join(row_values)
                row_values = "'" + row_values + "'"
                object_query = 'INSERT INTO fileservice.{table_name}({row_headers}) VALUES({row_values})'
                object_query = object_query.format(table_name=je_table_name, row_headers=row_headers,
                                                   row_values=row_values)
                exec_query = call_generic_query(object_query)

                if exec_query['status'] == 200:
                    response_data = {
                        'status': 200,
                        'message': 'JE rows added successfully!'
                    }
                else:
                    response_data = exec_query
        else:
            response_data = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }
    else:
        response_data = {
            'status': 403,
            'message': 'No recon found with the specified id!'
        }

    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def je_delete(request):
    # Getting the data from request
    recon_id = request.data['recon_id']
    app_type = request.data['app_type']
    rec_id = request.data['rec_id']

    # Checking if recon exists or not deleted
    if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
        recon_data = get_recon(recon_id)
        app_id = recon_data['app1_id'] if app_type == '0' else recon_data['app2_id']

        if is_write_permitted(request.user.email):
            je_table_name = 'je_' + str(recon_id) + '_' + str(app_id)
            object_query = f"DELETE FROM fileservice.{je_table_name} WHERE rec_id = '{rec_id}'"
            object_query = object_query.format(table_name=je_table_name, rec_id=rec_id)
            exec_query = call_generic_query(object_query)  # print(row_values)

            if exec_query['status'] == 200:
                response_data = {
                    'status': 200,
                    'message': 'JE rows Deleted successfully!'
                }
            else:
                response_data = exec_query
        else:
            response_data = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }
    else:
        response_data = {
            'status': 403,
            'message': 'No recon found with the specified id!'
        }

    return Response(response_data, status=status.HTTP_200_OK)
