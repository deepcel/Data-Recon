CREATE OR REPLACE FUNCTION fileservice.f_get_column_list(recon_id integer, var_intersection boolean)
 RETURNS text
 LANGUAGE plpgsql
AS $function$
declare
var_recon_id integer := recon_id;
s_schema_name text := 'fileservice';
var_in_not_in text := ' not in ';
var_query text := '';
var_rec text := '';
begin
	
	if
		exists (select 1 from fileservice.recon r where r.recon_id = var_recon_id and not r.is_deleted)
	then
		if var_intersection
		then 
			var_in_not_in = ' in ';
		end if;
	
		var_query =  'select string_agg(''"'' || c.column_name || ''"'','','') as select_string';
		var_query = var_query || ' from information_schema."columns" c';
		var_query = var_query || ' where c.table_schema = '''||s_schema_name||''' and c.table_name = ''report_'||var_recon_id||'''';
		var_query = var_query || ' and ''"'' || c.column_name || ''"'' not in (''"bridge-comment"'',''"je-comment"'',''"grand_abs_total"'')';
		var_query = var_query || ' and ''"'' || c.column_name || ''"'''|| var_in_not_in ||' (';
		var_query = var_query || ' select ''"bridgesync-''|| rd1.dimension || ''-'' || rd2.dimension || ''"''';
		var_query = var_query || ' from fileservice.recon_dimensions rd1 inner join fileservice.recon_dimensions rd2 on ';
		var_query = var_query || ' rd1.recon_id = rd2.recon_id and rd1.turn_on_define_order = rd2.turn_on_define_order ';
		var_query = var_query || ' and rd1.turn_on_define_order not in (''0'', ''1'', ''2'') and rd1.app_type = ''0'' and rd2.app_type = ''1''';
		var_query = var_query || ' where rd1.recon_id = '||var_recon_id||' and not rd1.is_deleted and rd1.is_active)';
--	raise notice '%',var_query;
	execute var_query into var_rec;
	end if;
	
	--	Log Script
--	call fileService.sp_log_entry(
--								null::integer,
--								'''Report report_'|| var_recon_id || ' without variance created'''::text,
--								var_recon_id::integer,
--								'report_'||var_recon_id::text
--								);
	return var_rec;							
end;
$function$
;

-- Permissions

ALTER FUNCTION fileservice.f_get_column_list(int4, bool) OWNER TO "user_dataRecon_file";
GRANT ALL ON FUNCTION fileservice.f_get_column_list(int4, bool) TO "user_dataRecon_file";
