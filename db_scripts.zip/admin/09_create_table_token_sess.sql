-- SEQUENCE: admin.token_sess_token_id_seq
DROP SEQUENCE IF EXISTS admin.token_sess_token_id_seq cascade;

CREATE SEQUENCE IF NOT EXISTS admin.token_sess_token_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE admin.token_sess_token_id_seq
    OWNER TO "user_dataRecon_admin";-- SEQUENCE: admin.token_sess_token_id_seq

-- Table: admin.token_sess
DROP TABLE IF EXISTS admin.token_sess cascade;

CREATE TABLE IF NOT EXISTS admin.token_sess
(
    token_id bigint NOT NULL DEFAULT nextval('admin.token_sess_token_id_seq'::regclass),
    email character varying COLLATE pg_catalog."default",
    token character varying COLLATE pg_catalog."default",
    created_date timestamp without time zone,
    expiry_date timestamp without time zone,
    type character varying COLLATE pg_catalog."default",
    status character varying COLLATE pg_catalog."default",
    CONSTRAINT pk_tokenid PRIMARY KEY (token_id)
        USING INDEX TABLESPACE tbsp_data_recon
)
TABLESPACE tbsp_data_recon;

ALTER TABLE IF EXISTS admin.token_sess
    OWNER to "user_dataRecon_admin";
GRANT ALL ON TABLE admin.token_sess TO postgres;
GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE admin.token_sess TO "user_dataRecon_admin";