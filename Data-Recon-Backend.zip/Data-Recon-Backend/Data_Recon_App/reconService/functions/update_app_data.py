from ... models import ReconApplications
from .. serializers import ReconAppSerializer


'''
<!---------- Method to update recon applications'
            data and give response ----------!>
'''


def update_app_data(recon_id, recon_data):

    # Initiating response
    response = True

    # Getting app1 data
    app1_data = {}
    if 'app1_import_type' in recon_data:
        app1_data['import_type'] = recon_data['app1_import_type']
    if 'app1_delimiter' in recon_data:
        app1_data['import_delimiter'] = recon_data['app1_delimiter']
    if 'app1_has_header' in recon_data:
        app1_data['has_header'] = recon_data['app1_has_header']
    if 'app1_currency_symbol' in recon_data:
        app1_data['currency_symbol'] = recon_data['app1_currency_symbol']
    if 'app1_currency_delimiter' in recon_data:
        app1_data['currency_delimiter'] = recon_data['app1_currency_delimiter']

    # Updating app1 data
    app1_instance = ReconApplications.objects.filter(recon_id=recon_id, app_name='0')[0]
    app1_serialized = ReconAppSerializer(app1_instance, data=app1_data, partial=True)

    if app1_serialized.is_valid():
        app1_serialized.save()
    else:
        response = False

    # Getting app2 data
    app2_data = {}
    if 'app2_import_type' in recon_data:
        app2_data['import_type'] = recon_data['app2_import_type']
    if 'app2_delimiter' in recon_data:
        app2_data['import_delimiter'] = recon_data['app2_delimiter']
    if 'app2_has_header' in recon_data:
        app2_data['has_header'] = recon_data['app2_has_header']
    if 'app2_currency_symbol' in recon_data:
        app2_data['currency_symbol'] = recon_data['app2_currency_symbol']
    if 'app2_currency_delimiter' in recon_data:
        app2_data['currency_delimiter'] = recon_data['app2_currency_delimiter']

    # Updating app2 data
    app2_instance = ReconApplications.objects.filter(recon_id=recon_id, app_name='1')[0]
    app2_serialized = ReconAppSerializer(app2_instance, data=app2_data, partial=True)

    if app2_serialized.is_valid():
        app2_serialized.save()
    else:
        response = False

    return response
