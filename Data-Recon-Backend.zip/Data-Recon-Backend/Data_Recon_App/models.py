import uuid
from django.db import models
from django.contrib.auth.models import AbstractUser


class ReconUser(AbstractUser):
    uuid = models.UUIDField(default=uuid.uuid4, editable=False)
    first_name = models.CharField(max_length=1000, blank=True)
    last_name = models.CharField(max_length=1000, blank=True)
    role = models.CharField(max_length=1000, blank=True)
    access_type = models.JSONField(max_length=1000, blank=True)
    last_login = models.DateTimeField(blank=True, null=True)
    DC_Url = models.CharField(max_length=1000, blank=True)
    DC_Username = models.CharField(max_length=1000, blank=True)
    DC_Password = models.BinaryField(max_length=1000, blank=True)
    tag = models.BinaryField(max_length=1000, blank=True)
    nonce = models.BinaryField(max_length=1000, blank=True)
    onestream = models.BooleanField(blank=True, null=True, default=False)
    admin_tag = models.CharField(max_length=1000, blank=True)

    class Meta:
        db_table = 'auth_user'


class Recon(models.Model):
    recon_id = models.BigAutoField(primary_key=True)
    app1_id = models.BigIntegerField(blank=True, null=True)
    app2_id = models.BigIntegerField(blank=True, null=True)
    name = models.CharField(max_length=1000, blank=True, null=True)
    variance_threshold = models.BigIntegerField(blank=True, null=True)
    execution_date = models.TimeField(blank=True, null=True)
    status = models.CharField(max_length=1000, blank=True, null=True, default='Initiated')
    is_deleted = models.BooleanField(blank=True, null=True, default=False)
    description = models.CharField(max_length=1000, blank=True, null=True)
    created_by = models.CharField(max_length=1000, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    last_modified_by = models.CharField(max_length=1000, blank=True, null=True)
    last_modified_date = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'recon'
        app_label = 'reconService'


class ReconApplications(models.Model):
    recon_app_id = models.BigAutoField(primary_key=True)
    recon_id = models.BigIntegerField(blank=True, null=True)
    app_name = models.CharField(max_length=1000, blank=True, null=True)
    import_type = models.CharField(max_length=1000, blank=True, null=True)
    import_delimiter = models.CharField(max_length=5, blank=True, null=True)
    currency_symbol = models.TextField(blank=True, null=True)
    currency_delimiter = models.TextField(blank=True, null=True)
    has_header = models.BooleanField(blank=True, null=True, default=False)
    url = models.CharField(max_length=1000, blank=True, null=True)
    cube = models.CharField(max_length=1000, blank=True, null=True)
    username = models.CharField(max_length=1000, blank=True, null=True)
    password = models.CharField(max_length=1000, blank=True, null=True)
    filename = models.CharField(max_length=200, blank=True, null=True)
    is_deleted = models.BooleanField(blank=True, null=True, default=False)

    class Meta:
        managed = False
        db_table = 'recon_applications'
        app_label = 'reconService'


class ReconBridgeMapping(models.Model):
    bridge_id = models.BigAutoField(primary_key=True)
    recon_id = models.BigIntegerField(blank=True, null=True)
    app_id = models.BigIntegerField(blank=True, null=True)
    dim_id = models.BigIntegerField(blank=True, null=True)
    flip_sign = models.BooleanField(blank=True, null=True)
    app_type = models.CharField(max_length=1000, blank=True, null=True)
    source_member = models.CharField(max_length=1000, blank=True, null=True)
    bridge_member = models.CharField(max_length=1000, blank=True, null=True)
    dim_comment = models.CharField(max_length=1000, blank=True, null=True)
    bridge_comment = models.CharField(max_length=1000, blank=True, null=True)
    je_comment = models.CharField(max_length=1000, blank=True, null=True)
    is_deleted = models.BooleanField(default=False)
    is_invalid = models.BooleanField(default=False)

    class Meta:
        managed = False
        db_table = 'recon_bridge_mapping'
        app_label = 'reconService'


class ReconDimensions(models.Model):
    dimensions_id = models.BigAutoField(primary_key=True)
    recon_app_id = models.BigIntegerField(blank=True, null=True)
    turn_on_define_order = models.CharField(max_length=1000, blank=True, null=True)
    dimension = models.CharField(max_length=1000, blank=True, null=True)
    dim_in_file = models.CharField(max_length=1000, blank=True, null=True)
    type_field = models.CharField(max_length=1000, blank=True, null=True)
    top_member = models.CharField(max_length=1000, blank=True, null=True)
    app_type = models.CharField(max_length=1000, blank=True, null=True)
    recon_id = models.BigIntegerField(blank=True, null=True)
    is_deleted = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    in_recon = models.BooleanField(default=True)

    class Meta:
        managed = False
        db_table = 'recon_dimensions'
        app_label = 'reconService'


class ReconLabels(models.Model):
    id = models.BigAutoField(primary_key=True)
    type = models.CharField(max_length=1000, blank=True, null=True)
    name = models.CharField(max_length=1000, blank=True, null=True)
    description = models.CharField(max_length=1000, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'recon_labels'
        app_label = 'reconService'


class ReconTransformation(models.Model):
    id = models.BigAutoField(primary_key=True)
    recon_id = models.BigIntegerField(blank=True, null=True)
    app_id = models.BigIntegerField(blank=True, null=True)
    dim_id = models.BigIntegerField(blank=True, null=True)
    tgt_concat_dimid = models.CharField(max_length=1000, blank=True, null=True)
    tgt_concat_dimname = models.CharField(max_length=1000, blank=True, null=True)
    concat_delimiter = models.TextField(blank=True, null=True, default='-')
    apply_all_members = models.BooleanField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'recon_transformation'
        app_label = 'reconService'


class ReconTransformationOverride(models.Model):
    id = models.BigAutoField(primary_key=True)
    recon_id = models.BigIntegerField(blank=True, null=True)
    app_id = models.BigIntegerField(blank=True, null=True)
    tfn_id = models.BigIntegerField(blank=True, null=True)
    source_sync = models.CharField(max_length=1000, blank=True, null=True)
    target_sync = models.CharField(max_length=1000, blank=True, null=True)
    flip_sign = models.BooleanField(blank=True, null=True, default=False)

    class Meta:
        managed = False
        db_table = 'recon_transformation_override'
        app_label = 'reconService'


class TrackAppData(models.Model):
    recon_id = models.BigIntegerField(blank=True, null=True)
    application_id = models.BigIntegerField(blank=True, null=True)
    table_name = models.CharField(max_length=1000, blank=True, null=True)
    log_comment = models.CharField(max_length=1000)
    source_caller = models.CharField(max_length=1000, blank=True, null=True)
    user_email = models.CharField(max_length=1000, blank=True, null=True)
    created_date = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'track_app_data_table'
        app_label = 'reconService'


class TrackFileLoadStatus(models.Model):
    file_id = models.BigAutoField(primary_key=True)
    recon_id = models.BigIntegerField(blank=True, null=True)
    app_id = models.BigIntegerField(blank=True, null=True)
    file_location = models.CharField(max_length=1000, blank=True, null=True)
    file_name = models.CharField(max_length=1000, blank=True, null=True)
    status = models.CharField(max_length=1000, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True, auto_now_add=True)

    class Meta:
        managed = False
        db_table = 'track_file_load_status'
        app_label = 'reconService'


class InviteDetails(models.Model):
    id = models.BigAutoField(primary_key=True)
    email = models.CharField(max_length=1000, blank=True, null=True)
    role = models.CharField(max_length=1000, blank=True, null=True)
    group = models.CharField(max_length=1000, blank=True, null=True)
    access_type = models.JSONField(max_length=1000, blank=True, null=True)
    status = models.CharField(max_length=1000, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    token = models.CharField(max_length=1000, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'invite_details'


class TokenDetails(models.Model):
    token_id = models.BigAutoField(primary_key=True)
    email = models.CharField(max_length=1000, blank=True, null=True)
    status = models.CharField(max_length=1000, blank=True, null=True)
    created_date = models.DateTimeField(blank=True, null=True)
    expiry_date = models.DateTimeField(blank=True, null=True)
    token = models.CharField(max_length=1000, blank=True, null=True)
    type = models.CharField(max_length=1000, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'token_sess'


class DCUser(models.Model):
    app_name = models.CharField(max_length=1000, blank=True, null=True)
    import_type = models.IntegerField(blank=True, null=True)
    dc_username = models.CharField(max_length=1000, blank=True, null=True)
    dc_password = models.BinaryField(max_length=1000, blank=True)
    dc_url = models.CharField(max_length=1000, blank=True, null=True)
    tag = models.BinaryField(max_length=1000, blank=True)
    nonce = models.BinaryField(max_length=1000, null=True)
    tenant_id = models.CharField(max_length=1000, null=True)
    email = models.CharField(max_length=1000, null=True)

    class Meta:
        managed = False
        db_table = 'direct_connect'
