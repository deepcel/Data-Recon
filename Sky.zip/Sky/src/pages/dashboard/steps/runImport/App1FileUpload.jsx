import React, { useState,useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import { Tooltip } from 'primereact/tooltip';
import { FileUpload } from 'primereact/fileupload';
import { Button } from "primereact/button";
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';
import { getExtension, cancelOptions } from "../../../../utils/fileutils";
import { runImport } from "../../../../store/sliceReducers/RunImportReducer";
import "./runImport.scss";

const App1FileUpload = () => {
  const dispatch = useDispatch();
  const authData = useSelector((state) => state.auth);
  let { data } = authData.data;
  const AccessType = data.access_type.privilege === 0 ? true : false;
  const [totalSizeApp1Source, setTotalSizeApp1Source] = useState(0);
  const fileUploadRef1 = useRef(null);
  const chooseOptions = {icon:"pi pi-plus" , className:"bg-primary custom-choose-btn", tooltip:"" };
  const uploadOptions = { icon: 'pi pi-fw pi-cloud-upload', className: 'p-button-outlined bg-primary' };
  
  const selectedReconId = useSelector(state =>
    state.reconRun.selectedReconRunId
  );

  const app1_Import_type=useSelector(state =>
    state.dimField.reconDetails.app1_import_type
  );

  const onTemplateRemoveApp1Source = (file, callback) => {
    setTotalSizeApp1Source(totalSizeApp1Source - file.size);
    callback();
  };

 
  const itemTemplateApp1Source = (file, props) => {
    return (
      <div className="flex justify-content-between ">
        <div className="flex align-items-center" style={{ width: "40%" }}>
          <span className="flex flex-column text-left ml-3">{file.name}</span>
        </div>
        <Button
          icon="pi pi-times"
          className="p-button-secondary"
          onClick={() => onTemplateRemoveApp1Source(file, props.onRemove)}
        />
      </div>
    );
  };
 

  const app1FileUpload = ({ files }) => {
    fileUpload(files, 0);
  };

 
  // const fileUpload = (files, appType) => {
  //     const supportedFileFormat = ["csv", "txt"];
  //     const file = files;
  //     if (file) {
  //         if (!supportedFileFormat.includes(getExtension(file.name))) {
  //             toast.error("Unsupported file format, Please upload valid files(.csv,.txt)");
  //             return;
  //         }
  //     }
  //     const fileReader = new FileReader();
  //     fileReader.onload = (e) => {
  //         let formData = new FormData();
  //         formData.append('source_file', file);
  //         formData.append('recon_id', selectedReconId);
  //         formData.append('app_type', appType);
  //         formData.append('max_rows', 100);
  //         formData.append('page_number', 1);
  //         dispatch(runImport(formData, appType));
  //     };
  //     fileReader.readAsDataURL(file);
  // }

  // multi file upload
  const fileUpload = (files, appType) => {
    const supportedFileFormat = ["csv", "txt"];
    for (let file of files) {
      if (!supportedFileFormat.includes(getExtension(file.name))) {
        toast.error("Unsupported file format, Please upload valid files(.csv,.txt)");
        return;
      }
    }
    let formData = new FormData();
    let fileReaders = [];
    let a = 0;
    files.forEach((file, index) => {
      const fileReader = new FileReader();
      fileReaders.push(
        new Promise((resolve, reject) => {
          fileReader.onload = (e) => {
            formData.append(`source_file[${index}]`, file);
            resolve();
          };
          fileReader.onerror = reject;
          fileReader.readAsArrayBuffer(file);
          a++;
        })
      );
    });
    Promise.all(fileReaders)
      .then(() => {
        formData.append('num_files', a);
        formData.append('recon_id', selectedReconId);
        formData.append('app_type', appType);
        formData.append('max_rows', 100);
        formData.append('page_number', 1);
        formData.append('je', false);
        dispatch(runImport(formData, appType));
       
          fileUploadRef1.current.clear();        
       
      })
      .catch(err => {
        // console.error(err);
      });
  };

  return (
    <>

        <Tooltip target=".custom-choose-btn" placeholder="Bottom"
                 content="Files delimited with (,), (;) in .csv or .txt format are accepted for import"/>
          <label htmlFor="app1FileUpload" className="mb-3">App1 FileUpload:</label>
          <span className="p-float-label p-input-icon-right w-full mt-2">
            <FileUpload accept=".csv, .txt"
                        ref={fileUploadRef1}
                        disabled={(!AccessType) || (app1_Import_type!=='0')}
                        // maxFileSize={500000000}
                        chooseOptions={chooseOptions}
                        uploadOptions={uploadOptions}
                        cancelOptions={cancelOptions}
                        itemTemplate={itemTemplateApp1Source}
                        multiple
                        customUpload
                        uploadHandler={app1FileUpload}
                        emptyTemplate={<p className="m-0">Drag and drop files to here to upload.</p>}/>
          </span>
       
    </>
  )
}

export default App1FileUpload;