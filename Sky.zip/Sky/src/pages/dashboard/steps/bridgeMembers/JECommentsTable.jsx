import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import {
    updateJECommentBridge, deleteInvalidJEComments, deleteJEComments, downloadJECommentsFile
} from "../../../../store/sliceReducers/BridgeMemberReducer";
import { Button } from "primereact/button";
import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { ConfirmPopup, confirmPopup } from 'primereact/confirmpopup';
import { InputText } from 'primereact/inputtext';
import { InputTextarea } from 'primereact/inputtextarea';
import { Dropdown } from 'primereact/dropdown';
import { FilterMatchMode, FilterOperator } from 'primereact/api';
import "./bridgeMembers.scss";

const JECommentsTable = () => {

    const dispatch = useDispatch();
    const [editingRows, setEditingRows] = useState({});
    const [globalFilterValue3, setGlobalFilterValue3] = useState('');
    const [filters3, setFilters3] = useState(null);

    const authData = useSelector((state) => state.auth);
    let { data } = authData.data;
    const AccessType = data.access_type.privilege === 0 ? true : false;


    const appTypeSource = [
        { label: 'App1', value: "APP1" },
        { label: 'App2', value: "APP2" },
        { label: 'Bridge', value: "BRIDGE" }
    ];

    const dimensions = useSelector(state =>
        state.bridgeMember.dimensions
    );

    const bridgeMembers = useSelector(state =>
        state.bridgeMember.bridgeMembers
    );

    const initFilters3 = () => {
        setFilters3({
            'global': { value: null, matchMode: FilterMatchMode.CONTAINS },
            'app_type': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'dim_id': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'source_member': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'comment': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
        });
        setGlobalFilterValue3('');
    }

    const selectedReconId = useSelector(state =>
        state.reconRun.selectedReconRunId
    );

    useEffect(() => {
        initFilters3();
    }, [])


    const clearFilter3 = () => {
        initFilters3();
    }

    const onGlobalFilterChange3 = (e) => {
        const value = e.target.value;
        let _filters3 = { ...filters3 };
        _filters3['global'].value = value;

        setFilters3(_filters3);
        setGlobalFilterValue3(value);
    }

    const downloadJeCommentsBridgeMemberData = () => {
        dispatch(downloadJECommentsFile(selectedReconId));
    }

    const deleteJECommentItems = (bridge_id, event, appType, isInValid) => {
        confirmPopup({
            target: event.currentTarget,
            message: 'Do you want to delete this record?',
            icon: 'pi pi-info-circle',
            acceptClassName: 'p-button-danger',
            accept: () => {
                if (isInValid) {
                    dispatch(deleteInvalidJEComments(bridge_id))
                }
                else {
                    dispatch(deleteJEComments(
                        {
                            "recon_id": selectedReconId,
                            "bridge_id": bridge_id,
                            "app_type": "2"
                        },
                        appType));
                }
            },
            reject: () => {
            }
        });
    }

    const jecommentsDelete = (rowData) => {
        return (
            <React.Fragment>
                <Button icon="pi pi-trash" disabled={!AccessType}
                    className="p-button-rounded  mx-1 bg-primary" onClick={(e) =>
                        deleteJECommentItems(rowData.bridge_id, e, "2", rowData.is_invalid)} />
            </React.Fragment>
        );
    }

    const jecommentRowEditComplete = (e) => {
        let { newData } = e;
        dispatch(updateJECommentBridge(
            {
                recon_id: selectedReconId,
                rows: [{
                    app_type: newData.app_type,
                    dim_id: newData.dim_id,
                    source_member: newData.source_member,
                    comment: newData.comment
                }]
            }));
    }

    const onRowEditChange = (e) => {
        if (AccessType === true) {
            setEditingRows(e.data)
        }
        else {
            return
        }
    }

    const getCommentsDimension = (dimId) => {
        if (!!dimId) {
            const app1DimensionIndex = dimensions.app1Dimension.findIndex(dim => dim.dimensions_id === dimId);
            const app2DimensionIndex = dimensions.app2Dimension.findIndex(dim => dim.dimensions_id === dimId);
            if (app1DimensionIndex > -1 || app2DimensionIndex > -1) {
                if (app1DimensionIndex > -1) {
                    return dimensions.app1Dimension[app1DimensionIndex]?.dimension;
                }
                else if (app2DimensionIndex > -1) {
                    return dimensions.app2Dimension[app2DimensionIndex]?.dimension;
                }
            }
            else {
                return dimId;
            }
        }
        else {
            return "--";
        }
    }

    const rowClassComments = (data) => {
        return {
            'bg-red-100': validateInValidDimension(data.dim_id, null, true)
        }
    }

    const validateInValidDimension = (dimId, dimension, isFromComment) => {
        if (dimId === null || !dimId) {
            return true;
        }
        else if (!!dimId) {
            if (isFromComment) {
                const app1DimensionIndex = dimensions.app1Dimension.findIndex(dim => dim.dimensions_id === dimId);
                const app2DimensionIndex = dimensions.app2Dimension.findIndex(dim => dim.dimensions_id === dimId);
                if (app1DimensionIndex > -1 || app2DimensionIndex > -1) {
                    return false;
                }
                else {
                    return true;
                }
            }
            else {
                const dimensionIndex = dimension.findIndex(dim => dim.dimensions_id === dimId);
                if (dimensionIndex > -1) {
                    return false;
                }
                else {
                    return true;
                }
            }
        }
    }

    const textEditor = (options) => {
        return <InputText type="text" value={options.value} onChange={(e) => options.editorCallback(e.target.value)} className="w-full" />;
    }

    const textAreaEditor = (options) => {
        return <InputTextarea type="text" value={options.value} onChange={(e) => options.editorCallback(e.target.value)} className="w-full" />;
    }

    const commentRowEditValidator = (rowData) => {
        if (!rowData['app_type']) {
            toast.error("Please select the appType");
            return false;
        }
        else if (!rowData['dim_id']) {
            toast.error("Please select the dimension");
            return false;
        }
        else if (!rowData['source_member']) {
            toast.error("Please enter the source member");
            return false;
        }

        else if (/[^a-zA-Z0-9\s]/.test(rowData['comment'])) {
            toast.error("Please enter the comment without comma");
            return false;
        }
        else if (!rowData['comment']) {
            toast.error("Please enter the comment");
            return false;
        }
        return true;
    }

    const commentsDimensionTemplate = (rowData) => {
        return (
            getCommentsDimension(rowData.dim_id)
        )
    }

    const commentsDimensionDropdownEditor = (options) => {
        return (
            <Dropdown value={options.value} options={options.rowData['app_Type']?.toLowerCase() === "app1" ?
                [...dimensions.app1Dimension] : options.rowData['app_Type']?.toLowerCase() === "app2" ? [...dimensions.app2Dimension] : [...dimensions.app1Dimension, ...dimensions.app2Dimension]}
                optionLabel="dimension" optionValue="dimensions_id"
                filter showClear filterBy="dimension" placeholder="Select a dimension"
                onChange={(e) => { options.editorCallback(e.value) }} className="w-full" />
        );
    }

    const commentsAppTypeDropdownEditor = (options) => {
        return (
            <React.Fragment>
                < Dropdown value={options.value} options={appTypeSource} optionLabel="label" optionValue="value"
                    onChange={(e) => { options.editorCallback(e.value) }} placeholder="select" className="w-full" />
            </React.Fragment>
        );
    }

    const renderHeader4 = () => {
        return (
            <div className="flex justify-content-end">

                <span className="p-input-icon-left">
                    <i className="pi pi-search" />
                    <InputText value={globalFilterValue3} onChange={onGlobalFilterChange3} placeholder="Search" />
                </span>
                <Button type="button"
                    icon="pi pi-filter-slash"
                    title="Clear"
                    className="p-button-rounded mx-1 bg-primary" onClick={clearFilter3} />
                <Button icon="pi pi-download"
                    disabled={!AccessType}
                    onClick={downloadJeCommentsBridgeMemberData}
                    className="p-button-rounded mx-1 bg-primary"
                    title="Download JE Comments" />

            </div>
        )
    }
    const header4 = renderHeader4();
    return (
        <>
            <ConfirmPopup />
            <DataTable value={bridgeMembers.jecomments}
                className="p-2"
                id="jecommentsTable"
                rowClassName={rowClassComments}
                editMode="row"
                editingRows={editingRows}
                onRowEditChange={onRowEditChange}
                rowEditValidator={commentRowEditValidator}
                onRowEditComplete={jecommentRowEditComplete}
                dataKey="bridge_id"
                showGridlines
                sortMode="multiple"
                removableSort
                filterDisplay="menu"
                globalFilterFields={['app_type', 'dim_id', 'source_member', 'comment']}
                header={header4}
                filters={filters3}
                paginator
                paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
                currentPageReportTemplate="Showing {first} to {last} of {totalRecords}"
                rows={10}
                rowsPerPageOptions={[10, 20, 50]}>
                <Column style={{ width: '12%' }} field="app_type"
                    header="App Type" sortable filter
                    editor={(options) => commentsAppTypeDropdownEditor(options)}></Column>
                <Column style={{ width: '20%' }} field="dim_id"
                    header="Dimension" body={commentsDimensionTemplate}
                    sortable filter
                    editor={(options) => commentsDimensionDropdownEditor(options)}></Column>
                <Column style={{ width: '20%' }} field="source_member"
                    header="Source Member" sortable filter
                    editor={(options) => textEditor(options)}></Column>
                <Column style={{ width: '35%' }} field="comment"
                    header="Comments" sortable filter
                    editor={(options) => textAreaEditor(options)}></Column>
                <Column style={{ width: '7%' }} rowEditor header="Edit"></Column>
                <Column style={{ width: '8%' }} align="center" body={jecommentsDelete}
                    header="Action" ></Column>
            </DataTable>
        </>
    )
}
export default JECommentsTable;