import React,{useState} from "react";
import {
    getDirectConnectSourceData,DCDialogApp1
} from "../../../../store/sliceReducers/DirectConnectReducer";
import { useDispatch, useSelector } from "react-redux";
import "./runImport.scss";
import { Button } from "primereact/button";
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';
import { useFormik } from 'formik';
import { classNames } from 'primereact/utils';
import { InputText } from 'primereact/inputtext';
import { Dialog } from 'primereact/dialog';
import { getEmail } from '../../../../utils/utils';
import DirectConnectTableApp1 from "../direct connect/DirectConnectTableApp1";

const App1Job = () => {
    const dispatch = useDispatch();
    const authData = useSelector((state) => state.auth);
    let { data } = authData.data;
    const AccessType = data.access_type.privilege === 0 ? true : false;
    const email = getEmail();
    const selectedReconId = useSelector(state =>
        state.reconRun.selectedReconRunId
    );
    
    const DC=useSelector(state =>
        state.DirectConnect
      );

    const app1_Import_type=useSelector(state =>
        state.dimField.reconDetails.app1_import_type
    );
  
   
    const reconForm1 = useFormik({
        initialValues: {
            app1jobname:''
        },
        validate: (data) => {
            let errors = {};

            if (!data.app1jobname) {
                errors.app1jobname = 'app1 job name is required.';
            }
            return errors;
        },
        onSubmit: (data) => {
               dispatch(getDirectConnectSourceData({
                "recon_id": selectedReconId,
                "jobname": data.app1jobname,
                "appType": 0,               
                "email": email
            }));
           data.app1jobname='';
           
        }
    });

  
    const isFormFieldValid = (name) => !!(reconForm1.touched[name] && reconForm1.errors[name]);
    const getFormErrorMessage = (name) => {
        return isFormFieldValid(name) && <small className="p-error">{reconForm1.errors[name]}</small>;
    };
    return (
        <>
        <p className="mt-0 ml-2">App1 Extract Data:</p>
          <form onSubmit={reconForm1.handleSubmit} className="p-fluid">
          
                    <div className="field p-2">
                        
                        <div className="formgrid grid">
                            <div className="col-8">
                                <span className="p-float-label p-input-icon-right">
                                    <InputText id="app1jobname" value={reconForm1.values.app1jobname}
                                               disabled={!AccessType}
                                               onChange={reconForm1.handleChange}
                                               className={classNames({ 'p-invalid': isFormFieldValid('app1jobname') })} placeholder="App1 Jobname" />
                                    <label htmlFor="app1jobname" className={classNames({ 'p-error': isFormFieldValid('app1jobname') })}>App1 Jobname*</label>
                                </span>
                                {getFormErrorMessage('app1jobname')}
                            </div>
                            <div className="col-4">
                                
                                    <Button type="submit"
                                            disabled={(!AccessType) || (app1_Import_type==='0')}
                                            label="" icon="pi pi-save" 
                                            className=" mx-1 bg-primary"
                                            tooltipOptions={{ "position": "top" }} 
                                            tooltip="Save Job Details" />
                            </div>
                        </div>
                    </div>
                </form>
              
                <Dialog header="Tag Headers to Dimensions" visible={DC.viewDialogApp1}
                        style={{ width: '95vw' }} 
                        onHide={() => dispatch(DCDialogApp1())} >
                    <DirectConnectTableApp1/>
                </Dialog> 
                
        </>
    )
}
export default App1Job;