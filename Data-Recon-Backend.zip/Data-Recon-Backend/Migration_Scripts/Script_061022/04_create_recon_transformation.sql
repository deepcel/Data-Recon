-- SEQUENCE: fileservice.recon_transformation_id_seq

DROP sequence if EXISTS fileservice.recon_transformation_id_seq CASCADE;

CREATE SEQUENCE fileservice.recon_transformation_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE fileservice.recon_transformation_id_seq
    OWNER TO postgres;

GRANT ALL ON SEQUENCE fileservice.recon_transformation_id_seq TO postgres;

GRANT ALL ON SEQUENCE fileservice.recon_transformation_id_seq TO "user_dataRecon_file";


-- Table: fileservice.recon_transformation

DROP TABLE if exists fileservice.recon_transformation CASCADE;

CREATE TABLE fileservice.recon_transformation
(
    id bigint NOT NULL DEFAULT nextval('fileservice.recon_transformation_id_seq'::regclass),
    recon_id bigint,
    app_id bigint,
    dim_id bigint,
	tgt_concat_dimid character varying COLLATE pg_catalog."default",
	tgt_concat_dimname character varying COLLATE pg_catalog."default",
	concat_delimiter "char",
	apply_all_members boolean,
    CONSTRAINT pk_recon_transformation_id PRIMARY KEY (id)
        USING INDEX TABLESPACE tbsp_data_recon
)

TABLESPACE tbsp_data_recon;

ALTER TABLE fileservice.recon_transformation
    OWNER to postgres;

GRANT ALL ON TABLE fileservice.recon_transformation TO postgres;

GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.recon_transformation TO "user_dataRecon_file";