import { createSlice } from "@reduxjs/toolkit";
import { toast } from "react-toastify";
import {
  makePostAPICall,
  makeZIPGetAPICallFileDownload,
  makePostAPICallFileDownloadrunreportexport
} from "../../utils/apiService";
import { redirectToLogin } from "../../utils/utils";
import { enableLoader, hideLoader } from "./LoadReducer";

// Dashboard reducer is used for handle all the steps data
export const runReportReducer = createSlice({
  name: "runreport",
  initialState: {
    loading: false,
    error: null,
    appData: [],
    runReport: {
      fixedheaders: [],
      changedheaders: [],
      rows: [],
      varThres:0,
      varCondition:'',
      columns:[],
      main_report: [],
      je_report: [],
      final_report: [],
      variance_percentage: "",
    },
  },

  reducers: {
    isLoading: (state, action) => {
      state.loading = true;
    },

    INVALID_SESSION: (state) => {
      state.loading = false;
      state.error = null;
    },

    RECON_LOAD_RUN_REPORT: (state, action) => {
      state.loading = false;
      state.error = null;
      // state.runReport.fixedheaders = [...action.payload.response.headers];
        // state.runReport.rows = [...action.payload.response.rows];
      // state.runReport.main_report = [...action.payload.response.main_report];
      // state.runReport.je_report = [...action.payload.response.je_report];
      // state.runReport.final_report = [...action.payload.response.final_report];
      // state.runReport.variance_percentage = [
      //   ...action.payload.response.variance_percentage,
      // ];

     // console.log(action.payload.response.variance_percentage);
      // state.runReport.fixedheaders = [...action.payload.response.headers];
      // if (Array.isArray(action.payload.response.headers)) {
      //   state.runReport.fixedheaders = [...action.payload.response.headers];
      // } else {
      //   //Handle the case where headers is not an array
      //   state.runReport.fixedheaders = [];
      // }
      if (Array.isArray(action.payload.response.headers)) {
        state.runReport.fixedheaders = [...action.payload.response.headers];
      } else if (typeof action.payload.response.headers === 'object') {
        // If headers is an object but not an array, convert it to an array
        state.runReport.fixedheaders = Object.entries(action.payload.response.headers);
      } else {
        //Handle the case where headers is not an array or object
        state.runReport.fixedheaders = [];
      }
      // state.runReport.rows = [...action.payload.response.rows];
      state.runReport.main_report = [...action.payload.response.main_report];
      if (Array.isArray(action.payload.response.main_report)) {
        state.runReport.main_report = [...action.payload.response.main_report];
      } else {
        //Handle the case where main_report is not an array
        state.runReport.main_report = [];
      }
      state.runReport.je_report = [...action.payload.response.je_report];
      if (Array.isArray(action.payload.response.je_report)) {
        state.runReport.je_report = [...action.payload.response.je_report];
      } else {
        //Handle the case where je_report is not an array
        state.runReport.je_report = [];
      }
      state.runReport.final_report = [...action.payload.response.final_report];
      if (Array.isArray(action.payload.response.final_report)) {
        state.runReport.final_report = [...action.payload.response.final_report];
      } else {
        //Handle the case where final_report is not an array
        state.runReport.final_report = [];
      }
      state.runReport.variance_percentage = [
        ...action.payload.response.variance_percentage,
      ];
      if (Array.isArray(action.payload.response.variance_percentage)) {
        state.runReport.variance_percentage = [
          ...action.payload.response.variance_percentage,
        ];
      } else {
        // Handle the case where variance_percentage is not an array
        state.runReport.variance_percentage = action.payload.response.variance_percentage;
      }
    },
    RECON_LOAD_RUN_REPORT_FILTER: (state, action) => {
      state.loading = false;
      state.error = null;
      state.runReport.changedheaders = [...action.payload.newdata.colList];
      // state.runReport.rows = [...action.payload.response.rows];
      state.runReport.main_report = [...action.payload.response.main_report];
      state.runReport.je_report = [...action.payload.response.je_report];
      state.runReport.final_report = [...action.payload.response.final_report];
      state.runReport.variance_percentage = [
        ...action.payload.response.variance_percentage,
      ];
    },
    RECON_LOAD_RUN_REPORT_EMPTY: (state, action) => {
      state.loading = false;
      state.error = null;
      state.runReport.headers = [];
    },
    // UPDATE_VARIANCE_VALUES:(state, action)=>{
    //   state.loading = false;
    //   state.error = null;
    //   state.varThres=action;
    //   state.varCondition=action;
    // },
    UPDATE_COLUMNS: (state, action) => {
      state.loading = false;
      state.error = null;
      state.columns=[action.payload]
      console.log(state.columns)
    },
  },
});

// Action creators are generated for each case reducer function
export const {
  isLoading,
  //UPDATE_VARIANCE_VALUES,
  UPDATE_COLUMNS,
  RECON_LOAD_RUN_REPORT,
  RECON_LOAD_RUN_REPORT_FILTER,
  RECON_LOAD_RUN_REPORT_EMPTY,
  INVALID_SESSION,
} = runReportReducer.actions;

export const updateColumns = (payload) => async (dispatch) => {
  console.log(payload)
  dispatch(UPDATE_COLUMNS({payload:payload}))
}

export const runReportPost = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePostAPICall("report/run", payload);
    if (response.status === 200) {
      dispatch(
        RECON_LOAD_RUN_REPORT({
          response,
        })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      dispatch(
        RECON_LOAD_RUN_REPORT_EMPTY({
          response: [],
        })
      );
      toast.info("Please click on the refresh data button");
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
    dispatch(
      RECON_LOAD_RUN_REPORT({
        response: {},
      })
    );
  }
};

export const runReportPostFilter = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePostAPICall("report/run", payload);
    
    if (response.status === 200) {
     
      // dispatch(
      //   RECON_LOAD_RUN_REPORT({
      //     response,
      //   })
      // );
      dispatch(
        RECON_LOAD_RUN_REPORT_FILTER({
          response: response,
          newdata: payload,
        })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
      dispatch(
        RECON_LOAD_RUN_REPORT_EMPTY({
          response: [],
        })
      );
    }
    dispatch(hideLoader({ loading: false }));
  } catch (err) {
    dispatch(hideLoader({ loading: false }));
    dispatch(
      RECON_LOAD_RUN_REPORT({
        response: {},
      })
    );
  }
};

export const exportrunreport = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePostAPICallFileDownloadrunreportexport(
      "report/run/export",
      payload
    );
    if (response.status === 200) {
      toast.success("Download triggered successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else if (response.status === 6002) {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const archiveRunReport = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makeZIPGetAPICallFileDownload(
      "report/run/archive/",
      payload
    );
    if (response.status === 200) {
      toast.success("Download triggered successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const defaultAPIcall = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePostAPICall("bridge/default", payload);
    if (response.status === 200) {
      // dispatch(listBridgeMembers (payload.recon_id));
      toast.success("Source members are defaulted to bridge members");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export default runReportReducer.reducer;
