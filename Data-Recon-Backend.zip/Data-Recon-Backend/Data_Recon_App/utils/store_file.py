import os
import datetime
from django.core.files.storage import default_storage
from django.conf import settings
from django.core.files.base import ContentFile

'''
<!---------- Method to store the uploaded file to django media
             folder and return filename, filepath as a response ----------!>
'''


def store_file(recon_id, file_obj):
    filename = []
    file_path = []
    time_stamp = int(round(datetime.datetime.now().timestamp()))
    if type(file_obj) is list:
        if file_obj[0] == 'je':
            je = True
            file_obj.pop(0)
        else:
            je = False
        for file in range(len(file_obj)):
            time_stamp = int(round(datetime.datetime.now().timestamp()))
            if je:
                filename.append('je_'+str(time_stamp) + '_Recon' + str(recon_id) + '_' + str(file_obj[file]))
            else:
                filename.append(str(time_stamp) + '_Recon' + str(recon_id) + '_' + str(file_obj[file]))
            save_path = default_storage.save(str(recon_id) + '/' + str(filename[file]),
                                             ContentFile(file_obj[file].read()))
            save_file = os.path.join(settings.MEDIA_ROOT, save_path)
            file_path.append((str(save_file)).replace('\\', '/'))
        return [filename, file_path]
    else:
        filename = str(time_stamp) + '_Recon' + str(recon_id) + '_' + file_obj.name
        save_path = default_storage.save(str(recon_id) + '/' + filename, ContentFile(file_obj.read()))
        save_file = os.path.join(settings.MEDIA_ROOT, save_path)
        file_path = (str(save_file)).replace('\\', '/')
        return [filename, file_path]
