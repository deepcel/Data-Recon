from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from . import views

urlpatterns = [
    path('forgot', views.forgot_password, name='forgotPassword'),
    path('reset', views.reset_password, name='resetPassword'),
    path('user/invite', views.user_invite, name='userInvite'),
    path('user/add', views.user_add, name='userAdd'),
    path('user/list', views.user_list, name='user_list'),
    path('invite/list', views.invite_list, name='invite_list'),
    path('user/update', views.update_user, name='update_user'),
    path('user/delete', views.user_delete, name='delete_user'),
    path('user/info', views.user_info, name='user_info'),
    path('user/resend', views.resend_invite, name='resend_invite'),
    path('user/onestream_config', views.onestream_config, name='onestream_config'),

]

urlpatterns = format_suffix_patterns(urlpatterns)
