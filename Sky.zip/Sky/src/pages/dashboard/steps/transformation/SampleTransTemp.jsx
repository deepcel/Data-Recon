import React from "react";
import { saveAs } from "file-saver";
import { Button } from "primereact/button";
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';
import Paper from '@mui/material/Paper';

const SampleTransTemplate = () => {
 
    const handleDownload = () => {
        const csvData = 'Column 1, Column 2, Column 3\nValue 1, Value 2, Value 3'; // Replace this with your CSV data
        const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
        saveAs(blob, 'DimensionTemplate.csv');
      };

  return (
    <>     
     <Paper variant="outlined">
            <div className="card flex justify-content-start ml-2 mt-1 pb-0">
                <span style={{fontSize: '1.02rem'}}>Download and view sample templates </span>
             </div>
             
             <Button icon="pi pi-download"  
                     label="Sync Template"
                     title="Download sample SYNC template"
                     className="p-button-success m-2 bg-primary" 
                     onClick={handleDownload} />
             
          
     </Paper>      
    </>
  )
}

export default SampleTransTemplate;