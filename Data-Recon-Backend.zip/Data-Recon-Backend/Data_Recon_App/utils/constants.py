INVITE_CONTENT = 'You are invited to Data Recon Application. ' \
                 'Please click the button to redirect to the join page.'

WELCOME_CONTENT = 'You are successfully registered to Data Recon. ' \
                  'Please click the below button to redirect to the home page.'

RESET_CONTENT = 'You had requested to change the password in Data Recon. ' \
                'Please click the below button.'

REACT_APP_URL = 'http://3.222.217.226:3000/'
