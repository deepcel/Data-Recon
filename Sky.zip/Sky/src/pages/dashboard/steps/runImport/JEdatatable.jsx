import React, { useState, useEffect } from "react";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { exportJournalEntry, updateJeTable, deleteJERunImport } from "../../../../store/sliceReducers/RunImportReducer";
import { useDispatch, useSelector } from "react-redux";
import "./runImport.scss";
import { Button } from "primereact/button";
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import { ConfirmPopup, confirmPopup } from 'primereact/confirmpopup';
import 'primeflex/primeflex.css';
import { InputText } from 'primereact/inputtext';

const JEdatatable = () => {
    const dispatch = useDispatch();
    const authData = useSelector((state) => state.auth);
    let { data } = authData.data;
    const AccessType = data.access_type.privilege === 0 ? true : false;
    const [editingRows, setEditingRows] = useState({});
    const [JERowData, setJERowData] = useState([]);
    const [filteredHeaders1, setFilteredHeaders1] = useState([]);
    const [editableColumns, setEditableColumns] = useState([]);

    const selectedReconId = useSelector(state =>
        state.reconRun.selectedReconRunId
    );

    const runImportData = useSelector(state =>
        state.runImport.runImportData
    );

    let filteredheaders = [...runImportData.jeheaders];
    // console.log(filteredheaders)
    filteredheaders = filteredheaders.filter(item => item !== 'record_id');
    // let emptyJERow = [];
    // let emptyJERow = {
    //     column1: '',
    //     column2: '',
    //     column3: '',
    //     column4: '',
    //     column5: '',
    //     column6: '',
    //     column7: '',
    //   };
    // runImportData.jeheaders.forEach(element => {
    //     const data = {
    //         [element]: ''
    //     }
    //     emptyJERow.push(data)
    // });

    const JEdownloadSourceData = () => {
        dispatch(exportJournalEntry({
            "recon_id": selectedReconId,
            "je_flag": true
        }));
    }

    useEffect(() => {
        setJERowData(runImportData.jerows);
    }, [runImportData.jerows]);

    // const Addrow = () => {
    //     setJERowData([emptyJERow, ...JERowData])
    // }

    const Addrow = () => {
        const newRow = {};
        runImportData.jeheaders.forEach(header => {
            newRow[header] = '';
        });
        setJERowData([newRow, ...JERowData]);
    }

    // const Addrow = () => {
    //     const newRow = {};
    //     const headers = runImportData.jeheaders;

    //     if (!headers || headers.length === 0) {
    //         const columnName = window.prompt('Enter column name');
    //         const columnValue = window.prompt('Enter column value');
    //         newRow[columnName] = columnValue;
    //     } else {
    //         headers.forEach(header => {
    //             newRow[header] = '';
    //         });
    //     }

    //     setJERowData([newRow, ...JERowData]);
    // };

    // const Addrow = () => {
    //     const newRow = {};
    //     const headers = runImportData.jeheaders;

    //     if (!headers || headers.length === 0) {
    //         const columnName = window.prompt('Enter column name');
    //         const columnValue = window.prompt('Enter column value');
    //         newRow[columnName] = columnValue;

    //         // Add the new column to the filteredheaders and editableColumns arrays
    //         setFilteredHeaders1([...filteredHeaders1, columnName]);
    //         if (columnName === 'column1' || columnName === 'column2') {
    //             setEditableColumns([...editableColumns, columnName]);
    //         }
    //     } else {
    //         headers.forEach(header => {
    //             newRow[header] = '';
    //         });
    //     }

    //     setJERowData([newRow, ...JERowData]);
    // };


    const onRowEditChange = (e) => {
        console.log(e);
        if (AccessType === true) {
            setEditingRows(e.data)
            // const { index, editing } = e;
            // setEditingRows(prevState => ({
            //     ...prevState,
            //     [index]: editing
            // }));

        }
        else {
            return
        }
    }

    const JERowEditComplete = (event, col) => {
        const editedRow = event.newData;
        const recordId = editedRow['record_id'];
        const app_id = editedRow['App1-App2'] === 'App1' ? 0 : 1;

        // Remove the App1-App2 property from the editedRow object
        delete editedRow['App1-App2'];

        const updatedDataForBackend = {
            recon_id: selectedReconId,
            app_type: app_id,
            record_id: recordId,
            rows: [{
                YEAR: editedRow['YEAR-YEAR'],
                PERIOD: editedRow['PERIOD-PERIOD'],
                AMOUNT: editedRow['AMOUNT-AMOUNT'],
                ENTITY: editedRow['ENTITY-ENTITY'],
                VIEW: editedRow['VIEW-VIEW'],
                ACCOUNT: editedRow['ACCOUNT-ACCOUNT']
            }],
        };

        dispatch(updateJeTable(updatedDataForBackend));
    };

    // const JERowEditComplete = (event, col) => {

    //     console.log(event)

    //     const editedRow = event.newData;

    //     const recordId = event.newData['record_id'];

    //     const app_id = event.newData['App1-App2'] === 'App1' ? 0 : 1;

    //     // Remove the App1-App2 property from the editedRow object

    //     delete editedRow['App1-App2'];

    //     delete editedRow.je_comment;

    //     delete editedRow.record_id;

    //     const newRow = [Object.entries(editedRow).reduce((acc, [key, value]) => {

    //         const newKey = key.replace(/-\w+$/, '');

    //         acc[newKey] = value;

    //         return acc;

    //     }, {})];

    //     console.log(editedRow)

    //     console.log(newRow)

    //     dispatch(updateJeTable({

    //         "recon_id": selectedReconId,

    //         "app_type": app_id,

    //         "record_id": recordId,

    //         "rows": newRow,

    //     }));

    // };

    const textEditor = (options) => {
        return <InputText type="text" value={options.value} onChange={(e) => options.editorCallback(e.target.value)} className="w-full" />;
    }

    const renderHeader2 = () => {
        return (
            <div className="flex justify-content-end">
                {/* <Button icon="pi pi-plus"
                    disabled={!AccessType}
                    className="p-button-rounded  ml-1 bg-primary"
                    title="Add New Row"
                    onClick={Addrow} /> */}

                <Button icon="pi pi-download"
                    disabled={!AccessType}
                    onClick={JEdownloadSourceData}
                    className="p-button-rounded  mx-1 bg-primary"
                    title="Download journal entry data" />
            </div>
        )
    }

    const deleteJECommentsRunImport = (record_id, event, appType) => {
        confirmPopup({
            target: event.currentTarget,
            message: 'Do you want to delete this record?',
            icon: 'pi pi-info-circle',
            acceptClassName: 'p-button-danger',
            accept: () => {
                dispatch(deleteJERunImport({
                    "recon_id": selectedReconId,
                    "record_id": record_id,
                    "app_type": appType,
                }));
            },
            reject: () => {
            }
        });
    }

    const jeDeleteRunImport = (rowData) => {
        const appType = rowData['App1-App2'] === 'App1' ? '0' : '1';
        return (
            <React.Fragment>
                <Button
                    icon="pi pi-trash"
                    disabled={!AccessType}
                    className="p-button-rounded mx-1 bg-primary"
                    onClick={(e) => deleteJECommentsRunImport(rowData.record_id, e, appType)}
                />
            </React.Fragment>
        );
    };

    const header2 = renderHeader2();
    return (
        <>
            {
                !JERowData && <div>
                    Please upload a app1 & app2 file.
                </div>
            }
            <ConfirmPopup />
            <DataTable
                id="JErunImportTable"
                value={JERowData}
                editMode="row"
                editingRows={editingRows}
                onRowEditChange={onRowEditChange}
                // onRowEditInit={onRowEditInit}
                onRowEditComplete={JERowEditComplete}
                column
                // dataKey="index"
                dataKey="record_id"
                showGridlines
                scrollable
                scrollDirection="both"
                sortMode="multiple"
                scrollHeight="500px"
                paginator
                header={header2}
                paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
                currentPageReportTemplate="Showing {first} to {last} of {totalRecords}"
                rows={10}
                filterDisplay="menu"
                removableSort
                rowsPerPageOptions={[10, 20, 50]}>
                {
                    filteredheaders?.map((col, i) => {
                        return (
                            <Column
                                field={col}
                                header={col}
                                style={{ "width": "15%" }}
                                className="ellipsify"
                                editor={(options) => textEditor(options, col)}
                                sortable
                                filter
                            />
                        );
                    })
                }
                {/* <Column
                    style={{ width: '8%' }}
                    rowEditor
                    header="Edit"
                />
                <Column
                    style={{ width: '8%' }}
                    align="center"
                    header="Action"
                    body={jeDeleteRunImport}
                /> */}
            </DataTable>

            {/* <DataTable
                id="JErunImportTable"
                value={JERowData}
                editMode="row"
                editingRows={editingRows}
                onRowEditChange={onRowEditChange}
                onRowEditComplete={JERowEditComplete}
                column
                dataKey="record_id"
                showGridlines
                scrollable
                scrollDirection="both"
                sortMode="multiple"
                scrollHeight="500px"
                paginator
                header={header2}
                paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
                currentPageReportTemplate="Showing {first} to {last} of {totalRecords}"
                rows={10}
                filterDisplay="menu"
                removableSort
                rowsPerPageOptions={[10, 20, 50]}
            >
                {filteredHeaders1?.map((col, i) => {
                    return (
                        <Column
                            field={col}
                            header={col}
                            style={{ width: "15%" }}
                            className="ellipsify"
                            editor={(options) => textEditor(options, col)}
                            sortable
                            filter
                        />
                    );
                })}
                {filteredHeaders1?.length > 0 && editableColumns.some(col => filteredHeaders1.includes(col)) && (
                    <>
                        <Column style={{ width: "8%" }} rowEditor header="Edit" />
                        <Column
                            style={{ width: "8%" }}
                            align="center"
                            header="Action"
                            body={jeDeleteRunImport}
                        />
                    </>
                )}
                {runImportData.jeheaders?.length > 0 && (
                    <>
                        <Column style={{ width: "8%" }} rowEditor header="Edit" />
                        <Column
                            style={{ width: "8%" }}
                            align="center"
                            header="Action"
                            body={jeDeleteRunImport}
                        />
                    </>
                )}
                {Object.keys(JERowData[0] || {}).length > filteredHeaders1?.length && (
                    <>

                    </>
                )}
                <Column style={{ width: "8%" }} rowEditor header="Edit" />
                <Column
                    style={{ width: "8%" }}
                    align="center"
                    header="Action"
                    body={jeDeleteRunImport}
                />
            </DataTable> */}
        </>
    )
}

export default JEdatatable;