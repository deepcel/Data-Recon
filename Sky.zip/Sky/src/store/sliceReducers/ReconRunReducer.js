import { createSlice } from "@reduxjs/toolkit";
import { toast } from "react-toastify";
import {
    makeGetAPICall,
    makeDeleteAPICall,
    makePostAPICall,
    makePutAPICall,
    makePutAPIFormData,
    makeGetAPICallFileDownload,
  } from "../../utils/apiService";
  import { redirectToLogin } from "../../utils/utils";
  import { enableLoader, hideLoader } from "./LoadReducer";
  
  // Dashboard reducer is used for handle all the steps data
  export const reconRunReducer = createSlice({
    name: "reconRun",
    initialState: {
        loading: false,
        appData: [],
        selectedReconRunId:"",
        selectedRecon: {
            recon_id: "",
            reconName: "",
            app1_import_type:"",
            app2_import_type:""
          },
        dimensions: {
            app1Dimension: [],
            app2Dimension: [],
            dimensionsimport: [],
          },
        error: null,
    },
    reducers: {
        isLoading: (state, action) => {
          state.loading = true;
        },
        VALIDATE_SESSION: (state, action) => {
          state.loading = false;
          state.error = null;
          state.appData = [action.payload.data];
        },
        INVALID_SESSION: (state) => {
            state.loading = false;
            state.error = null;
          },
        setSelectedReconRunId: (state, action) => {
            state.selectedReconRunId = action.payload;
            // state.runBridge = {
            //   headers: [],
            //   rows: [],
            //   unMapped: [],
            // };
          },
        RECON_ADD: (state, action) => {
          state.loading = false;
          state.error = null;
          state.appData[0].unshift(action.payload.data);
        },
         //update existing dimensions
         RECON_UPDATE: (state, action) => {
          state.loading = false;
          state.error = null;     
          let index = state.appData[0].findIndex((p) => {
            return p.recon_id === action.payload.recon_id; });
            state.appData[0][index] = action.payload.response.data;
           state.dimensions.dimensionsimport = [...action.payload.response.data.dimensions,];
        },
        RECON_UPDATE_DIMENSIONS: (state, action) => {
          state.loading = false;
          state.error = null;
          let index = state.appData[0].findIndex((p) => {
            return p.recon_id === action.payload.recon_id;
          });
          state.appData[0][index].dimensions = action.payload.response.data;
        },
        //importing dimensions
        RECON_IMPORT_DIMENSIONS: (state, action) => {
          state.loading = false;
          state.error = null;
          state.dimensions.dimensionsimport = [...action.payload.response.rows];
        },
       
        RECON_DELETE: (state, action) => {
          state.loading = false;
          state.error = null;
          state.appData[0] = state.appData[0].filter(
            (data) => data.recon_id !== action.payload
          );
        },
    },
});

export const {
    isLoading,
    INVALID_SESSION,
    VALIDATE_SESSION,
    setSelectedReconRunId,
    RECON_ADD,
    RECON_UPDATE,
    RECON_UPDATE_DIMENSIONS,  
    RECON_IMPORT_DIMENSIONS ,
    RECON_DELETE,    
  } = reconRunReducer.actions;
  
// Create recon run
export const createReconRun = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePostAPICall("recon/create", payload);
    if (response.status === 200) {
      dispatch(RECON_ADD(response));
      toast.success("Recon Run Name is created successfully");
    } else if (response.status === 6001) {
      toast.error(
        "Recon Run Name is duplicated, please enter unique Recon RunName"
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const reorderDimension = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPICall("recon/dim/order/update", payload);
    if (response.status === 200) {
      dispatch(
        RECON_UPDATE_DIMENSIONS({
          response: response,
          recon_id: payload.recon_id,
        })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const downloadApp1App2DimensionsFile = (payload) => async (dispatch) => {
  try {
    dispatch(isLoading({ loading: true }));
    const response = await makeGetAPICallFileDownload(
      "recon/dim/export/",
      payload
    );
    if (response.status === 200) {
      toast.success("Download triggered successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};


//dimension tab import export
export const dimensionsImport = (formData) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPIFormData("recon/dim/import", formData);
    if (response.status === 200) {
      dispatch(
        RECON_IMPORT_DIMENSIONS({
          response: response,
        })
      );
      toast.success("File imported successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

// Update recon dimension
export const updateReconDimension = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPICall("recon/update", { data: payload });
    if (response.status === 200) {
      dispatch(
        RECON_UPDATE({
          response: response,
          recon_id: payload.recon_id,
        })
      );
      toast.success("ReconRun is updated successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

// Get all the recon run list
export const listReconRun = () => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makeGetAPICall("recon/list");
    if (response.status === 200) {
      dispatch(VALIDATE_SESSION(response));
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

// Delete recon run based on reconid
export const deleteReconRun = (reconId) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makeDeleteAPICall("recon/delete/" +reconId);
    if (response.status === 200) {
      dispatch(RECON_DELETE(reconId));
      toast.success("Recon Run is deleted successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};
// Update specific/particular recon details
export const updateReconRun = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPICall("recon/update", { data: payload });
    if (response.status === 200) {
      dispatch(
        RECON_UPDATE({
          response: response,
          recon_id: payload.recon_id,
        })
      );
      toast.success("ReconRun is updated successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const updateSelectedReconRunId = (payload) => async (dispatch) => {
  dispatch(setSelectedReconRunId(payload));
};


// Get Recon details with dimension
export const listReconRunDimension = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makeGetAPICall("recon/info/" + payload);
    if (response.status === 200) {
      dispatch(
        RECON_UPDATE({
          response: response,
          recon_id: payload,
        })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export default reconRunReducer.reducer;