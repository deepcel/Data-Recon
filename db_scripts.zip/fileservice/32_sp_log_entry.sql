CREATE OR REPLACE PROCEDURE fileservice.sp_log_entry(app_id integer, status text, recon_id integer DEFAULT NULL::integer, table_name text DEFAULT NULL::text)
 LANGUAGE plpgsql
AS $procedure$
declare
s_schema_name text := 'fileservice';
s_tracker_table text := 'track_app_data_table';
var_script text := '';
begin 

--	raise notice 'Log1: % % % %',app_id, status, recon_id, table_name;

	if (recon_id is null) and (table_name is null)
		then
			var_script = 'insert into ' || s_schema_name || '.' || s_tracker_table || ' (application_id, log_comment, created_date)';
			var_script = var_script || 'values (' || app_id || ',' || status || ',''' ||localtimestamp||'''::timestamp);';	
	elsif (app_id is null) and (table_name is null)
		then
			var_script = 'insert into ' || s_schema_name || '.' || s_tracker_table || '(recon_id, log_comment, created_date)';
			var_script = var_script || ' values (' || recon_id || ',' || status || ', ''' || localtimestamp || '''::timestamp);';
	elsif (app_id is null) 
		then 
			var_script = 'insert into ' || s_schema_name || '.' || s_tracker_table || ' (recon_id,  table_name, log_comment, created_date)';
			var_script = var_script || ' values (' || recon_id || ',''' || table_name || ''', '||status||',''' || localtimestamp || '''::timestamp);';
	else
			var_script = 'insert into ' || s_schema_name || '.' || s_tracker_table || ' (recon_id, application_id, table_name, log_comment, created_date)';
			var_script = var_script || ' values (' || recon_id || ',' || app_id || ',''' || table_name || ''', '||status||',''' || localtimestamp || '''::timestamp);';
	end if;
	
--	raise notice 'log2: %', var_script;
-- Run insert into trakcer table
	execute var_script;
	commit;
end;

$procedure$
;

-- Permissions

ALTER PROCEDURE fileservice.sp_log_entry(int4, text, int4, text) OWNER TO "user_dataRecon_file";
GRANT ALL ON PROCEDURE fileservice.sp_log_entry(int4, text, int4, text) TO public;
GRANT ALL ON PROCEDURE fileservice.sp_log_entry(int4, text, int4, text) TO postgres;
GRANT ALL ON PROCEDURE fileservice.sp_log_entry(int4, text, int4, text) TO "user_dataRecon_file";
