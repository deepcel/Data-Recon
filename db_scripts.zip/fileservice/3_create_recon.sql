-- SEQUENCE: fileservice.recon_recon_id_seq

DROP SEQUENCE IF EXISTS fileservice.recon_recon_id_seq cascade;

CREATE SEQUENCE fileservice.recon_recon_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE fileservice.recon_recon_id_seq
    OWNER TO "user_dataRecon_file";

GRANT ALL ON SEQUENCE fileservice.recon_recon_id_seq TO postgres;

GRANT ALL ON SEQUENCE fileservice.recon_recon_id_seq TO "user_dataRecon_file";

-- Table: fileservice.recon

DROP TABLE IF EXISTS fileservice.recon CASCADE;

CREATE TABLE fileservice.recon (
	recon_id bigint NOT NULL DEFAULT nextval('fileservice.recon_recon_id_seq'::regclass),
	app1_id int8 NULL,
	app2_id int8 NULL,
	"name" varchar NULL,
	variance_threshold numeric NULL DEFAULT 0,
	execution_date time NULL,
	status varchar NULL,
	is_deleted bool NULL,
	description varchar NULL,
	created_by varchar NULL,
	created_date timestamp NULL,
	last_modified_by varchar NULL,
	last_modified_date timestamp NULL,
	CONSTRAINT pk_recon_id PRIMARY KEY (recon_id)
)
TABLESPACE tbsp_data_recon;

ALTER TABLE IF EXISTS fileservice.recon OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE fileservice.recon TO postgres;
GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.recon TO "user_dataRecon_file";