ALTER TABLE IF EXISTS fileservice.recon
    ADD COLUMN last_modified_date time without time zone;

ALTER TABLE IF EXISTS fileservice.recon
    ADD COLUMN last_modified_by character varying;

ALTER TABLE IF EXISTS fileservice.recon
DROP COLUMN dimensions_id;

ALTER TABLE IF EXISTS fileservice.recon
ALTER COLUMN last_modified_date TYPE timestamp without time zone
USING current_date + last_modified_date;
