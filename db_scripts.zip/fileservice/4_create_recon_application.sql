-- SEQUENCE: fileservice.recon_applications_recon_app_id_seq

DROP SEQUENCE  IF EXISTS fileservice.recon_applications_recon_app_id_seq cascade;

CREATE SEQUENCE fileservice.recon_applications_recon_app_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE fileservice.recon_applications_recon_app_id_seq
    OWNER TO "user_dataRecon_file";

GRANT ALL ON SEQUENCE fileservice.recon_applications_recon_app_id_seq TO postgres;

GRANT ALL ON SEQUENCE fileservice.recon_applications_recon_app_id_seq TO "user_dataRecon_file";


-- Table: fileservice.recon_applications

DROP TABLE  IF EXISTS fileservice.recon_applications cascade;
CREATE TABLE fileservice.recon_applications (
	recon_app_id bigint NOT NULL DEFAULT nextval('fileservice.recon_applications_recon_app_id_seq'::regclass),
	recon_id int8 NULL,
	app_name varchar NULL,
	import_type varchar NULL,
	import_delimiter varchar NULL,
	currency_symbol varchar NULL,
	currency_delimiter varchar NULL,
	has_header bool NULL,
	url varchar NULL,
	"cube" varchar NULL,
	username varchar NULL,
	"password" varchar NULL,
	filename varchar NULL,
	is_deleted bool NULL,
	CONSTRAINT pk_recon_app_id PRIMARY KEY (recon_app_id)
)
TABLESPACE tbsp_data_recon;

ALTER TABLE IF EXISTS fileservice.recon_applications
    OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE fileservice.recon_applications TO postgres;
GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.recon_applications TO "user_dataRecon_file";