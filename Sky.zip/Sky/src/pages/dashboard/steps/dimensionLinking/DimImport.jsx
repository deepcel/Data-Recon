import React, { useState,useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import { FileUpload } from 'primereact/fileupload';
import { Button } from "primereact/button";
import { getExtension, chooseOptions, uploadOptions, cancelOptions } from "../../../../utils/fileutils";
import { dimensionsImport } from "../../../../store/sliceReducers/ReconRunReducer";

import "./dimensionLinking.scss";
import { saveAs } from "file-saver";

const DimImport = () => {
  const dispatch = useDispatch();
  const authData = useSelector((state) => state.auth);
  let { data } = authData.data;
  const AccessType = data.access_type.privilege === 0 ? true : false;
  const fileUploadRef = useRef(null);
  
  const [totalSize, setTotalSize] = useState(0);
  const onTemplateRemove = (file, callback) => {
    setTotalSize(totalSize - file.size);
    callback();
  };

  const itemTemplate = (file, props) => {
    return (
      <div className="flex justify-content-between ">
        <div className="flex align-items-center" style={{ width: "40%" }}>
          <span className="flex flex-column text-left ml-3">{file.name}</span>
        </div>

        <Button
          icon="pi pi-times"
          className="p-button-secondary"
          onClick={() => onTemplateRemove(file, props.onRemove)}
        />
      </div>
    );
  };

  const selectedReconId = useSelector(state =>
    state.reconRun.selectedReconRunId
  );

  const dimensionFile = (files) => {
    const supportedFileFormat = ["csv", "txt"];
    const [file] = files;
    if (file) {
      if (!supportedFileFormat.includes(getExtension(file.name))) {
        toast.error("Unsupported file format, Please upload valid files(.csv,.txt)");
        return;
      }
    }
    const fileReader = new FileReader();
    fileReader.onload = (e) => {
      let formData = new FormData();
      formData.append('Dim_File', file);
      formData.append('recon_id', selectedReconId);
      dispatch(dimensionsImport(formData));
      fileUploadRef.current.clear();
    };
    fileReader.readAsDataURL(file);
  }

  const dimensionsFileUpload = ({ files }) => {
    dimensionFile(files);
  };

  const handleDownload = () => {
    const csvData = 'slno,dimension,dim in file,yes type field,no type top member,is_active,dimension,dim in file,yes type field,no type top member,is_active\n0, YEAR, YES, 1,,TRUE,YEAR,YES,1,,TRUE'; // Replace this with your CSV data
    const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
    saveAs(blob, 'DimensionTemplate.csv');
  };

  const headerTemplate = (options) => {
    const { className, chooseButton, uploadButton, cancelButton } = options;

    return (
      <div className={className} style={{ backgroundColor: 'transparent', display: 'flex', alignItems: 'center' }}>
        {chooseButton}
        {uploadButton}
        {cancelButton}
        <div className="flex align-items-center gap-3 ml-auto">
          <Button label="Dimension Template"
            icon="pi pi-download"
            className="p-button-success my-3 bg-primary"
            title="Download sample dimension template"
            onClick={handleDownload} />
        </div>
      </div>
    );
  };

  return (
    <>
      <div className="formgrid grid">

        <div className="col-12">
          <label htmlFor="dimensionsfileupload" className="mb-3">Import Dimensions</label>
          <span className="p-float-label p-input-icon-right mt-2 my-3 w-full">
            <FileUpload accept=".csv, .txt"
              ref={fileUploadRef}
              disabled={(selectedReconId === '' || !AccessType ? true : false)}
              maxFileSize={100000000}
              customUpload
              chooseOptions={chooseOptions}
              uploadOptions={uploadOptions}
              headerTemplate={headerTemplate}
              cancelOptions={cancelOptions}
              uploadHandler={dimensionsFileUpload}
              itemTemplate={itemTemplate}
              emptyTemplate={<p className="m-0">Drag and drop files to here to upload.</p>} />
          </span>
        </div>

      </div>

    </>
  );
}
export default DimImport;