from ...utils.get_recon import get_recon
from ...models import ReconBridgeMapping
from ..serializers import BridgeSerializer


'''
<!---------- Method to get save the structured data to db
             and return the structured data back ----------!>
'''


def save_bridge(bridge_data):
    recon_id = bridge_data['recon_id']
    app_type = bridge_data['app_type']
    recon_data = get_recon(recon_id)
    app_id = recon_data['app1_id'] if app_type == '0' else recon_data['app2_id']

    number_of_bridges = len(bridge_data['rows'])
    for i in range(0, number_of_bridges):
        bridge_data['rows'][i]['recon_id'] = recon_id
        bridge_data['rows'][i]['app_id'] = app_id
        bridge_data['rows'][i]['app_type'] = app_type

        # Save / Updating bridge
        if 'bridge_id' in bridge_data['rows'][i]:
            if ReconBridgeMapping.objects.filter(recon_id=recon_id,
                                                 bridge_id=bridge_data['rows'][i]['bridge_id']).exists():
                bridge_instance = ReconBridgeMapping.objects.filter(recon_id=recon_id,
                                                                    bridge_id=bridge_data['rows'][i]['bridge_id'])[0]
                if bridge_data['rows'][i]['dim_id']:
                    bridge_data['rows'][i]['is_invalid'] = False
                else:
                    bridge_data['rows'][i]['is_invalid'] = True
                serialized_bridge = BridgeSerializer(bridge_instance, data=bridge_data['rows'][i], partial=True)

                if serialized_bridge.is_valid():
                    serialized_bridge.save()
                else:
                    response_data = {
                        'status': 6002,
                        'message': serialized_bridge.errors
                    }
                    return response_data
        else:
            if ReconBridgeMapping.objects.filter(
                    app_id=app_id, dim_id=bridge_data['rows'][i]['dim_id'],
                    app_type=app_type, recon_id=recon_id,
                    source_member=bridge_data['rows'][i]['source_member'], is_deleted=False).exists():
                bridge_instance = ReconBridgeMapping.objects.filter(
                    app_id=app_id, dim_id=bridge_data['rows'][i]['dim_id'],
                    app_type=app_type, recon_id=recon_id,
                    source_member=bridge_data['rows'][i]['source_member'], is_deleted=False)[0]
                serialized_bridge = BridgeSerializer(bridge_instance, data=bridge_data['rows'][i], partial=True)
            elif ReconBridgeMapping.objects.filter(
                    app_id=app_id, dim_id=None,
                    app_type=app_type, recon_id=recon_id,
                    source_member=bridge_data['rows'][i]['source_member'], is_deleted=False).exists():
                bridge_instance = ReconBridgeMapping.objects.filter(
                    app_id=app_id, dim_id=None,
                    app_type=app_type, recon_id=recon_id,
                    source_member=bridge_data['rows'][i]['source_member'], is_deleted=False)[0]
                if bridge_data['rows'][i]['dim_id']:
                    bridge_data['rows'][i]['is_invalid'] = False
                else:
                    bridge_data['rows'][i]['is_invalid'] = True
                serialized_bridge = BridgeSerializer(bridge_instance, data=bridge_data['rows'][i], partial=True)
            else:
                serialized_bridge = BridgeSerializer(data=bridge_data['rows'][i])

            if serialized_bridge.is_valid():
                serialized_bridge.save()
            else:
                response_data = {
                    'status': 6002,
                    'message': serialized_bridge.errors
                }
                return response_data

    response_data = {
        'status': 200,
        'message': 'Saved successfully!'
    }
    return response_data
