import React from "react";
import "./select.scss";
// Sub components for create form and table
import CreateRecon from "./CreateRecon";
import ListOfRecons from "./ListOfRecons";
import { Card } from 'primereact/card';
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';

const Select = ({ setActiveStepWizard }) => {

    const setWizard = (rowData) => {
        setActiveStepWizard(1)
    }

    return (
        <React.Fragment>
            <Card className="shadow-5" >
                <div className="card m-0 p-0 p-sm-3 p-md-4" >
                    <CreateRecon />
                    <ListOfRecons setWiz={setWizard} />
                </div>
            </Card>
        </React.Fragment >
    );
}
export default Select;