import React,{useState} from "react";
import { useDispatch, useSelector } from "react-redux";
import "./runImport.scss";
import { Button } from "primereact/button";
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';
import { useFormik } from 'formik';
import { classNames } from 'primereact/utils';
import { InputText } from 'primereact/inputtext';
import { Dialog } from 'primereact/dialog';
import OneStreamApp1 from "../direct connect/OneStreamApp1";
const OSExtracApp1 = () => {
    const [visibleApp1, setApp1Visible] = useState(false);

    const app1_Import_type=useSelector(state =>
        state.dimField.reconDetails.app1_import_type
    );

    let showJob1=app1_Import_type==='0'?false:true;
    const hideApp1dialogue=()=>{
        setApp1Visible(false)
    }
    return (
       <>
            <p className="mt-0 ml-2">App1 Extract Data:</p>
            <Button type="button" id="ExtractApp1" label="Extract App1" className="bg-primary mx-2"
                    onClick={()=>{setApp1Visible(true)}}/>
                  
          
            <Dialog visible={visibleApp1}
                            header="App1 OneStream extraction"
                            className="center-header"
                            style={{ width: '60vw', height:'80vh' }} 
                            onHide={hideApp1dialogue}>
                      <OneStreamApp1/>  
           </Dialog> 
        </>
          
          
       
    )
}
export default OSExtracApp1;