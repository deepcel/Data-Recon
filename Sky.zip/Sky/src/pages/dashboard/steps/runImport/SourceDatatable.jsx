import React, { useEffect, useState } from "react";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import {
    getSourceData, exportrunimport,
    getJESourceData,
} from "../../../../store/sliceReducers/RunImportReducer";
import { useDispatch, useSelector } from "react-redux";
import "./runImport.scss";
import { Button } from "primereact/button";
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import { FilterMatchMode, FilterOperator } from 'primereact/api';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';
import { InputText } from 'primereact/inputtext';

const Sourcedatatable = () => {
    const dispatch = useDispatch();
    const authData = useSelector((state) => state.auth);
    let { data } = authData.data;
    const AccessType = data.access_type.privilege === 0 ? true : false;
    const [globalFilterValue1, setGlobalFilterValue1] = useState('');
    const [filters1, setFilters1] = useState(null);

    const selectedReconId = useSelector(state =>
        state.reconRun.selectedReconRunId
    );
    const runImportData = useSelector(state =>
        state.runImport.runImportData
    );
    let filteredheaders = [...runImportData.headers];
    // console.log(filteredheaders)
    filteredheaders = filteredheaders.filter(item => item !== 'record_id');
    useEffect(() => {
        dispatch(getSourceData({
            "recon_id": selectedReconId,
            "max_rows": 5000,
            "page_number": 1
        }));
        dispatch(getJESourceData({
            "recon_id": selectedReconId,
            "max_rows": 5000,
            "page_number": 1
        }));

        initFilters1();
    }, []);

    const clearFilter1 = () => {
        initFilters1();
    }

    const onGlobalFilterChange1 = (e) => {
        const value = e.target.value;
        let _filters1 = { ...filters1 };
        _filters1['global'].value = value;

        setFilters1(_filters1);
        setGlobalFilterValue1(value);
    }

    const initFilters1 = () => {
        setFilters1({
            'global': { value: null, matchMode: FilterMatchMode.CONTAINS },
            'App1-App2': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'Year-Years': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'YEAR-YEAR': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'bridge-YEAR-YEAR': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'PERIOD-PERIOD': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'bridge-PERIOD-PERIOD': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'ENTITY-ENTITY': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
	    'ENT-ENTITY': {operator: FilterOperator.AND, constraints: [{value: null, matchMode: FilterMatchMode.STARTS_WITH }]},
	    'ACCT-ACCOUNT': { operator: FilterOperator.AND, constraints: [{value:null, matchMode: FilterMatchMode.STARTS_WITH }]},
	    'FUNCTION-FUNCTION': {operator: FilterOperator.AND, constraints: [{value:null, matchMode: FilterMatchMode.STARTS_WITH }]},	
            'bridge-Entity-Entity': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'VIEW-VIEW': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'bridge-VIEW-VIEW': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'ACCOUNT-ACCOUNT': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'bridge-Account-Account': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'Period-Period': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'Entity-Ent': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'Value-Cons': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'Scenario-Scenario': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'Account-ACCT': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'Flows-Flow': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'Dim8-Origin': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'ICP-IC': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'DataSource-U1': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'Segment-U2': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'Dim12-Function': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'Dim13-U4': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'Geography-U5': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'Customer-U6': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'Dim16-U7': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'Census-Dim17': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'Dim18-U8': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'View-View': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'AMOUNT-AMOUNT': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
        });
        setGlobalFilterValue1('');
    }
    const downloadRunImport = () => {
        dispatch(exportrunimport({ "recon_id": selectedReconId, "je_flag": false }));
    }
    const renderHeader1 = () => {
        return (
            <div className="flex justify-content-end">
                <span className="p-input-icon-left">
                    <i className="pi pi-search" />
                    <InputText value={globalFilterValue1} onChange={onGlobalFilterChange1} placeholder="Search" />
                </span>
                <Button type="button" icon="pi pi-filter-slash"
                    title="Clear" className="p-button-rounded  mx-1 bg-primary"
                    onClick={clearFilter1} />
                <Button icon="pi pi-download"
                    disabled={!AccessType}
                    onClick={downloadRunImport}
                    className="p-button-rounded  mx-1 bg-primary"
                    title="Download source data" />
            </div>
        )
    }
    const header1 = renderHeader1();
    return (
        <>
            {!!runImportData.rows &&
                <DataTable id="runImportTable"
                    value={runImportData.rows}
                    column
                    showGridlines
                    scrollable
                    scrollDirection="both"
                    sortMode="multiple"
                    paginator
                    paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
                    currentPageReportTemplate="Showing {first} to {last} of {totalRecords}"
                    rows={10}
                    dataKey="index"
                    header={header1}
                    filters={filters1}
                    globalFilterFields={['App1-App2', 'Year-Years',
                        'Period-Period', 'Entity-Ent',
                        'Value-Cons', 'Scenario-Scenario',
                        'Account-ACCT',
                        'YEAR-YEAR',
			'ENT-ENTITY',
			'ACCT-ACCOUNT',
			'FUNCTION-FUNCTION',
                        'bridge-YEAR-YEAR',
                        'PERIOD-PERIOD',
                        'bridge-PERIOD-PERIOD',
                        'ENTITY-ENTITY',
                        'bridge-Entity-Entity',
                        'VIEW-VIEW',
                        'bridge-VIEW-VIEW',
                        'ACCOUNT-ACCOUNT',
                        'bridge-Account-Account',
                        'Flows-Flow',
                        'Dim8-Origin',
                        'ICP-IC', 'DataSource-U1', 'Segment-U2',
                        'Dim12-Function', 'Dim13-U4',
                        'Geography-U5', 'Customer-U6',
                        'Dim16-U7', 'Census-Dim17', 'Dim18-U8', 'View-View',
                        'AMOUNT-AMOUNT']}
                    filterDisplay="menu"
                    removableSort
                    rowsPerPageOptions={[10, 20, 50]}>
                    {
                        filteredheaders?.map((col, i) => {
                            return <Column field={col} header={col}
                                style={{ "width": "15%" }}
                                className="ellipsify" sortable filter />;
                        })
                    }
                </DataTable>}
        </>
    )
}
export default Sourcedatatable;
