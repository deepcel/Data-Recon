import React, { useState, useEffect } from "react";
import { exportruntransformation } from "../../../../store/sliceReducers/RunTransformReducer";
import './RunTransformation.scss';
import { useDispatch, useSelector } from "react-redux";
import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Button } from "primereact/button";
import { InputText } from 'primereact/inputtext';
import { FilterMatchMode, FilterOperator } from 'primereact/api';
import 'primeicons/primeicons.css';
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';

const TransTable = () => {

  const dispatch = useDispatch();
  const [filters1, setFilters1] = useState(null);
  const [globalFilterValue1, setGlobalFilterValue1] = useState('');
  const authData = useSelector((state) => state.auth);
  let { data } = authData.data;
  const AccessType = data.access_type.privilege === 0 ? true : false;

  const selectedReconId = useSelector(state =>
    state.reconRun.selectedReconRunId
  );

  const runTransformation = useSelector(state =>
    state.runTransform.runTransformation
  );

  const onGlobalFilterChange1 = (e) => {
    const value = e.target.value;
    let _filters1 = { ...filters1 };
    _filters1['global'].value = value;
    setFilters1(_filters1);
    setGlobalFilterValue1(value);
  }

  const initFilters1 = () => {
    setFilters1({
      'global': { value: null, matchMode: FilterMatchMode.CONTAINS },
      'App1-App2': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'YEAR-YEAR': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Year-Years': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-YEAR-YEAR': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Year-Years': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Period-Period': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'PERIOD-PERIOD': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-PERIOD-PERIOD': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Period-Period': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Entity-Ent': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'ENTITY-ENTITY': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Entity-Ent': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-ENTITY-ENTITY': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'VIEW-VIEW': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-VIEW-VIEW': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Value-Cons': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Value-Cons': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Scenario-Scenario': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Scenario-Scenario': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Account-ACCT': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Account-ACCT': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Flows-Flow': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Flows-Flow': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Dim8-Origin': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Dim8-Origin': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'ICP-IC': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-ICP-IC': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'DataSource-U1': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-DataSource-U1': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Segment-U2': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Segment-U2': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Dim12-Function': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Dim12-Function': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Dim13-U4': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Dim13-U4': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Geography-U5': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Geography-U5': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Customer-U6': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Customer-U6': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Dim16-U7': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Dim16-U7': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Census-Dim17': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Census-Dim17': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Dim18-U8': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-Dim18-U8': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'VIEW-VIEW': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-VIEW-VIEW': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridgesync-ACCOUNT-ACCOUNT': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
    //  'ENT-ENTITY': {operator: FilterOperator.AND, constrains: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
     // 'ACCT-ACCOUNT': {operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }]},
     // 'FUNCTION-FUNCTION': {operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }]},
     // 'bridgesync-ENT-ENTITY': {operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }]},
     // 'bridgesync-ACCT-ACCOUNT': {operator: FilterOperator.AND, constraints: [{value: null, matchMode: FilterMatchMode.STARTS_WITH }]},
     // 'bridgesync-FUNCTION-FUNCTION': {operator: FilterOperator.AND, constraints: [{value: null, matchMode: FilterMatchMode.STARTS_WITH }]}, 
     // 'ACCOUNT-ACCOUNT': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Amount': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Comments': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
    });
    setGlobalFilterValue1('');
  }

  useEffect(() => {
    initFilters1();
  }, [])

  const downloadRunTransformation = () => {
    dispatch(exportruntransformation(selectedReconId));
  }

  const clearFilter1 = () => {
    initFilters1();
  }

  const renderHeader1 = () => {
    return (
      <div className="flex justify-content-end">
        {/* <Button type="button" icon="pi pi-filter-slash" label="Clear" className="p-button-outlined" onClick={clearFilter1} /> */}
        <span className="p-input-icon-left">
          <i className="pi pi-search" />
          <InputText value={globalFilterValue1}
            onChange={onGlobalFilterChange1} placeholder="Search" />
        </span>
        <Button type="button"
          icon="pi pi-filter-slash"
          title="Clear"
          disabled={(selectedReconId === '' || !AccessType ? true : false)}
          className="p-button-rounded  ml-1 bg-primary"
          onClick={clearFilter1} />
        <Button icon="pi pi-download"
          disabled={!AccessType}
          className="p-button-rounded  mx-1 bg-primary"
          title="Download run transformation sync"
          onClick={downloadRunTransformation} />
      </div>
    )
  }

  const header1 = renderHeader1();

  const dynamicColumns = runTransformation.headers?.map((col, i) => {
    return <Column field={col} style={{ "width": "14%" }} header={<div>{col}</div>} sortable filter />;
  });

  return (
    <DataTable id="runTranformTable"
      value={runTransformation.rows}
      scrollable
      scrollDirection="both"
      showGridlines
      removableSort
      filterDisplay="menu"
      globalFilterFields={[
        'App1-App2',
        'Year-Years',
        'YEAR-YEAR',
        'bridgesync-YEAR-YEAR',
        'bridgesync-Year-Years',
        'PERIOD-PERIOD',
        'bridgesync-PERIOD-PERIOD',
        'bridgesync-Period-Period',
        'ENTITY-ENTITY',
        'Entity-Ent',
        'bridgesync-Entity-Ent',
        'bridgesync-ENTITY-ENTITY',
        'VIEW-VIEW',
        'bridgesync-VIEW-VIEW',
        'Value-Cons',
        'bridgesync-Value-Cons',
        'Scenario-Scenario',
        'bridgesync-Scenario-Scenario',
        'Account-ACCT',
        'bridgesync-Account-ACCT',
        'ACCOUNT-ACCOUNT',
        'bridgesync-ACCOUNT-ACCOUNT',
        'Flows-Flow',
        'bridgesync-Flows-Flow',
        'Dim8-Origin',
        'bridgesync-Dim8-Origin',
        'ICP-IC',
        'bridgesync-ICP-IC',
        'DataSource-U1',
        'bridgesync-DataSource-U1',
        'Segment-U2',
        'bridgesync-Segment-U2',
        'Dim12-Function',
        'bridgesync-Dim12-Function',
        'Dim13-U4',
        'bridgesync-Dim13-U4',
        'Geography-U5',
        'bridgesync-Geography-U5',
        'Customer-U6',
        'bridgesync-Customer-U6',
        'Dim16-U7',
        'bridgesync-Dim16-U7',
        'Census-Dim17',
        'bridgesync-Census-Dim17',
        'Dim18-U8',
        'bridgesync-Dim18-U8',
        'VIEW-VIEW',
        'bridgesync-VIEW-VIEW',
        'Amount',
        'Comments',
	'ENT-ENTITY',
	'ACCT-ACCOUNT',
	'FUNCTION-FUNCTION',
	'bridgesync-ENT-ENTITY',
	'bridgesync-ACCT-ACCOUNT',
	'bridgesync-FUNCTION-FUNCTION',
      ]}
      header={header1}
      filters={filters1}
      sortMode="multiple"
      paginator
      scrollHeight="480px"
      paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
      currentPageReportTemplate="Showing {first} to {last} of {totalRecords}"
      rows={10}
      rowsPerPageOptions={[10, 20, 50]}
      emptyMessage="No data found.">
      {dynamicColumns}
    </DataTable>
  )
}

export default TransTable;
