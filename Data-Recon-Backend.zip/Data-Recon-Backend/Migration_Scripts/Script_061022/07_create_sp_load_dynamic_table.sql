CREATE OR REPLACE PROCEDURE fileService.sp_load_dynamic_table(
	in recon_app_id integer
)
LANGUAGE 'plpgsql'
AS $BODY$
DECLARE 
var_app_id integer = recon_app_id;
var_table_name record;
var_table boolean := false;

var_script text := '';
var_script_insert text := '';

var_dim_names text[];
v_dim text := '';
var_file record;
var_default_location text := 'C:\Workspace\PostgreSQL\Data_Recon\input\';
var_file_meta record;
s_schema_name text := 'fileservice';
v_row_count integer :=0;
v_file_count integer :=0;
v_tmp_table text := '';


begin

	call fileservice.sp_log_entry(var_app_id, '''Preparing load''');
 
	/*
	 * This procedure assumes that the target table exists on the database with appropriate roles and privileges
	 * 
	 * Check if the application entry exists in the recon_application table
	 */
	if
		exists(select 1 from fileservice.recon_applications ra where ra.recon_app_id=var_app_id)
		then
			select concat('app_',r.recon_id,'_',var_app_id) as table_name, r.recon_id::integer as rec_id 
			into var_table_name
			from fileservice.recon r 
			where r.app1_id = var_app_id
			or r.app2_id = var_app_id;
		else 
			-- Log Script
			call fileService.sp_log_entry(
									var_app_id::integer,
									'''ERROR: Application does not exist'''::text
									);
			return;		
	end if;
	
	v_tmp_table = var_table_name.table_name||'_tmp';


	/*
	 * Check if the table exists in the database using the system table pg_catalog.pg_tables
	 */
	select exists
	into var_table
	(select from pg_catalog.pg_tables pt 
	where schemaname = s_schema_name  
	and tablename = var_table_name.table_name) q1;
--	raise notice '%', not(var_table);

	if not(var_table)
		then
			call fileService.sp_log_entry(
									var_app_id::integer,
									'''ERROR: Table does not exist'''::text
									);
			return;
--			raise exception '% table does not exist',var_table_name;	
	end if;


	/*
	 * Prepare the copy statement to load the file
	 * Loop to get the dimension names that exist in the file
	 * 
	 */
	var_dim_names := array (
			select concat('"',generate_series(1,v_max),'"') as col_id
			from (
				select max(type_field::integer) as v_max
				from fileservice.recon_dimensions rd 
				where rd.recon_app_id = var_app_id
				and top_member is null
			) q2
	);

	
	/*
	 * Create intermediate temp table
	 */
	var_script = 'drop table if exists fileservice.'||v_tmp_table||' cascade; ';
	var_script = var_script || 'create table fileservice.'||v_tmp_table||'( ';

	foreach v_dim in array var_dim_names
	loop
		var_script = var_script || v_dim || '  character varying COLLATE pg_catalog."default",';
	end loop;

	var_script = var_script || ' dummy_column character varying COLLATE pg_catalog."default") TABLESPACE tbsp_data_recon;';
	execute var_script;
	
	/*
	 * v_dim will provide dimension names for file to temp table
	 */
	v_dim = pg_catalog.array_to_string(var_dim_names, ',') ;


	var_script_insert = 'insert into '||s_schema_name||'.'||var_table_name.table_name||' (';

	select
		string_agg(dim_name,', ')
	into var_script
	from (
		select rd.dimension as dim_name
		from fileservice.recon_dimensions rd 
		where rd.recon_app_id = var_app_id
		order by rd.type_field::integer,
		rd.dimensions_id 
	) q3;
	var_script_insert = var_script_insert||var_script||')';


	select concat('select ',string_agg(dim_name,', '))
	into var_script
	from (
		select
			case 
				when rd.type_field is null
				then concat('''',rd.top_member,'''')
				else concat('"',rd.type_field,'"')
			end as dim_name
		from fileservice.recon_dimensions rd 
		where rd.recon_app_id = var_app_id
		order by rd.type_field::integer,
		rd.dimensions_id
	) q4;
	
	var_script = var_script || ' from '||s_schema_name||'.'||v_tmp_table;

	var_script_insert = var_script_insert||' '||var_script;
--	raise notice '%', var_script_insert;


	select import_delimiter , 
	case 
		when has_header=true
		then 'csv header'
		else ''
		end as import_header
	into var_file_meta
	from fileservice.recon_applications ra 
	where ra.recon_app_id = var_app_id;

	

	for var_file in
		select --concat('''',coalesce(tfls.file_location, var_default_location) , tfls.file_name,'''') as file
		tfls.file_location as file_location , tfls.file_name as file
		from fileservice.track_file_load_status tfls 
		where tfls.app_id = var_app_id
		and (tfls.status <> 'Completed'
		or tfls.status is null)
		order by tfls .file_id 
	loop 
		
		/*
		 * log file load start time
		 */
		call fileservice.sp_log_entry(
			var_app_id, 
			'''Loading file '||var_file.file||'''', 
			var_table_name.rec_id, 
			var_table_name.table_name
		); 
	
		var_script = 'delete from '||s_schema_name||'.'||v_tmp_table;
		execute var_script;
		
		
		/*
		 * load file to tmp table
		 */
		var_script = 'copy '||s_schema_name||'.'||v_tmp_table||'('|| v_dim ||') from ';	
		var_script = var_script||''''||var_file.file_location||var_file.file||'''';
		var_script = var_script|| ' delimiter '''||var_file_meta.import_delimiter||''' '||var_file_meta.import_header||';';
--		raise notice '%',var_script;
		execute var_script;
	
		get diagnostics v_row_count = ROW_COUNT;
		v_file_count = v_file_count+1;
	
	
		/*
		 * Move data from tmp table to dynamic table
		 */
		execute var_script_insert;
	
		--log file status
		update fileservice.track_file_load_status 
		set status = 'Completed'
		where app_id = var_app_id
		and file_name = var_file.file;
--		perform pg_sleep(5);
	
		/*
		 * log file load end time
		 */
		call fileservice.sp_log_entry(
			var_app_id, 
			'''Load completed for file '||var_file.file||' '||v_row_count||' rows''', 
			var_table_name.rec_id, 
			var_table_name.table_name
		); 
		
		commit;

	end loop;

	/*
	 * Drop temporary table
	 * 
	 */

	var_script = 'drop table if exists fileservice.'||v_tmp_table||' cascade; ';
	execute var_script;

	/*
	 * Log final load status
	 */
	call fileservice.sp_log_entry(
		var_app_id, 
		'''Load completed for '||v_file_count||' files''', 
		var_table_name.rec_id, 
		var_table_name.table_name
	);

END
$BODY$;
