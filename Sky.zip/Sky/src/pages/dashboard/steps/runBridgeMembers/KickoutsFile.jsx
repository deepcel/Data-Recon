import React, { useState, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import "./runBridgeMembers.scss";
import {
  unMappedKickoutImport,
} from "../../../../store/sliceReducers/RunBridgeReducer";
import { getExtension, chooseOptions,uploadOptions,cancelOptions } from "../../../../utils/fileutils";
import { toast } from "react-toastify";
import { Button } from "primereact/button";
import { FileUpload } from 'primereact/fileupload';
import 'primeicons/primeicons.css';
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';

const KickoutsFile = () => {
    const dispatch = useDispatch();
    const authData=useSelector((state)=>state.auth);
    let{data}=authData.data;
    const AccessType=data.access_type.privilege===0?true:false;
    const [totalSizeBridge, setTotalSizeBridge] = useState(0);
    const fileUploadRef = useRef(null);
    const selectedReconId = useSelector(state =>
      state.reconRun.selectedReconRunId
    );

    
    const onTemplateRemoveBridge = (file, callback) => {
      setTotalSizeBridge(totalSizeBridge - file.size);
      callback();
    };
    const itemTemplateBridge = (file, props) => {
      return (
        <div className="flex justify-content-between ">
          <div className="flex align-items-center" style={{ width: "40%" }}>
            <span className="flex flex-column text-left ml-3">{file.name}</span>
          </div>
          
          <Button            
            icon="pi pi-times"
            className="p-button-secondary" 
            onClick={() => onTemplateRemoveBridge(file, props.onRemove)}
          />
        </div>
      );
    };

    const unMappedKickoutFileupload = ({ files }) => {
      const supportedFileFormat = ["csv", "txt"];
      const [file] = files;
      if (file) {
        if (!supportedFileFormat.includes(getExtension(file.name))) {
          toast.error("Unsupported file format, Please upload valid files(.csv,.txt)");
          return;
        }
      }
      const fileReader = new FileReader();
      fileReader.onload = (e) => {
        let formData = new FormData();
        formData.append('kick_out_file', file);
        formData.append('recon_id', selectedReconId);
        dispatch(unMappedKickoutImport(formData, selectedReconId));
        
          fileUploadRef.current.clear();        

      };
      fileReader.readAsDataURL(file);
    };

    return (
       <>
       <FileUpload disabled={!AccessType}
                   ref={fileUploadRef}
                   accept=".csv, .txt"
                   maxFileSize={100000000}
                   customUpload
                   chooseOptions={chooseOptions} 
                   uploadOptions={uploadOptions} 
                   cancelOptions={cancelOptions}
                   itemTemplate={itemTemplateBridge}
                   uploadHandler={unMappedKickoutFileupload}
                   emptyTemplate={<p className="m-0">Drag and drop files to here to upload.</p>} />
                    
       </>
    )
}
export default KickoutsFile;