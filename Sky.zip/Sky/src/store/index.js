import { configureStore } from '@reduxjs/toolkit';
import logger from 'redux-logger';
import { combineReducers } from "redux";
import storage from 'redux-persist/lib/storage';
import AuthReducer from './sliceReducers/AuthReducer';
import bridgeMemberReducer from './sliceReducers/BridgeMemberReducer';
import DimFieldReducer from './sliceReducers/DimFieldReducer';
import DirectConnectReducer from './sliceReducers/DirectConnectReducer';
import LoadReducer from './sliceReducers/LoadReducer';
import ReconRunReducer from './sliceReducers/ReconRunReducer';
import RunBridgeReducer from './sliceReducers/RunBridgeReducer';
import runImportReducer from './sliceReducers/RunImportReducer';
import runReportReducer from './sliceReducers/RunReportReducer';
import RunTransformReducer from './sliceReducers/RunTransformReducer';
import TransformationReducer from './sliceReducers/TransformationReducer';
import UserReducer from './sliceReducers/UserReducer';
import {
  persistStore,
  persistReducer,
  FLUSH,
  REHYDRATE,
  PAUSE,
  PERSIST,
  PURGE,
  REGISTER
} from "redux-persist";

const rootReducer = combineReducers({ 
  auth: AuthReducer,
  bridgeMember:bridgeMemberReducer,
  DirectConnect:DirectConnectReducer,
  dimField:DimFieldReducer,
  loader: LoadReducer,
  reconRun:ReconRunReducer,
  runbridge:RunBridgeReducer,
  runImport:runImportReducer,
  runreport:runReportReducer,
  runTransform:RunTransformReducer,
  transform:TransformationReducer,
  user: UserReducer,
});

const persistConfig = {
  key: 'root',
  version: 1,
  storage,
  whitelist: ['auth']
}

const persistedReducer = persistReducer(persistConfig, rootReducer)
const store = configureStore({
  reducer: persistedReducer,
  middleware: (getDefaultMiddleware) => getDefaultMiddleware({
    serializableCheck: {
      ignoredActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER]
    }
  }).concat(logger),
  devTools: process.env.NODE_ENV !== 'production',
});

let persistor = persistStore(store);
export { store, persistor };

// The store has been created with these options:
// - The slice reducers were automatically passed to combineReducers()
// - redux-thunk and redux-logger were added as middleware
// - The Redux DevTools Extension is disabled for production
// - The middleware, batched subscribe, and devtools enhancers were composed together