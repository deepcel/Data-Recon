import React, { useEffect, useState } from "react";
import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useDispatch, useSelector } from "react-redux";
import "./runBridgeMembers.scss";
import {
  updateUnMappedBridge,
  downloadUnMappedKickoutFile,
} from "../../../../store/sliceReducers/RunBridgeReducer";
import { toast } from "react-toastify";
import { InputText } from 'primereact/inputtext';
import { Button } from "primereact/button";
import { FilterMatchMode, FilterOperator } from 'primereact/api';
import 'primeicons/primeicons.css';
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';

const KickoutsTable = () => {

  const dispatch = useDispatch();
  const [editingRows, setEditingRows] = useState({});
  const [globalFilterValue1, setGlobalFilterValue1] = useState('');
  const [filters1, setFilters1] = useState(null);
  const authData = useSelector((state) => state.auth);
  let { data } = authData.data;
  const AccessType = data.access_type.privilege === 0 ? true : false;


  const selectedReconId = useSelector(state =>
    state.reconRun.selectedReconRunId
  );

  const runBridge = useSelector(state =>
    state.runbridge.runBridge
  );

  useEffect(() => {
    initFilters1();
  }, [])

  const clearFilter1 = () => {
    initFilters1();
  }

  const onGlobalFilterChange1 = (e) => {
    const value = e.target.value;
    let _filters1 = { ...filters1 };
    _filters1['global'].value = value;
    setFilters1(_filters1);
    setGlobalFilterValue1(value);
  }

  const initFilters1 = () => {
    setFilters1({
      'global': { value: null, matchMode: FilterMatchMode.CONTAINS },
      'app1_app2': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'source_member': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridge_member': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
    });
    setGlobalFilterValue1('');
  }

  const unMappedRowEditValidator = (rowData) => {
    if (!rowData['app1_app2']) {
      toast.error("Please select the appType");
      return false;
    }
    else if (!rowData['source_member']) {
      toast.error("Please enter the source member");
      return false;
    }
    else if (!rowData['bridge_member']) {
      toast.error("Please enter the bridge members");
      return false;
    }
    return true;
  }

  const unMappedRowEditComplete = (e) => {
    let { newData } = e;
    dispatch(updateUnMappedBridge(
      {
        recon_id: selectedReconId,
        rows: [{
          out_id: newData.out_id,
          app1_app2: newData.app1_app2,
          source_member: newData.source_member,
          bridge_member: newData.bridge_member
        }]
      }));
  }

  const downloadUnMappedKickout = () => {
    dispatch(downloadUnMappedKickoutFile({ "recon_id": selectedReconId, "je_flag": false }));
  }

  const onRowEditChange = (e) => {
    if (AccessType === true) {
      setEditingRows(e.data)
    }
    else {
      return
    }
  }

  const textEditor = (options) => {
    return <InputText type="text" value={options.value} onChange={(e) => options.editorCallback(e.target.value)} className="w-full" />;
  }

  const renderHeader1 = () => {
    return (
      <div className="flex justify-content-end">

        <span className="p-input-icon-left">
          <i className="pi pi-search" />
          <InputText value={globalFilterValue1} onChange={onGlobalFilterChange1} placeholder="Search" />
        </span>
        <Button type="button"
          icon="pi pi-filter-slash"
          title="Clear" className="p-button-rounded  mx-1 bg-primary" onClick={clearFilter1} />
        <Button icon="pi pi-download" onClick={downloadUnMappedKickout} disabled={!AccessType}
          className="p-button-rounded  mx-1 bg-primary" title="Download Unmapped kick outs" />

      </div>
    )
  }

  const header1 = renderHeader1();

  return (
    <>
      <DataTable value={runBridge.unMapped}
        id="unMappedTable"
        editMode="row"
        editingRows={editingRows}
        onRowEditChange={onRowEditChange}
        rowEditValidator={unMappedRowEditValidator}
        onRowEditComplete={unMappedRowEditComplete}
        dataKey="out_id"
        showGridlines
        removableSort
        sortMode="multiple"
        scrollHeight="500px"
        paginator
        filterDisplay="menu"
        globalFilterFields={['app1_app2', 'source_member', 'bridge_member']}
        header={header1}
        filters={filters1}
        paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
        currentPageReportTemplate="Showing {first} to {last} of {totalRecords}"
        rows={10}
        rowsPerPageOptions={[10, 20, 50]}>
        <Column style={{ width: '15%' }} field="app1_app2" header="App Type" sortable filter editor={(options) => textEditor(options)}></Column>
        <Column style={{ width: '20%' }} field="source_member" header="Source Member" sortable filter editor={(options) => textEditor(options)}></Column>
        <Column style={{ width: '20%' }} field="bridge_member" header="Bridge Member" sortable filter editor={(options) => textEditor(options)}></Column>
        <Column style={{ width: '10%' }} rowEditor header="Edit"></Column>
      </DataTable>
    </>
  )
}
export default KickoutsTable;