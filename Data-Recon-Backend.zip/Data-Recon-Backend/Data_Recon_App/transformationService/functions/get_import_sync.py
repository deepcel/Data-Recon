import csv
from ...utils.get_recon import get_recon
from ...bridgeService.functions.get_import_data import get_dim_id
from ...models import ReconTransformation
from .update_tfn_sync import update_tfn_sync
from .get_sync_data import get_sync_data


'''
<!---------- Method to get the imported sync file data
             and return as structured data ----------!>
'''


def get_import_sync(recon_id, app_type, file_path):
    recon_data = get_recon(recon_id)
    app_id = recon_data['app1_id'] if app_type == '0' else recon_data['app2_id']

    # Creating the data object
    data_object = {
        'recon_id': recon_id,
        'app_type': app_type,
        'rows': []
    }

    # Reding the imported file
    with open(file_path, newline='', encoding="utf-8-sig") as Comments_File:
        reader = csv.reader(Comments_File)

        # Looping through the file data
        for index, row in enumerate(reader):
            number_of_col = len(row)

            # Checking if all columns are there
            if number_of_col < 4:
                response_data = {
                    'status': 6002,
                    'message': 'Missing required columns in file!'
                }
                return response_data
            else:
                dim_id = get_dim_id(recon_id, row[0], app_type)

                if dim_id != 'None':
                    tfn_id = get_tfn_id(recon_id, app_id, dim_id)

                    if tfn_id:
                        row_object = {
                            'tfn_id': tfn_id,
                            'source_sync': row[1],
                            'flip_sign': True if (row[2]).upper() == 'YES' else False,
                            'target_sync': row[3]
                        }
                        data_object['rows'].append(row_object)
                    else:
                        response_data = {
                            'status': 6002,
                            'message': 'Transformation not found for ' + row[0] + ' dimension!'
                        }
                        return response_data
                else:
                    response_data = {
                        'status': 6002,
                        'message': 'Invalid dimension ' + row[0] + ' found in file!'
                    }
                    return response_data

    # Saving or updating sync
    update_tfn_sync(recon_id, app_type, data_object['rows'])

    # Getting sync data
    response_data = get_sync_data(recon_id, app_type)
    return response_data


def get_tfn_id(recon_id, app_id, dim_id):
    tfn_id = None
    if ReconTransformation.objects.filter(recon_id=recon_id, app_id=app_id, dim_id=dim_id).exists():
        instance = ReconTransformation.objects.filter(recon_id=recon_id, app_id=app_id, dim_id=dim_id)[0]
        tfn_id = instance.id

    return tfn_id
