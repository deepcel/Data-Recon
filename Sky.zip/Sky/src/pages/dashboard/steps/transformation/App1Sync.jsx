import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { FilterMatchMode, FilterOperator } from 'primereact/api';
import { Button } from "primereact/button";
import { InputText } from 'primereact/inputtext';
import { Dropdown } from 'primereact/dropdown';
import { ConfirmPopup, confirmPopup } from 'primereact/confirmpopup';
import { Dialog } from 'primereact/dialog';
import {
    downloadTransformSyncMap, updateTransformationSync, addRowApp1Sync,
    deleteTransformSync, UPDATE_APP1SYNC,
} from "../../../../store/sliceReducers/TransformationReducer";
import "./transformation.scss";

const App1Sync = () => {
    const dispatch = useDispatch();
    const authData = useSelector((state) => state.auth);
    let { data } = authData.data;
    const AccessType = data.access_type.privilege === 0 ? true : false;
    const [editingRows, setEditingRows] = useState({});
    const [globalFilterValue2, setGlobalFilterValue2] = useState('');
    const [filters2, setFilters2] = useState(null);
    const [app1SourceSyncDropdown, setApp1SourceSyncDropdown] = useState([]);
    const [transformationSyncApp1Dialog, setTransformationSyncApp1Dialog] = useState(false);
    const [selectedsync, setSelectedSync] = useState([]);
    const [deleteProductsDialog, setDeleteProductsDialog] = useState(false);
    const [app1selectedProducts, app1setSelectedProducts] = useState(null);
    const [selectedapp1flipsign, setSelectedapp1flipsign] = useState(null);

    let emptyTransformationSync = {
        app1dimension: '',
        app1sourcesync: '',
        app1flipsign: '',
        app1targetsync: ''
    };
    const [transformationSync, setTransformationSync] = useState(emptyTransformationSync);

    const flipSyncdropdown = [
        { label: 'YES', value: 'YES' },
        { label: 'NO', value: 'NO' }
    ];

    // get selected recon_id from redux state
    const selectedReconId = useSelector(state =>
        state.reconRun.selectedReconRunId
    );
    // get stransformation data from redux state 
    const transformation = useSelector(state =>
        state.transform.transformation
    );

    // set values of transformation received for app1Sync table
    useEffect(() => {
        setSelectedSync(transformation.app1Sync);
    }, [transformation, transformation.rows]); // dependency array to re render this component 

    const confirmDeleteSelected = () => {
        setDeleteProductsDialog(true);
    }

    const hideDeleteProductsDialog = () => {
        setDeleteProductsDialog(false);
    }

    // const transformSyncRowEditValidator = (rowData) => {
    //     if (!rowData['dimensions_id']) {
    //         toast.error("Please select the dimension");
    //         return false;
    //     }
    //     else if (!rowData['source_sync']) {
    //         toast.error("Please fill the source member");
    //         return false;
    //     }
    //     else if (!rowData['flip_sign']) {
    //         toast.error("Please fill the flip sign");
    //         return false;
    //     }
    //     else if (!rowData['target_sync']) {
    //         toast.error("Please fill the target sync");
    //         return false;
    //     }
    //     return true;
    // }

    const transformSyncRowEditValidator = (rowData) => {
        if (!rowData['dimensions_id']) {
            toast.error("Please select the dimension");
            return false;
        }
        else if (!rowData['source_sync']) {
            toast.error("Please fill the source member");
            return false;
        }
        else if (!rowData['flip_sign']) {
            toast.error("Please fill the flip sign");
            return false;
        }
        else if (!rowData['target_sync']) {
            toast.error("Please fill the target sync");
            return false;
        }
        else if (rowData['source_sync'].toUpperCase() === 'YEAR' && !Number.isInteger(rowData['target_sync'])) {
            toast.error("Target sync should be an integer for YEAR source sync");
            return false;
        }
        else if (rowData['source_sync'].toUpperCase() !== 'YEAR' && typeof rowData['target_sync'] !== 'string') {
            toast.error("Target sync should be a string for non-YEAR source sync");
            return false;
        }
        return true;
    }

    const onGlobalFilterChange2 = (e) => {
        const value = e.target.value;
        let _filters2 = { ...filters2 };
        _filters2['global'].value = value;
        setFilters2(_filters2);
        setGlobalFilterValue2(value);
    }

    const initFilters2 = () => {
        setFilters2({
            'global': { value: null, matchMode: FilterMatchMode.CONTAINS },
            'dimensions_id': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'source_sync': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'flip_sign': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'target_sync': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
        });
        setGlobalFilterValue2('');
    }

    const clearFilter2 = () => {
        initFilters2();
    }


    const getDimensionData = (dimensionList, dimId) => {
        if (!!dimId) {
            const index = dimensionList.findIndex(dim => String(dim.dimensions_id) === String(dimId));
            if (index === -1) {
                return dimId;
            }
            else {
                return dimensionList[index]?.dimension;
            }
        }
        else {
            return "--";
        }
    }

    const downloadApp1SyncMap = () => {
        dispatch(downloadTransformSyncMap(
            {
                "recon_id": selectedReconId,
                "app_type": "0"
            }));
    }



    const onApp1FlipSignChange = (e) => {
        setSelectedapp1flipsign(e.value);
    }

    const app1FlipsignTemplate = (rowData) => {
        return rowData.flip_sign === "YES" ? "YES" : "NO"
    }

    const app1FlipSign = (options) => {
        return (
            <Dropdown value={options.value} className="w-full"
                options={flipSyncdropdown} optionLabel="label" optionValue="value"
                onChange={(e) => { options.editorCallback(e.value); }}
                placeholder="select" />
        );
    }

    const deleteSelectedProducts = () => {
        let _products = selectedsync.filter(val => app1selectedProducts.includes(val));
        setSelectedSync(_products);
        setDeleteProductsDialog(false);
        // setSelectedProducts(emptySync);
        let rows = [];
        for (let i = 0; i < _products.length; i++) {
            rows.push(_products[i].sync_id);
        }
        // deleteTransformationSync(rows, e, "0")
        dispatch(deleteTransformSync(
            {
                "recon_id": selectedReconId,
                "sync_id": rows,
                "appType": 0
            }));
        app1selectedProducts.length = 0;
    }

    const app1SourceSyncDropdownUpdate = (dimId) => {
        const rowIndex = transformation.combinations.app1Data.findIndex(t => t.dimensions_id === dimId);
        if (rowIndex !== -1) {
            setApp1SourceSyncDropdown(transformation.combinations.app1Data[rowIndex]?.source_sync);
        }
    }

    // const getApp1SourceSyncDropdownUpdate = (dimId) => {
    //     const rowIndex = transformation.combinations.app1Data.findIndex(t => t.dimensions_id === dimId);
    //     if (rowIndex !== -1) {
    //         return transformation.combinations.app1Data[rowIndex]?.source_sync;
    //     }
    // }

    const app1CombinationDropdownEditor = (options) => {
        return (
            <Dropdown
                value={options.value}
                options={transformation.combinations.app1SourceSync }
                onChange={(e) => { options.editorCallback(e.value) }}
                // // value={app1combinationdropdown} options={transformation.combinations.app1Data} optionLabel="source_sync"
                // onChange={(e) => { options.editorCallback(e.value); setapp1combinationdropdown(e.value); }}
                placeholder="select" className="w-full" filter showClear filterBy="dimension" />
        )
    }

    const app1DropdownEditor = (options) => {
        return (
            <Dropdown value={options.value}
                options={transformation.combinations.app1Dimension}
                optionLabel="dimension" optionValue="dimensions_id"
                onChange={(e) => { options.editorCallback(e.value); app1SourceSyncDropdownUpdate(e.value) }}
                placeholder="select" className="w-full" filter showClear filterBy="dimension" />
        )
    }

    const onRowEditChange = (e) => {
        if (AccessType === true) {
            setEditingRows(e.data)
        }
        else {
            return
        }
    }
    const textEditor = (options) => {
        return <InputText type="text" value={options.value} onChange={(e) => options.editorCallback(e.target.value)} className="w-full" />;
    }
    const app1DimensionNameTemplate = (rowData) => {
        return (
            getDimensionData(transformation.combinations.app1Dimension, rowData.dimensions_id)
        );
    }

    const app1TransformSyncDelete = (rowData) => {
        return (
            <React.Fragment>
                <Button icon="pi pi-trash"
                    disabled={!AccessType}
                    className="p-button-rounded mx-1 bg-primary"
                    onClick={(e) => deleteTransformationSync(rowData.sync_id, e, "0")}
                />
            </React.Fragment>
        );
    }
    
    const deleteTransformationSync = (sync_id, event, appType) => {
        confirmPopup({
            target: event.currentTarget,
            message: 'Do you want to delete this record?',
            icon: 'pi pi-info-circle',
            acceptClassName: 'p-button-danger',
            accept: () => {
                dispatch(deleteTransformSync(
                    {
                        "recon_id": selectedReconId,
                        "sync_id": [sync_id]
                    }, appType));
            },
            reject: () => {
            }
        });
    }
    // const addRow = () => {
    //     dispatch(addRowApp1Sync(emptyTransformationSync))
    // };

    const addRow = () => {
        // Create a new empty row object
        const newRow = {
            dimensions_id: "",
            source_sync: "",
            flip_sign: "",
            target_sync: "",
        };

        // Add the new row to the state with the added data
        dispatch(addRowApp1Sync(newRow));

        // Get the index of the new row
        const rowIndex = transformation.app1Sync.length - 1;

        // try {
        //     // Call the update API with the new row
        //     dispatch(
        //         updateTransformationSync({
        //             recon_id: selectedReconId,
        //             app_type: "0",
        //             rows: [newRow],
        //         })
        //     );
        // } catch (error) {
        //     toast.info("Empty Row is added Please enter values to the row" + error);
        // }
    };

    const App1TransformSyncRowEditComplete = (e, rowIndex) => {
        const { newData } = e;

        // Update the row in the state
        dispatch(UPDATE_APP1SYNC(newData, rowIndex));

        // Call the update API with the updated row
        dispatch(
            updateTransformationSync({
                recon_id: selectedReconId,
                app_type: "0",
                rows: [newData],
            })
        );
    };


    // const App1TransformSyncRowEditComplete = (e) => {
    //     let { newData } = e;
    //     dispatch(updateTransformationSync(
    //         {
    //             recon_id: selectedReconId,
    //             app_type: "0",
    //             rows: [{
    //                 // tfn_id: newData.tfn_id,
    //                 dimensions_id: newData.dimensions_id,
    //                 source_sync: newData.source_sync,
    //                 flip_sign: newData.flip_sign,
    //                 target_sync: newData.target_sync
    //             }]
    //         }));
    // }

    const openNewApp1 = () => {
        setTransformationSync(emptyTransformationSync);
        setTransformationSyncApp1Dialog(false);
        addRow();
    }

    const hideDialog1 = () => {
        // setSubmitted(false);
        setTransformationSyncApp1Dialog(false);
    }
    const transformationDialogFooter1 = (
        <React.Fragment>
            <Button label="Cancel" icon="pi pi-times" className="p-button-text" onClick={hideDialog1} />
            <Button label="Save" icon="pi pi-check" className="p-button-text"
            // onClick={saveProduct} 
            />
        </React.Fragment>
    );
    const deleteProductsDialogFooter = () => {
        return (
            <React.Fragment>
                <Button label="No" icon="pi pi-times" className="p-button-text" onClick={hideDeleteProductsDialog} />
                <Button label="Yes" icon="pi pi-check" className="p-button-text"
                    onClick={deleteSelectedProducts} />
            </React.Fragment>
        )
    };
    const renderHeader2 = () => {
        return (
            <div className="flex justify-content-between">
                <span className="p-input-icon-left">
                    <i className="pi pi-search" />
                    <InputText value={globalFilterValue2} onChange={onGlobalFilterChange2} placeholder="Search" />
                </span>
                <div>
                    <Button type="button" icon="pi pi-filter-slash"
                        title="Clear"
                        className="p-button-rounded  mx-1 bg-primary"
                        onClick={clearFilter2} />
                    <Button icon="pi pi-download"
                        onClick={downloadApp1SyncMap}
                        disabled={!AccessType}
                        className="p-button-rounded  mx-1 bg-primary"
                        title="Download App1 Sync Mapping" />
                    <Button icon="pi pi-plus"
                        disabled={!AccessType}
                        className="p-button-rounded  ml-1 bg-primary"
                        title="Add Transformation Sync"
                        onClick={openNewApp1} />
                    <Button title="Bulk Delete" icon="pi pi-trash"
                        className="p-button-rounded  mx-1 bg-primary"
                        onClick={confirmDeleteSelected}
                        disabled={!app1selectedProducts || !app1selectedProducts.length} />

                </div>
            </div>
        )
    }
    const header2 = renderHeader2();
    return (
        <>
            <ConfirmPopup />
            <DataTable id="app1SyncTable"
                value={transformation.app1Sync}
                editMode="row"
                editingRows={editingRows}
                onRowEditChange={onRowEditChange}
                onRowEditComplete={App1TransformSyncRowEditComplete}
                rowEditValidator={transformSyncRowEditValidator}
                dataKey="sync_id"
                showGridlines
                sortMode="multiple"
                scrollHeight="400px"
                scrollable
                removableSort
                scrollDirection="both"
                paginator
                filterDisplay="menu"
                globalFilterFields={['dimensions_id', 'source_sync', 'flip_sign', 'target_sync']}
                paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
                currentPageReportTemplate="Showing {first} to {last} of {totalRecords}"
                rows={10}
                header={header2}
                filters={filters2}
                rowsPerPageOptions={[10, 20, 50]}
                selection={app1selectedProducts}
                onSelectionChange={(e) => app1setSelectedProducts(e.value)}>
                {AccessType && <Column selectionMode="multiple" headerStyle={{ width: '3.5rem' }}></Column>}
                <Column style={{ width: '23%' }} field="dimensions_id"
                    header={<span className="transformationsync">Dimension</span>}
                    sortable filter body={app1DimensionNameTemplate} editor={(options) => app1DropdownEditor(options)}></Column>
                <Column style={{ width: '23%' }} field="source_sync" header={<span className="transformationsync">Source Sync</span>} sortable filter editor={(options) => app1CombinationDropdownEditor(options)}></Column>
                <Column style={{ width: '20%' }} field="flip_sign" header={<span className="transformationsync">Flip Sign</span>} body={app1FlipsignTemplate} sortable filter editor={(options) => app1FlipSign(options)}></Column>
                <Column style={{ width: '19%' }} field="target_sync" header={<span className="transformationsync">Target Sync</span>} sortable filter editor={(options) => textEditor(options)}></Column>
                <Column style={{ width: '13%' }} rowEditor header="Edit"></Column>
                <Column style={{ width: '12%' }} align="center" body={app1TransformSyncDelete} header="Action" ></Column>
            </DataTable>
            <Dialog visible={deleteProductsDialog} style={{ width: '460px' }} header="Confirm" modal footer={deleteProductsDialogFooter} onHide={hideDeleteProductsDialog}>
                <div className="confirmation-content">
                    <i className="pi pi-exclamation-triangle mr-3" style={{ fontSize: '2rem' }} />
                    {selectedsync && <span>Are you sure you want to delete the selected transformation syncs?</span>}
                </div>
            </Dialog>
        </>
    )
}
export default App1Sync;