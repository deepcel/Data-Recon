import React from "react";
import { saveAs } from "file-saver";
import { Button } from "primereact/button";
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';
import "./runImport.scss";
import Paper from '@mui/material/Paper';

const SampleJETemplate = () => {
 
   
  const JEhandleDownload = () => {
      const csvData = 'Year,Period,VIEW,Entity,Account,Amount,Comment\n2019,Dec,YTD,E_MHICoContinuingOps,TotLiabsEquity,253605883.00,abc'; // Replace this with your CSV data
      const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
      saveAs(blob, 'Runimportjetemplate.txt');
  };

  return (
    <>     
     <Paper variant="outlined" className="mb-4">
             <div className="card flex justify-content-start ml-2 mt-1 pb-0">
                <span style={{fontSize: '1.02rem'}}>Download and view Journal Entry template </span>
             </div>
             
      
             <Button icon="pi pi-download"  
                     label="JE Template"
                     title="Download JE template"
                     className="p-button-success m-2  bg-primary" 
                     onClick={JEhandleDownload} />
      </Paper>       
    </>
  )
}

export default SampleJETemplate;