import React, { useState, useEffect } from 'react';
import { getToken } from '../../utils/utils';
import { Panel } from 'primereact/panel';
import { Button } from 'primereact/button';
import { InviteUser } from "./InviteUser";
import { RegUserTable } from './RegUserTable';
import { InvUserTable } from './InvUserTable';
import { Card } from 'primereact/card';
import "../users/userList.scss";
import { Link } from 'react-router-dom';

const UserList = () => {
  // Logged in user email
  const [loggedInUser, setLoggedInUser] = useState('');

  const [selectedTable, setselectedTable] = useState('Registered users');

  useEffect(() => {

    let userObj = getToken('objUser');
    setLoggedInUser(userObj.email);
  }, []);

  // function for setting option to select table 

  const selTabHandler = (value) => {
    setselectedTable(value);
  }

  return (
    <>
      {/* <-------------------------------page header -------------------------> */}
      <Panel style={{ fontFamily: "'Open Sans', sans-serif" }}className='mx-2'>
        <div className='p-panel-header'>
          <div className='header'>
            <span className='headertext'> Manage users</span>
            <span> <Link to="/dashboard">
              <Button label="Go to Dashboard" className="p-button-success" icon="pi pi-arrow-left" />
            </Link> </span>
          </div>
        </div>
        <Card className="myCard" >
          <InviteUser />
          {selectedTable === 'Registered users' ?
            <RegUserTable selectedtableHandler={selTabHandler} />
            : <InvUserTable selectedtableHandler={selTabHandler} />
          }
        </Card>
      </Panel>
    </>

  )
}
export default UserList;