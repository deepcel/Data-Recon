
import { createSlice } from '@reduxjs/toolkit';
import {
    makePostAPICall,
    makePutAPICall,
  } from "../../utils/apiService";
//import { updateToken ,getEmail} from '../../utils/utils';
import { toast } from 'react-toastify';
import { enableLoader, hideLoader } from './LoadReducer';
import { redirectToLogin } from "../../utils/utils";

// This reducer handles login
export const DirectConnectReducer = createSlice({
    name: "DirectConnect",
    initialState: {
        data: [],
        DCInfo:{
            DCStatus:false,
        },
        DCDataApp1:[],
        DCDataApp2:[],
        App1file:'',
        App2file:'',
        viewDialogApp1:false,
        viewDialogApp2:false,
        DCApp1initDimensions:[], 
        DCApp1Dimensions:[], 
        App1Headers:[],
        DCApp2initDimensions:[], 
        DCApp2Dimensions:[],   
        App2Headers:[],  
        DCData:[],   
        error: null,
        loading: false,
        isAuthenticated: false
    },
    reducers: {   
        isLoading: (state, action) => {
            state.loading = true;
          },
        INVALID_SESSION: (state) => {
            state.loading = false;
            state.error = null;
          },   
        DC_DETAILS_RECEIVED: (state, action) => {
            state.data = action.payload;
            state.DCStatus=true;
            state.error = null;
        },

        SET_VIEW_DIALOG_APP1:(state)=>{
          state.viewDialogApp1=false;
         },

        SET_VIEW_DIALOG_APP2:(state)=>{
           state.viewDialogApp2=false;
        },

        INIT_APP1_DIMENSION:(state, action)=>{
             state.DCApp1initDimensions=action.payload;
        },

        INIT_APP2_DIMENSION:(state, action)=>{
              state.DCApp2initDimensions=action.payload;
        },

        UPDATE_INIT_APP1_DIMENSION:(state, action)=>{
          state.DCApp1initDimensions=action.payload;  
        },

        UPDATE_INIT_APP2_DIMENSION:(state, action)=>{
          if(action.payload!=='NOT APPLICABLE')
          {
            state.DCApp2initDimensions=state.DCApp2initDimensions.filter(item=>
              item!==action.payload)
          }
              
        },

        UPDATE_APP1_DIMENSION:(state, action)=>{
          let index=action.payload.i;
          state.DCApp1Dimensions[index]=action.payload.val;  
        },

        UPDATE_APP2_DIMENSION:(state, action)=>{
              let index=action.payload.i;
              state.DCApp2Dimensions[index]=action.payload.val;
        },

        FAILED_LOGIN: (state, action) => {
            state.data = [];
            state.error = action.payload.message;
        },

        LOAD_DIRECTCONNECT_RUN_IMPORT_APP1: (state, action) => {
            state.loading = false;
            state.error = null;
            state.App1file=action.payload.response.files;
            state.DCDataApp1 = [...action.payload.response.headers];
            state.App1Headers=Object.keys(state.DCDataApp1[0]);
            let temp=[]
            for(let i=0;i<state.App1Headers;i++)
            {
              temp[i]='NOT APPLICABLE';
            }
            state.DCApp1Dimensions=[...temp]
            state.viewDialogApp1=true;
          },

        LOAD_DIRECTCONNECT_RUN_IMPORT_APP2:(state, action) => {
          state.loading = false;
          state.error = null;
          state.App2file=action.payload.response.files;
          state.DCDataApp2 = [...action.payload.response.headers];
          state.App2Headers=Object.keys(state.DCDataApp2[0]);
          let temp=[]
          for(let i=0;i<state.App2Headers;i++)
          {
            temp[i]='NOT APPLICABLE';
          }
          state.DCApp2Dimensions=[...temp]
          state.viewDialogApp2=true;
        },
        
    },
    
    
})

export const { 
    isLoading,
    FAILED_LOGIN, 
    SET_VIEW_DIALOG_APP1,
    SET_VIEW_DIALOG_APP2,
    INVALID_SESSION,
    INIT_APP1_DIMENSION,
    INIT_APP2_DIMENSION,
    UPDATE_APP1_DIMENSION,
    UPDATE_APP2_DIMENSION,
    UPDATE_INIT_APP1_DIMENSION,
    UPDATE_INIT_APP2_DIMENSION,
    DC_DETAILS_RECEIVED,
    LOAD_DIRECTCONNECT_RUN_IMPORT_APP1,
    LOAD_DIRECTCONNECT_RUN_IMPORT_APP2
     } = DirectConnectReducer.actions;

export const DCDialogApp1= ()=> async (dispatch) =>{
     dispatch(SET_VIEW_DIALOG_APP1())
    }

export const DCDialogApp2= ()=> async (dispatch) =>{
      dispatch(SET_VIEW_DIALOG_APP2())
     }

export const initApp1Dimension= (payload)=> async (dispatch) =>{
     dispatch(INIT_APP1_DIMENSION(payload))
    }

export const initApp2Dimension= (payload)=> async (dispatch) =>{
        dispatch(INIT_APP2_DIMENSION(payload))
      }

export const updateApp1Dimension= (payload)=> async (dispatch) =>{
        dispatch(UPDATE_APP1_DIMENSION({
          i:payload.index, 
          val:payload.value
        }))
      }

export const updateApp2Dimension = (payload)=> async (dispatch) =>{
          dispatch(UPDATE_APP2_DIMENSION({
            i:payload.index, 
            val:payload.value
          }))
       }

export const updateinitApp1Dimension= (payload)=> async (dispatch) =>{
        dispatch(UPDATE_INIT_APP1_DIMENSION(payload))
      }

export const updateinitApp2Dimension = (payload)=> async (dispatch) =>{
          dispatch(UPDATE_INIT_APP2_DIMENSION(payload))
       }
//Direct Connect Login
export const directconnectLogin = (payload) => async dispatch => {
    dispatch(enableLoader());
    try {
        const response = await makePutAPICall('recon/dc/info', payload);
       
        if (response.status === 200) {
           // updateToken(response);
            toast.success("Your Direct Connect login was successful");
            dispatch(DC_DETAILS_RECEIVED(response));
            dispatch(hideLoader());
        } 
        else {
            toast.error(response.message);
            dispatch(FAILED_LOGIN(response));
            dispatch(hideLoader());
        }
    }
    catch {
        dispatch(hideLoader());
    }
}

//DIRECT CONNCET
export const getDirectConnectSourceData = (payload) => async (dispatch) => {
    try {
      dispatch(enableLoader()); 
      const response = await makePostAPICall("source/dc/import", payload);    
       
      if (response.status === 200) {
        if(payload.appType===0)
        {
        dispatch(
          LOAD_DIRECTCONNECT_RUN_IMPORT_APP1({
            response: response,
          }));
        }
        else
        {
          dispatch(
            LOAD_DIRECTCONNECT_RUN_IMPORT_APP2({
              response: response,
            }));
        }
        toast.success('Data retreived successfully');
      } else if (response.status === 401) {
        dispatch(INVALID_SESSION(response));
        redirectToLogin();
      } else {
        toast.error(response.message);
      }
      dispatch(hideLoader());
    } catch (err) {
      dispatch(hideLoader());
    }
  };

  // Post API call for onestream configuration

  export const OneStreamSourceData = (payload) => async (dispatch) => {
    try {
      dispatch(enableLoader()); 
      const response = await makePostAPICall("general/user/onestream_config", payload);    
       
      if (response.status === 200) {
        if(payload.appType===0)
        {
        dispatch(
          LOAD_DIRECTCONNECT_RUN_IMPORT_APP1({
            response: response,
          }));
        }
        else
        {
          dispatch(
            LOAD_DIRECTCONNECT_RUN_IMPORT_APP2({
              response: response,
            }));
        }
        toast.success('Data retreived successfully');
      } else if (response.status === 401) {
        dispatch(INVALID_SESSION(response));
        redirectToLogin();
      } else {
        toast.error(response.message);
      }
      dispatch(hideLoader());
    } catch (err) {
      dispatch(hideLoader());
    }
  };

  
export default DirectConnectReducer.reducer;

