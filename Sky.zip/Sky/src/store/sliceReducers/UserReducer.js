
import { createSlice } from "@reduxjs/toolkit";
import { toast } from "react-toastify";
import {
  makeGetAPICall,
  makePostAPICall,
  makePostUpdateUserAPICall,
  makeDeleteAPICall,
} from "../../utils/apiService";
import { showTostify } from "../../utils/utils";
import { enableLoader, hideLoader } from "../sliceReducers/LoadReducer";

export const userReducer = createSlice({
  name: "user",
  initialState: {
    loading: false,
    data: {
      data: [],
    },
    error: null,
  },
  reducers: {
    usersReceived: (state, action) => {
      state.loading = false;
      state.data = action.payload;
     
    },
    inviteUsersRecived: (state, action) => {
      state.loading = false;
      state.data.data = !!action.payload.inviteList
        ? action.payload.inviteList
        : [];
      state.data.message = !!action.payload.message
        ? action.payload.message
        : "";
    },
    usersInvited: (state, action) => {
      state.loading = false;
      state.data = action.payload;
    },
    setUserStatus: (state, action) => {
      state.loading = false;
      state.error = null;
     
    },
    usersDetailsUpdated: (state, action)=>{
      state.loading = false;
      state.error = null;
      let index = state.data.data.findIndex((p) => {
         return p.email === action.payload.newdata.email;
       });
     state.data.data[index] = action.payload.newdata;
    },
    addinviteduserDetailsUpdated: (state, action) => {
      state.loading = false;
      // state.userList = [...state.userList]
      state.error = null;
      state.data.data.push(action.payload);
    },
    MANAGE_USER_DELETE: (state, action) => {
      state.loading = false;
      state.error = null;
      state.data.data = (state.data.data).filter(
        (data) => data.email !== action.payload.newdata
       );
    },
   
    failed: (state, action) => {
      state.loading = false;
      state.error = action.payload.message;
    },
  },
});
export const {
  usersReceived,
  inviteUsersRecived,
  setUserStatus,
  usersInvited,
  usersDetailsUpdated,
  failed,
  MANAGE_USER_DELETE,
  addinviteduserDetailsUpdated,
} = userReducer.actions;

export const getUserlist = (URI) => async (dispatch) => {
  dispatch(enableLoader({ loading: true }));
  const response = await makeGetAPICall(URI);
  if (response.status === 200) {
    if (!!response.data) {
      dispatch(usersReceived(response));
    } else {
      dispatch(inviteUsersRecived(response));
    }
  } else {
    showTostify(response);
    dispatch(failed(response));
  }
  dispatch(hideLoader({ loading: false }));
};

export const updateUserStatus = (payload) => async (dispatch) => {
    dispatch(enableLoader({ loading: true }));
    const response = await makePostAPICall("general/user/update", payload);
    if (response.status === 200) {
      dispatch(usersDetailsUpdated(payload));
      showTostify(response);
    } else {
      dispatch(failed(response));
    }
    dispatch(hideLoader({ loading: false }));
  };

export const inviteUser = (payload) => async (dispatch) => {
  dispatch(enableLoader());
  try{
    const response = await makePostAPICall("general/user/invite", payload);
    if (response.status === 200) {
      toast.success("User invited successfully");
      dispatch(addinviteduserDetailsUpdated(payload));
    } else {
      toast.error(response.message);
      dispatch(failed(response));
      dispatch(hideLoader());
    }
    dispatch(hideLoader());
  }
  catch{
    dispatch(hideLoader());
  }
};

export const resendInvite = (payload) => async (dispatch) => {
  dispatch(enableLoader());
  try 
  {
    const response = await makePostAPICall("general/user/resend", payload);
    toast.success("Invite link sent successfully");
    if (response.status === 200) {
      dispatch(usersDetailsUpdated(response));
    } else {
      toast.error(response.message);
      dispatch(failed(response));
      dispatch(hideLoader());
    }
    dispatch(hideLoader());
  }
  catch { 
    dispatch(hideLoader());
  }
};

export const updateUser = (payload) => async (dispatch) => {
  dispatch(enableLoader({ loading: true }));
  const response = await makePostUpdateUserAPICall("general/user/update", payload);
  toast.success("User updated successfully");
  if (response.status === 200) {
    dispatch(usersDetailsUpdated({
      response:response,
      newdata:payload }));    
  } else {
    dispatch(failed(response));
  }
  dispatch(hideLoader({ loading: false }));
};

export const deleteUser = (payload, message) => async (dispatch) => {
  dispatch(enableLoader({ loading: true }));
  const response = await makeDeleteAPICall("general/user/delete", payload);
  if (response.status === 200) {
    
  toast.success("User deleted successfully");
    dispatch(MANAGE_USER_DELETE({ 
        response:response,
        newdata:payload.email
      }));
  } else {
    dispatch(failed(response));
    toast.error(response.message);
  }
  dispatch(hideLoader({ loading: false }));
};

export default userReducer.reducer;
