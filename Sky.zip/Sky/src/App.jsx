import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
// import "primereact/resources/themes/mdc-light-indigo/theme.css";
import "primereact/resources/themes/md-light-deeppurple/theme.css"; //theme
import "primereact/resources/primereact.min.css";                   //core css
import "primeicons/primeicons.css";
import 'primeflex/primeflex.css';
import Login from "./pages/auth/login/Login";
import Register from "./pages/auth/register/Register";
import Dashboard from "./pages/dashboard/Dashboard";
import Header from "./components/header/Header";
import PageLoader from "./components/loader/Loader";
import { useSelector } from "react-redux";
import ResetPassword from "./pages/auth/resetPassword/ResetPassword";
import UserList from "./pages/users/userList";
import './App.css';

const App = () => {
  const { loading } = useSelector((state) => state.loader);
  return (
    <div className="App">
      {loading&&<PageLoader/>}
      <BrowserRouter>
        <Header />
        <Routes component={Header}>
          <Route path="/" element={<Login defaultEmailValue={''} />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/register" element={<Register/>}/>
          <Route path="/reset" element={<ResetPassword/>}/>
          <Route path="manageuser" element={<UserList/>}/>
        </Routes>
        <ToastContainer position="top-right" />
      </BrowserRouter>
    </div>
  )
}
export default App;