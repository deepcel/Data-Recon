from ...models import ReconDimensions


def in_recon_dims(recon_id):
    recon_len = len(ReconDimensions.objects.filter(recon_id=recon_id, in_recon=True))
    dim_lst = []
    for i in range(recon_len):
        recon_obj = ReconDimensions.objects.filter(recon_id=recon_id, in_recon=True)[i]
        dim_lst.append(recon_obj.dimensions_id)
    return dim_lst
