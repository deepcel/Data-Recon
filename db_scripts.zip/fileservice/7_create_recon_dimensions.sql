-- SEQUENCE: fileservice.recon_dimensions_dimensions_id_seq

DROP SEQUENCE if exists fileservice.recon_dimensions_dimensions_id_seq cascade;

CREATE SEQUENCE fileservice.recon_dimensions_dimensions_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE fileservice.recon_dimensions_dimensions_id_seq
    OWNER TO "user_dataRecon_file";

GRANT ALL ON SEQUENCE fileservice.recon_dimensions_dimensions_id_seq TO postgres;

GRANT ALL ON SEQUENCE fileservice.recon_dimensions_dimensions_id_seq TO "user_dataRecon_file";


-- Table: fileservice.recon_dimensions

DROP TABLE if exists fileservice.recon_dimensions cascade;

CREATE TABLE IF NOT EXISTS fileservice.recon_dimensions
(
    dimensions_id bigint NOT NULL DEFAULT nextval('fileservice.recon_dimensions_dimensions_id_seq'::regclass),
	recon_id int8 NULL,
	recon_app_id int8 NULL,
	turn_on_define_order varchar NULL,
	dimension varchar NULL,
	dim_in_file varchar NULL,
	type_field varchar NULL,
	top_member varchar NULL,
	app_type varchar NULL,
	is_deleted bool NULL,
	is_active bool NULL,
	in_recon bool NOT NULL DEFAULT false,
	CONSTRAINT pk_dimensions_id PRIMARY KEY (dimensions_id)
)

TABLESPACE tbsp_data_recon;

ALTER TABLE fileservice.recon_dimensions
    OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE fileservice.recon_dimensions TO postgres;

GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.recon_dimensions TO "user_dataRecon_file";