import io
import csv
from .get_view_data import get_view_data
from ... utils.get_recon import get_recon
from .is_exists import is_exists


'''
<!---------- Method to export the data as a csv file &
             return data as a response ----------!>
'''


def export_data(recon_id, je):
    recon_data = get_recon(recon_id)
    app1_id = recon_data['app1_id']
    app2_id = recon_data['app2_id']

    if je:

        # Checking if data exists
        view_exists = is_exists('fileservice', 'view_je_' + str(recon_id))

        if view_exists['rows'][0]['exists']:
            # Getting both apps data
            view_query = 'SELECT * FROM fileService.view_je_' + str(recon_id)
            source_data = get_view_data(view_query, app1_id, app2_id)
        else:
            source_data = {
                'status': 200,
                'headers': [],
                'rows': [],
                'message': 'Data retrieved successfully!'
            }
    else:
        # Checking if data exists
        view_exists = is_exists('fileservice', 'view_' + str(recon_id))

        if view_exists['rows'][0]['exists']:
            # Getting both apps data
            view_query = 'SELECT * FROM fileService.view_' + str(recon_id)
            source_data = get_view_data(view_query, app1_id, app2_id)
        else:
            source_data = {
                'status': 200,
                'headers': [],
                'rows': [],
                'message': 'Data retrieved successfully!'
            }

    # Creating a file object without saving
    csv_file = io.StringIO()
    header = source_data['headers']
    csv_writer = csv.DictWriter(csv_file, fieldnames=header)
    csv_writer.writeheader()

    for i in range(0, len(source_data['rows'])):
        # Creating the row object
        row = dict()

        # Looping headers and adding in object
        for head in header:
            row[head] = source_data['rows'][i][head]

        # Writing to file object
        csv_writer.writerow(row)

    return csv_file
