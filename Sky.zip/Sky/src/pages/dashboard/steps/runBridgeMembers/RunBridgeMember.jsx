import React, { useEffect, useState } from "react";
import { Card } from "primereact/card";
import { useDispatch, useSelector } from "react-redux";
import "./runBridgeMembers.scss";
import {
  bridgeRun,
  bridgeRunJE,
} from "../../../../store/sliceReducers/RunBridgeReducer";
import 'primeicons/primeicons.css';
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';
import RunBridgeTable from "./RunBridgeTable";
import KickoutsTable from "./KickoutsTable";
import JEKickoutsTable from "./JEKickoutsTable";
import KickoutsFile from "./KickoutsFile";
import JEKickoutsFile from "./JEKickoutsFile";
import JERunBridgeTable from "./JERunBridgeTable";

const RunBridgeMember = () => {

  const dispatch = useDispatch();
  const [reconRunName, setReconRunName] = useState("");
 
  const reconRunList = useSelector(state =>
    state.reconRun.appData[0]
  );

  const selectedReconId = useSelector(state =>
    state.reconRun.selectedReconRunId
  );

  const runBridge = useSelector(state =>
    state.runbridge.runBridge
  );

 

  useEffect(() => {
    let filteredRecon = reconRunList.find(run => run.recon_id === selectedReconId)
    if (filteredRecon) {
      setReconRunName(filteredRecon.name)
    }

    if (selectedReconId) {
      dispatch(bridgeRun({
        recon_id: selectedReconId,
        max_rows: 100,
        page_number: 1,
        je_flag: false,
      }));

      if (selectedReconId) {
        dispatch(bridgeRunJE({
          recon_id: selectedReconId,
          max_rows: 100,
          page_number: 1,
          je_flag: true,
        }));
      };
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // const [filters, setFilters] = useState({
  //   'app1_app2': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
  //   'source_member': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
  //   'bridge_member': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] }
  // });
  
  return (
    <React.Fragment>
      <Card className="shadow-5">
        <div className="card pt-0">
          {!reconRunName && <div className="text-center text-pink-500">
            Please select recon and click run bridge tab
          </div>}
          {
            !!reconRunName && <React.Fragment>
             
             <div className="formgrid grid pb-4" style={{marginTop:'-12px'}}>
                <div className="col-12">
                     Recon RunName: <span className="font-bold">{reconRunName} </span>
                 </div>
              </div>
              <div className="formgrid grid">
                <div className="col-12">
                  {
                    !!runBridge.rows && <RunBridgeTable/>
                  }
                </div>
              </div>
              <br/>
              <div className="field p-2">
                    <span className="font-bold">FIX UNMAPPED BRIDGE MEMBER KICKOUTS</span>
              </div>
              <div className="mb-2">
                      <KickoutsFile/>
              </div>
                 <KickoutsTable/>
             
              <div className="field p-2">
                  <span className="font-bold">JE RUNBRIDGE</span>
              </div>
              <div className="formgrid grid">
                <div className="col-12">
                  {
                    !!runBridge.jerows && <JERunBridgeTable/>
                  }
                </div>
              </div>
              <br />
              <div className="field p-2">
                    <span className="font-bold">FIX UNMAPPED JE BRIDGE MEMBER KICKOUTS</span>
              </div>
              <div className="mb-2">
                      <JEKickoutsFile/>
              </div>
                      <JEKickoutsTable/>
               
            </React.Fragment>
          }
        </div>
      </Card>
    </React.Fragment>
  )
}

export default RunBridgeMember;