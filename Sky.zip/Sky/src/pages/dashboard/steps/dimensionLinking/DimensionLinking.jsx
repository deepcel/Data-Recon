import React from "react";
import { useSelector } from "react-redux";
import { Card } from 'primereact/card';
import Dimensions from "./Dimensions";
import DimImport from "./DimImport";
import DimFields from "./DimFields";
import "./dimensionLinking.scss";

const DimensionLinking = () => {

    const selectedReconId = useSelector(state =>
        state.reconRun.selectedReconRunId
      );

    return (
        <React.Fragment>
            <Card className="shadow-5">
                <div className="card pt-0 m-0">
                {selectedReconId===''? <div className="text-left text-pink-600 mb-3">
                        Please select recon run to enter recon fields and dimensions 
                   </div>:''}
                   <DimFields/>
                   <DimImport/>
                   <Dimensions/>
                   
                </div>
            </Card>
        </React.Fragment>);
}
export default DimensionLinking;