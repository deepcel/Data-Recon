import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { useFormik } from 'formik';
import { InputText } from 'primereact/inputtext';
import { persistor } from "../../../store/index";
import { Button } from 'primereact/button';
import { Password } from 'primereact/password';
import { classNames } from 'primereact/utils';
import Footer from "../../../components/footer/Footer";
import { checkUserLogin, resetError, sendResetDetails } from "../../../store/sliceReducers/AuthReducer";
import { clearSession, getToken } from '../../../utils/utils';
import "./login.scss";
import { Typography, Link } from '@material-ui/core';


function Login() {
    const [errMessage, setErrorMessage] = useState("");
    const [isforgot, setIsForgot] = useState(false);
    const [isFailed, setIsFailed] = useState({ error: null });
    const [disable, setDisable] = useState(false);
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const appData = useSelector(state =>
        state.auth
    );

    const loginForm = useFormik({
        initialValues: {
            email: '',
            password: ''
        },
        enableReinitialize: false,
        validate: (data) => {
            let errors = {};

            if (!data.email) {

                errors.email = 'Email is required.';
            }
            else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(data.email)) {
                errors.email = 'Invalid email address. E.g. example@email.com';
            }

            if (!data.password) {
                errors.password = 'Password is required.';
            }
            return errors;
        },

        onSubmit: (data) => {
            dispatch(checkUserLogin({ email: data.email, password: data.password }));
            setErrorMessage("");
        },
    });

    const handleEmail = (e) => {
        loginForm.values.password = "";
    }
    const isFormFieldValid = (name) => !!(loginForm.touched[name] && loginForm.errors[name]);
    const getFormErrorMessage = (name) => {
        return isFormFieldValid(name) && <small className="p-error">{loginForm.errors[name]}</small>;
    };

    useEffect(() => {
        clearSession();
        persistor.purge();
    }, []);

    useEffect(() => {
        if (appData && appData.data.status === 200 && appData.data.access_token !== '') {
            loginForm.resetForm();
            navigate("/dashboard");
            // dispatch(listReconRun());
        }

        if (appData.error && appData.error !== '') {
            setErrorMessage(appData.error);
        }
        else {
            setErrorMessage("");
        }

    }, [appData, dispatch, navigate, loginForm]);

    const removeErrorMessage = () => {
        if (errMessage && errMessage.length > 0) {
            setErrorMessage("");
            dispatch(resetError());
        }

    }

    const changeView = (isChecked, position) => {
        position(isChecked);
        setIsFailed({ error: null })
    }

    const handleStateChange = (responce) => {
        const authDetails = !!responce ? responce : getToken('objUser');
        if (!!authDetails.email) {
            navigate("/dashboard");
        } else {
            setIsFailed(authDetails);
        }
    }

    const resetInputField = () => {
        setEmail("");

    }

    const setEmailvalue = (email) => {
        setEmail(email);
        setDisable(false);
        setIsFailed({ error: null });
    }

    const handleReset = (e) => {
        e.preventDefault();
        dispatch(sendResetDetails({ email: email }, handleStateChange));
        resetInputField();
        setDisable(true);
    };

    return (
        <React.Fragment>
            <div className="content grid grid-nogutter surface-section text-800">
                {isforgot === false &&
                    <><div className="col-12 md:col-6 p-5 mb-0 text-center md:text-left flex align-items-center ">
                        <section>
                            <span className="block text-6xl font-bold mb-1">Data Recon Automation...</span>
                            <div className="text-6xl text-custom font-bold">Reconcile two applications and generate reports</div>
                            {/* <img src="assets/images/img25.svg" alt="hero-1" className="md:ml-auto block md:h-full" style={{ clipPath: 'polygon(8% 0, 100% 0%, 100% 100%, 0 100%)', width: "48%"}} /> */}
                        </section>
                    </div><div className="col-12 md:col-6 flex align align-items-center justify-content-center overflow-hidden">
                            <div className="surface-card m-4 p-4 shadow-2 border-round w-full lg:w-6">
                                <div className="text-center mb-2">
                                    <img src="./assets/images/login-icon.svg" alt="hyper" height="50" className="mb-3" />
                                    <div className="text-900 text-3xl font-medium mb-5">Sign In</div>
                                </div>

                                <form onSubmit={loginForm.handleSubmit} className="p-fluid">
                                    <div className="field mb-5">
                                        <span className="p-float-label p-input-icon-right">
                                            <i className="pi pi-envelope" />
                                            <InputText id="email"
                                                name="email"
                                                value={loginForm.values.email}
                                                onChange={(e) => { removeErrorMessage(); loginForm.handleChange(e); handleEmail(e); }}
                                                className={classNames({ 'p-invalid': isFormFieldValid('email') })} />
                                            <label htmlFor="email" className={classNames({ 'p-error': isFormFieldValid('email') })}>Email*</label>
                                        </span>
                                        {getFormErrorMessage('email')}
                                    </div>
                                    <div className="field mb-5">
                                        <span className="p-float-label">
                                            <Password id="password"
                                                name="password"
                                                value={loginForm.values.password}
                                                onChange={(e) => { removeErrorMessage(); loginForm.handleChange(e); }}
                                                toggleMask className={classNames({ 'p-invalid': isFormFieldValid('password') })}
                                                panelClassName="hidden" />
                                            <label htmlFor="password" className={classNames({ 'p-error': isFormFieldValid('password') })}>Password*</label>
                                        </span>
                                        {getFormErrorMessage('password')}
                                    </div>

                                    <div className="flex justify-content-end mb-3">
                                        <a href='#' className="font-medium no-underline ml-2 text-blue-500 cursor-pointer" onClick={() => changeView(true, setIsForgot)}>Forgot password?</a>
                                    </div>
                                    {errMessage && <span className="flex justify-content-center mb-3 p-error"> {errMessage} </span>}
                                    <Button type="submit" label="Submit" className="mt-2 bg-primary" />
                                </form>
                            </div>
                        </div></>
                }

                {isforgot === true &&
                    <><div className="col-12 md:col-6 overflow-hidden">
                        {/* <span>Data Recon Automation...</span> */}
                        <img src="assets/images/forgot.svg" alt="hero-1" className="md:ml-auto block md:h-full" style={{ clipPath: 'polygon(8% 0, 100% 0%, 100% 100%, 0 100%)', width: "82%", marginRight: "35px" }} />
                    </div>
                        <div className="col-12 md:col-6 flex align align-items-center justify-content-center overflow-hidden">
                            <div className="surface-card m-4 p-4 shadow-2 border-round w-full lg:w-6">
                                <div className="text-center">
                                    <div className="text-900 text-3xl font-medium mb-5">Forgot Your Password</div>
                                </div>
                                <form className="p-fluid" onSubmit={(e) => handleReset(e)} >
                                    <div className="field mb-5">
                                        <span className="p-float-label p-input-icon-right">
                                            <i className="pi pi-envelope" />
                                            <InputText id="email"
                                                required
                                                value={email}
                                                onChange={(e) => setEmailvalue(e.target.value)} />
                                            <label htmlFor="email"
                                            >Email*</label>
                                        </span>
                                    </div>
                                    <Button type="submit" label="Send verification" className="mt-2 mb-3 bg-primary" />

                                    <Typography sx={{ m: 2 }}>
                                        <Link onClick={() => changeView(false, setIsForgot)}>
                                            Sign in?
                                        </Link>
                                    </Typography>
                                </form>
                            </div>
                        </div>
                    </>}
            </div>
            <Footer />
        </React.Fragment >
    )
}

export default Login;