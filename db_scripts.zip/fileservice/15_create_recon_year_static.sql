DROP SEQUENCE if exists fileservice.recon_year_static_year_id_seq cascade;

CREATE SEQUENCE fileservice.recon_year_static_year_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807
	START 1
	CACHE 1
	NO CYCLE;

-- Permissions

ALTER SEQUENCE fileservice.recon_year_static_year_id_seq OWNER TO "user_dataRecon_file";
GRANT ALL ON SEQUENCE fileservice.recon_year_static_year_id_seq TO "user_dataRecon_file";


-- Drop table

DROP TABLE if exists fileservice.recon_year_static;

CREATE TABLE fileservice.recon_year_static (
	year_id bigserial NOT NULL,
	source_format varchar NULL,
	target_format varchar NULL,
	CONSTRAINT recon_year_static_un UNIQUE (source_format)
);

-- Permissions

ALTER TABLE fileservice.recon_year_static OWNER TO "user_dataRecon_file";
GRANT ALL ON TABLE fileservice.recon_year_static TO "user_dataRecon_file";