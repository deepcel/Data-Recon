import React, { useState,useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import { bridgeMemberImport } from "../../../../store/sliceReducers/BridgeMemberReducer";
import { getExtension, cancelOptions } from "../../../../utils/fileutils";
import { Tooltip } from 'primereact/tooltip';
import { FileUpload } from 'primereact/fileupload';
import { Button } from "primereact/button";
import "./bridgeMembers.scss";

const BridgeFile = () => {
  const dispatch = useDispatch();
  const fileUploadRef1 = useRef(null);
  const fileUploadRef2 = useRef(null);
  const authData = useSelector((state) => state.auth);
  let { data } = authData.data;
  const AccessType = data.access_type.privilege === 0 ? true : false;

  const [totalSizeBridge1, setTotalSizeBridge1] = useState(0);
  const [totalSizeBridge2, setTotalSizeBridge2] = useState(0);
  const chooseOptions = {icon:"pi pi-plus" , className:"bg-primary custom-choose-btn", tooltip:"" };
  const uploadOptions = { icon: 'pi pi-fw pi-cloud-upload', className: 'p-button-outlined bg-primary' };
  
  const selectedReconId = useSelector(state =>
    state.reconRun.selectedReconRunId
  );

  const onTemplateRemoveBridge1 = (file, callback) => {
    setTotalSizeBridge1(totalSizeBridge1 - file.size);
    callback();
  };

  const onTemplateRemoveBridge2 = (file, callback) => {
    setTotalSizeBridge2(totalSizeBridge2 - file.size);
    callback();
  };

  const itemTemplateBridge1 = (file, props) => {
    return (
      <div className="flex justify-content-between ">
        <div className="flex align-items-center" style={{ width: "40%" }}>
          <span className="flex flex-column text-left ml-3">{file.name}</span>
        </div>

        <Button
          icon="pi pi-times"
          className="p-button-secondary"
          onClick={() => onTemplateRemoveBridge1(file, props.onRemove)}
        />
      </div>
    );
  };

  const itemTemplateBridge2 = (file, props) => {
    return (
      <div className="flex justify-content-between ">
        <div className="flex align-items-center" style={{ width: "40%" }}>
          <span className="flex flex-column text-left ml-3">{file.name}</span>
        </div>

        <Button
          icon="pi pi-times"
          className="p-button-secondary"
          onClick={() => onTemplateRemoveBridge2(file, props.onRemove)}
        />
      </div>
    );
  };

  const fileUpload = (files, appType) => {
    const supportedFileFormat = ["csv", "txt"];
    const [file] = files;
    if (file) {
      if (!supportedFileFormat.includes(getExtension(file.name))) {
        toast.error("Unsupported file format, Please upload valid files(.csv,.txt)");
        return;
      }
    }
    const fileReader = new FileReader();
    fileReader.onload = (e) => {
      let formData = new FormData();
      formData.append('bridge_file', file);
      formData.append('recon_id', selectedReconId);
      formData.append('app_type', appType);
      // formData.append('is_default', checked);
      dispatch(bridgeMemberImport(formData, appType));
      if(appType===0)
      {
        fileUploadRef1.current.clear();        
      }
      else
      {
        fileUploadRef2.current.clear();
      }
    };
    fileReader.readAsDataURL(file);
  }

  const app1BridgeMemberUpload = ({ files }) => {
    fileUpload(files, 0);
  };

  const app2BridgeMemberUpload = ({ files }) => {
    fileUpload(files, 1);
  };

  return (
    <>
      <div className="formgrid grid">
        <div className="col-6">
        <Tooltip target=".custom-choose-btn" content="Files delimited with (,), (;) in .csv or .txt format are accepted for import"/>
          <label htmlFor="app1FileUpload" className="mb-3">APP1 STORED BRIDGE MEMBERS:</label>
          <span className="p-float-label p-input-icon-right mt-2 w-full">
            <FileUpload accept=".csv, .txt"
            ref={fileUploadRef1}
              disabled={!AccessType}
              maxFileSize={100000000}
              customUpload
              chooseOptions={chooseOptions}
              uploadOptions={uploadOptions}
              cancelOptions={cancelOptions}
              itemTemplate={itemTemplateBridge1}
              uploadHandler={app1BridgeMemberUpload}
              emptyTemplate={<p className="m-0">Drag and drop files to here to upload.</p>} />
          </span>
        </div>
        <div className="col-6">
          <label htmlFor="app2FileUpload" className="mb-3">APP2 STORED BRIDGE MEMBERS:</label>
          <span className="p-float-label p-input-icon-right mt-2 w-full">
            <FileUpload accept=".csv, .txt"
            ref={fileUploadRef2}
              disabled={!AccessType}
              maxFileSize={100000000}
              customUpload
              chooseOptions={chooseOptions}
              uploadOptions={uploadOptions}
              cancelOptions={cancelOptions}
              itemTemplate={itemTemplateBridge2}
              uploadHandler={app2BridgeMemberUpload}
              emptyTemplate={<p className="m-0">Drag and drop files to here to upload.</p>} />
          </span>
        </div>
      </div>
    </>
  )
}
export default BridgeFile;