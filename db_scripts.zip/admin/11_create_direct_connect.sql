DROP TABLE if exists "admin".direct_connect cascade;

CREATE TABLE "admin".direct_connect (
	onestreamid varchar(50) NULL,
	app_name varchar(50) NULL,
	import_type int4 NULL,
	dc_username varchar(50) NULL,
	dc_password bytea NULL,
	dc_url varchar(50) NULL,
	tag bytea NULL,
	nonce bytea NULL,
	email varchar(50) NULL,
	tenant_id varchar(50) NULL
);