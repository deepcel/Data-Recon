import { createSlice } from "@reduxjs/toolkit";
import { toast } from "react-toastify";
import {
  makePostAPICall,
  makePutAPIFormData,
  makePutAPICall,
  makePostAPICallFileDownload,
  makeDeleteBodyParamAPICall,
} from "../../utils/apiService";
import { redirectToLogin } from "../../utils/utils";
import { enableLoader, hideLoader } from "./LoadReducer";
import { DCDialogApp1,DCDialogApp2  } from "./DirectConnectReducer";
// Dashboard reducer is used for handle all the steps data
export const runImportReducer = createSlice({
  name: "runImport",
  initialState: {
    loading: false,
    error: null,
    runImportData: {
      headers: [],
      rows: [],
      app1Rows: [],
      app2Rows: [],
      app1JERows: [],
      app2JERows: [],
      jerows: [],
      jeheaders: [],
    },
  },
  reducers: {
    isLoading: (state, action) => {
      state.loading = true;
    },
    VALIDATE_SESSION: (state, action) => {
      state.loading = false;
      state.error = null;
    },
    INVALID_SESSION: (state) => {
      state.loading = false;
      state.error = null;
    },
    RUN_IMPORT_UPDATE: (state, action) => {
      state.loading = false;
      state.error = null;
      state.runImportData.headers = [...action.payload.response.headers];
      if (action.payload.appType === 0) {
        state.runImportData.app1Rows = [...action.payload.response.rows];
      } else {
        state.runImportData.app2Rows = [...action.payload.response.rows];
      }
      state.runImportData.rows = [
        ...state.runImportData.app1Rows,
        ...state.runImportData.app2Rows,
      ];
    },
    RUN_JE_IMPORT_UPDATE: (state, action) => {
      state.loading = false;
      state.error = null;
      state.runImportData.jeheaders = [...action.payload.response.headers];
      if (action.payload.appType === 0) {
        state.runImportData.app1JERows = [...action.payload.response.rows];
      } else {
        state.runImportData.app2JERows = [...action.payload.response.rows];
      }
      state.runImportData.jerows = [
        ...state.runImportData.app1JERows,
        ...state.runImportData.app2JERows,
      ];
    },
    LOAD_RUN_IMPORT: (state, action) => {
      state.loading = false;
      state.error = null;
      state.runImportData.headers = [...action.payload.response.headers];
      state.runImportData.rows = [...action.payload.response.rows];
    },
    LOAD_RUN_JE_IMPORT: (state, action) => {
      state.loading = false;
      state.error = null;
      state.runImportData.jeheaders = [...action.payload.response.headers];
      state.runImportData.jerows = [...action.payload.response.rows];
    },
    UPDATE_JE_TABLE: (state, action) => {
      state.loading = false;
      state.error = null;
      if (action.payload.appType === 0) {
        state.runImportData.app1JERows = [...action.payload.response.rows];
      } else {
        state.runImportData.app2JERows = [...action.payload.response.rows];
      }
    },
    DELETE_JE_RUN_IMPORT: (state, action) => {
      state.loading = false;
      state.error = null;
      if (action.payload.response.appType === "0") {
        state.runImportData.app1JERows = state.runImportData.app1JERows.filter(
          (item) => item.record_id !== action.payload.response.record_id
        );
      } else if (action.payload.response.appType === "1") {
        state.runImportData.app2JERows = state.runImportData.app2JERows.filter(
          (item) => item.record_id !== action.payload.response.record_id
        );
      }
    },
  },
});

export const {
  isLoading,
  INVALID_SESSION,
  VALIDATE_SESSION,
  LOAD_RUN_IMPORT,
  LOAD_RUN_JE_IMPORT,
  RUN_JE_IMPORT_UPDATE,
  RUN_IMPORT_UPDATE,
  LOAD_DIRECTCONNECT_RUN_IMPORT,
  UPDATE_JE_TABLE,
  DELETE_JE_RUN_IMPORT,
} = runImportReducer.actions;

// Get Recon details with dimension
export const runImport = (formData, appType) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPIFormData("source/file/import", formData);
    if (response.status === 200) {
      dispatch(
        RUN_IMPORT_UPDATE({
          response: response,
          appType: appType,
        })
      );
      toast.success("File imported successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const updateDimensions = (payload) => async (dispatch) => {
  try {
    const response = await makePostAPICall("source/dc/dimtag", payload);
    dispatch(enableLoader());
    if (response.status === 200) {
      let appType = payload.appType === "0" ? 0 : 1;
      dispatch(
        RUN_IMPORT_UPDATE({
          response: response,
          appType: appType,
        })
      );
      if(appType)
      {
        dispatch(DCDialogApp1())
      }
      else
      {
        dispatch(DCDialogApp2())
      }
      toast.success("Dimensions saved and File imported successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};
export const getSourceData = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePostAPICall("source/data", payload);
    if (response.status === 200) {
      dispatch(
        LOAD_RUN_IMPORT({
          response: response,
        })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

//runmport source data export
export const exportrunimport = (payload) => async (dispatch) => {
  try {
    dispatch(isLoading({ loading: true }));
    const response = await makePostAPICallFileDownload(
      "source/export",
      payload
    );
    if (response.status === 200) {
      toast.success("Source data downloaded successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

//journal entry
export const exportJournalEntry = (payload) => async (dispatch) => {
  try {
    dispatch(isLoading({ loading: true }));
    const response = await makePostAPICallFileDownload(
      "source/export",
      payload
    );
    if (response.status === 200) {
      toast.success("JE data downloaded successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const JEsourceDataImport = (formData, appType) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPIFormData(
      "source/file/je/import",
      formData
    );
    if (response.status === 200) {
      dispatch(
        RUN_JE_IMPORT_UPDATE({
          response: response,
          appType: appType,
        })
      );
      toast.success("File imported successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const getJESourceData = (payload) => async (dispatch) => {
  try {
    dispatch(isLoading({ loading: true }));
    const response = await makePostAPICall("source/je/data", payload);
    if (response.status === 200) {
      dispatch(
        LOAD_RUN_JE_IMPORT({
          response: response,
        })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const updateJeTable = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPICall("source/je/update", payload);
    if (response.status === 200) {
      toast.success("Je data updated successfully");
      dispatch(
        UPDATE_JE_TABLE({
          response: response,
        })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const deleteJERunImport = (payload, appType) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPICall(
      "source/je/delete",
      payload
    );
    if (response.status === 200) {
      dispatch(
        DELETE_JE_RUN_IMPORT({
          response: {
            appType: appType,
            record_id: payload.record_id,
          },
        })
      );
      toast.success("RunImport JE row is deleted successfully");
      // dispatch(getJESourceData(payload.recon_id));
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};
export default runImportReducer.reducer;
