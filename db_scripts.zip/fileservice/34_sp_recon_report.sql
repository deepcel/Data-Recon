CREATE OR REPLACE PROCEDURE fileservice.sp_recon_report(recon_id integer)
 LANGUAGE plpgsql
AS $procedure$
declare
var_recon_id integer := recon_id;
s_schema_name text := 'fileservice';

var_threshold decimal := 0;
var_AMOUNT text;
var_q1_sel text;
var_q2_cat text;
var_q1_sel_gt text;
var_dim text[];
var_year text;
var_period text;
v_yp text;
var_order text := '';
v_yp2 text;
v_yp3 text;
v_yp4 text;
v_yp5 text;
v_order2 text := '';
var_query text;
v_gt text;
var_piv text :='';
var_split integer := 1;
v_dim text;
begin
	/*
	 * Crosstab Query Parts
	*/	
	-- Report for non journal entries
	select *
	into var_q1_sel, var_AMOUNT, /*var_q1_sel_gt,*/ var_q2_cat, var_dim, var_year, var_period
	from (
		select * from fileservice.f_get_recon_report_query(var_recon_id, false) as (sel_clause_1 text, amt text, /*sel_clause_gt text,*/ sel_clause_category text, dim_name text[], dim_year text, dim_period text)
	)q;
	
	
	var_q2_cat = 'select '|| var_q2_cat ||' from '||s_schema_name||'.bridgesync_'||var_recon_id||' group by 1';
--		raise notice '%',var_q2_cat;
	
	execute 'select string_agg(concat(''"'',year_period,''"''),'','') as yp 
	from ('||var_q2_cat||')q'
	into v_yp;
	
--	substr starts at character 5 since data should be in yearperiod format eg 2019Jan. So char 5 onwards will be Jan
	execute 'select substring(split_part(regexp_replace('''||v_yp||''',''"'','''',''g''),'','',1),5)'
	into var_order;

--	raise notice '%===%===%', var_order,var_year,var_period;
	
	execute 'select 
	case
		when '''||var_order||''' = "Mon" then ''to_date(concat('||var_year||','||var_period||'),''''''''yyyyMon'''''''')''
		when '''||var_order||''' = "P_mm" then ''substring(concat('||var_year||','||var_period||'),length("year_period")-1)::integer''
		when trim('''||var_order||''',''0'') = "Month_ID"::text then ''to_date(concat('||var_year||','||var_period||'),''''''''MM'''''''')''
		when '''||var_order||''' = "Month" then ''to_date(concat('||var_year||','||var_period||'),''''''''Month'''''''')''
	end as yp_order_1,
	case
		when '''||var_order||''' = "Mon" then ''to_date(concat('||var_year||','||var_period||'),''''yyyyMon'''')''
		when '''||var_order||''' = "P_mm" then ''substring(concat('||var_year||','||var_period||'),length("year_period")-1)::integer''
		when trim('''||var_order||''',''0'') = "Month_ID"::text then ''to_date(concat('||var_year||','||var_period||'),''''MM'''')''
		when '''||var_order||''' = "Month" then ''to_date(concat('||var_year||','||var_period||'),''''Month'''')''
	end as yp_order_2
	from fileservice.recon_month_static
	where trim('''||var_order||''',''0'')::text in ("Month","Mon","P_mm","Month_ID"::text)'
	into var_order, v_order2;
--	raise notice '%', var_order;
	
	
	/*
	 * Crosstab Query 1
	 */
	
	var_q1_sel = 'select '||var_q1_sel||' case when abs('||var_AMOUNT||') > '||var_threshold||' then '||var_AMOUNT||' else 0 end from '||s_schema_name||'.bridgesync_'||var_recon_id||' group by 1,2 order by 1,'||var_order;
	--raise notice '3 %', var_q1_sel;
	
	
	/*
	 * Crosstab Query 1 - Grand Total
	 */
--	var_q1_sel_gt = 'select '|| var_q1_sel_gt||var_AMOUNT||' from '||s_schema_name||'.view_bridgesync_'||var_recon_id||' group by 1,2 order by 1,'||var_order;
	--raise notice '%', var_q1_sel_gt;

	/*,string_agg(concat(''case when "'',year_period,''"<0 then concat(''''('''',"'',year_period,''"* -1,'''')'''') else "'',year_period,''"::text end as "'',year_period,''"''),'','') as yp_4*/
	execute 'select string_agg(concat(''"'',year_period,''" decimal''),'','') as yp2
	,string_agg(concat(''round(coalesce("'',year_period,''",0),2) as "'',year_period,''"''),'','') as yp3
	,string_agg(concat(''"'',year_period,''"::decimal''),'','') as yp_4
	,string_agg(concat(''abs("'',year_period,''") ''), ''+ '') as yp5 from ('||var_q2_cat||' order by '|| v_order2 ||')q'
	into v_yp2,v_yp3,v_yp4,v_yp5;
	
	/*
	 * Crosstab Query 2 - Category
	 */	
	var_q2_cat = var_q2_cat||' order by '||var_order;
--	raise notice '%', var_q2_cat;
	
	var_order := '';
	var_query = 'drop table if exists '||s_schema_name||'.report_'||var_recon_id||' cascade; create table '||s_schema_name||'.report_'||var_recon_id;
	var_query = var_query||' as (with pivot_table as (';
	var_query = var_query||E'\n select ';
	
	foreach v_dim in array var_dim
	loop
		if v_dim is not null
		then
			if var_split = 1
			then
				v_gt = v_dim;
--				var_union = v_dim;
			end if;
		
			var_piv = var_piv||'split_part(conc,''|'','||var_split||') as '||v_dim||',';
			var_order = var_order||','||v_dim; 
			var_split = var_split+1;
		end if;
	end loop;
	--raise notice '%', var_piv;
	
	var_query = var_query||E'\n'||var_piv||E'\n'||v_yp;
	var_query = var_query||E'\n ,1 as order_by \n from '||s_schema_name||'.crosstab(';
	var_query = var_query||E'\n'''||var_q1_sel||''','||E'\n'''||var_q2_cat||''') as final_result (';
	var_query = var_query||E'\n conc text,'||v_yp2||E'\n ) ';
	
--	var_query = var_query||E'\nunion';
--	var_query = var_query||E'\nselect \n'||var_piv||E'\n'||v_yp||E'\n ,2 as order_by \n from crosstab(';
--	var_query = var_query||E'\n'''||var_q1_sel_gt||''','||E'\n'''||var_q2_cat||''') as final_result (';
--	var_query = var_query||E'\nconc text,'||v_yp2||E'\n )';
	
	var_query = var_query||'order by order_by'||var_order||E'), final_table as (\n select \n'||substring(var_order,2)||','||v_yp3||' from pivot_table) ';
	var_query = var_query||E'\nselect \n'||substring(var_order,2)||E',\n'||v_yp4||', ';
	var_query = var_query||'('||v_yp5||') as Grand_ABS_Total';
	var_query = var_query||E'\n from final_table \norder by case when '||v_gt||E'=''Grand Total'' then 2 else 1 end, '||substring(var_order,2)||');';
	
	raise notice '%',var_query;	
	execute var_query;
	
	--	Log Script
	call fileService.sp_log_entry(
								null::integer,
								'''Report report_'|| var_recon_id || ' without variance created'''::text,
								var_recon_id::integer,
								'report_'||var_recon_id::text
								);
							
end;
$procedure$
;

-- Permissions

ALTER PROCEDURE fileservice.sp_recon_report(int4) OWNER TO "user_dataRecon_file";
GRANT ALL ON PROCEDURE fileservice.sp_recon_report(int4) TO public;
GRANT ALL ON PROCEDURE fileservice.sp_recon_report(int4) TO postgres;
GRANT ALL ON PROCEDURE fileservice.sp_recon_report(int4) TO "user_dataRecon_file";
