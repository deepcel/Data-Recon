from datetime import datetime
from rest_framework import status
from rest_framework.decorators import permission_classes, api_view, renderer_classes, parser_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.renderers import JSONRenderer
from rest_framework.response import Response
from ..models import ReconApplications, Recon, ReconDimensions, ReconBridgeMapping
from .serializers import ReconAppSerializer, ReconSerializer, \
    ReconUpdateSerializer, DimensionSerializer, DimensionGetSerializer, \
    ReconGetSerializer
import requests
import requests
from ..utils.get_recon import get_recon
from .functions.update_app_data import update_app_data
from .functions.get_dimensions import get_dimensions
from .functions.get_dim_export import get_dim_export
from django.http import HttpResponse
from rest_framework.parsers import MultiPartParser, FormParser
from ..utils.store_file import store_file
from .functions.is_valid_file import is_valid_file
from .functions.get_dim_import import get_import_data
from .functions.recon_update import recon_update_dim
from ..utils.run_export_script import run_export_script
from django.conf import settings
from ..models import ReconUser
import os
import copy
from ..utils.user_permissions import is_write_permitted
from Crypto.Cipher import AES
from ..utils.export_query import dim_query


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def app_list(request):
    instance = ReconApplications.objects.all()
    serialized = ReconAppSerializer(instance, many=True)
    response_data = {
        'status': 200,
        'data': serialized.data
    }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def recon_list(request):
    # if request.user.username == 'Admin':
    instance = Recon.objects.filter(is_deleted=False).order_by('-created_date')
    # else:
    #  instance = Recon.objects.filter(is_deleted=False,
    #                                 created_by=request.user.username).order_by('-created_date')
    serialized = ReconGetSerializer(instance, many=True)
    response_data = {
        'status': 200,
        'data': serialized.data
    }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def get_recon_info(request, recon_id):
    if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
        serialized = get_recon(recon_id)
        merged_dimensions = get_dimensions(recon_id)

        # Merging recon info and related dimensions
        recon_dict = serialized
        recon_dict['dimensions'] = merged_dimensions

        response_data = {
            'status': 200,
            'data': recon_dict
        }
    else:
        response_data = {
            'status': 403,
            'message': 'No recon found with the specified id!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def recon_create(request):
    obtained_recon_name = request.data['name']
    obtained_description = request.data['description']
    recon_dimensions = request.data['dimensions']
    created_by = request.user.username
    current_time = datetime.now().time().strftime("%H:%M:%S")
    current_date = datetime.now().strftime("%Y-%m-%d")
    created_date = str(current_date) + ' ' + str(current_time)

    if is_write_permitted(request.user.email):
        if Recon.objects.filter(name=obtained_recon_name, is_deleted=False).exists():
            response_data = {
                'status': 6001,
                'message': 'Recon name already exists!'
            }
            return Response(response_data, status=status.HTTP_200_OK)
        else:
            serialized = ReconSerializer(data=request.data)
            if serialized.is_valid():
                new_recon = Recon(name=obtained_recon_name, created_by=created_by,
                                  created_date=created_date, description=obtained_description)
                new_recon.save()
                recon_id = new_recon.recon_id

                # Creating applications
                create_app1 = ReconApplications(recon_id=recon_id, app_name='0', import_type='0')
                create_app2 = ReconApplications(recon_id=recon_id, app_name='1', import_type='0')
                create_app1.save()
                create_app2.save()

                # Updating App id in recon
                new_recon.app1_id = create_app1.recon_app_id
                new_recon.app2_id = create_app2.recon_app_id
                new_recon.save()

                # Get the recon info
                instance = Recon.objects.filter(recon_id=recon_id)[0]
                serialized = ReconGetSerializer(instance)

                # Storing the default dimension info
                number_of_dimensions = len(recon_dimensions)
                dimensions_list = []
                for i in range(0, number_of_dimensions):
                    # Application one dimension
                    dimensions_list.append(
                        {
                            'turn_on_define_order': recon_dimensions[i]['order'],
                            'dimension': recon_dimensions[i]['app1_dimension'],
                            'dim_in_file': recon_dimensions[i]['app1_dim_in_file'],
                            'type_field': recon_dimensions[i]['app1_type_field'],
                            'top_member': recon_dimensions[i]['app1_top_member'],
                            'app_type': recon_dimensions[i]['app1_app_type'],
                            'is_active': recon_dimensions[i]['app1_is_active'],
                            'recon_app_id': create_app1.recon_app_id
                        }
                    )

                    # Application two dimension
                    dimensions_list.append(
                        {
                            'turn_on_define_order': recon_dimensions[i]['order'],
                            'dimension': recon_dimensions[i]['app2_dimension'],
                            'dim_in_file': recon_dimensions[i]['app2_dim_in_file'],
                            'type_field': recon_dimensions[i]['app2_type_field'],
                            'top_member': recon_dimensions[i]['app2_top_member'],
                            'app_type': recon_dimensions[i]['app2_app_type'],
                            'is_active': recon_dimensions[i]['app1_is_active'],
                            'recon_app_id': create_app2.recon_app_id
                        }
                    )

                dimensions_length = len(dimensions_list)
                for i in range(0, dimensions_length):
                    dimension = dimensions_list[i]
                    dimension['recon_id'] = recon_id
                    serialized_dim = DimensionSerializer(data=dimension)
                    if serialized_dim.is_valid():
                        serialized_dim.save()
                    else:
                        return Response(serialized_dim.errors, status=status.HTTP_400_BAD_REQUEST)

                # Making empty top member/type field values null in dimensions
                ReconDimensions.objects.filter(recon_id=recon_id, top_member='').update(top_member=None)
                ReconDimensions.objects.filter(recon_id=recon_id, type_field='').update(type_field=None)

                response_data = {
                    'status': 200,
                    'data': serialized.data,
                    'message': 'Recon created successfully!'
                }
                return Response(response_data, status=status.HTTP_200_OK)

            return Response(serialized.errors, status=status.HTTP_400_BAD_REQUEST)
    else:
        response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def recon_update(request):
    recon_id = request.data['data']['recon_id']

    if is_write_permitted(request.user.email):
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            instance = Recon.objects.filter(recon_id=recon_id)[0]

            # Updating recon status
            instance.status = "Dim Updated"
            instance.save()

            # Splitting the recon and dimension data
            recon_data = request.data['data']
            recon_dimensions = request.data['data']['dimensions']
            del recon_data['dimensions']

            # Adding modification info in data
            current_time = datetime.now().time().strftime("%H:%M:%S")
            current_date = datetime.now().strftime("%Y-%m-%d")
            modified_date = str(current_date) + ' ' + str(current_time)
            modified_by = request.user.username
            recon_data['last_modified_by'] = modified_by
            recon_data['last_modified_date'] = modified_date

            serialized = ReconUpdateSerializer(instance, data=recon_data, partial=True)
            if serialized.is_valid():
                serialized.save()

                # Updating applications info
                update_res = update_app_data(recon_id, recon_data)
                if not update_res:
                    response_data = {
                        'status': 6001,
                        'message': 'Something went wrong while updating app details!'
                    }
                    return Response(response_data, status=status.HTTP_200_OK)

            dim_update = recon_update_dim(recon_dimensions, instance, recon_id)

            if dim_update['status'] == 200:
                # Making empty top member/type field values null in dimensions
                ReconDimensions.objects.filter(recon_id=recon_id, top_member='').update(top_member=None)
                ReconDimensions.objects.filter(recon_id=recon_id, type_field='').update(type_field=None)

                # Getting the recon info
                get_serialized = get_recon(recon_id)
                get_dimensions_instance = ReconDimensions.objects.filter(recon_id=recon_id)
                get_serialized_dimensions = DimensionGetSerializer(get_dimensions_instance, many=True)

                # Merging the same order dimension together
                merged_dimensions = []
                number_of_dimensions = len(get_serialized_dimensions.data)
                for i in range(0, number_of_dimensions):
                    for j in range(i + 1, number_of_dimensions):
                        if get_serialized_dimensions.data[i]['order'] == get_serialized_dimensions.data[j]['order']:
                            merged_dict = get_serialized_dimensions.data[i] | get_serialized_dimensions.data[j]
                            merged_dimensions.append(merged_dict)

                # Ordering dimensions
                merged_dimensions.sort(key=lambda x: int(x['order']))

                # Merging recon info and related dimensions
                recon_dict = get_serialized
                recon_dict['dimensions'] = merged_dimensions

                response_data = {
                    'status': 200,
                    'data': recon_dict,
                    'message': 'Recon updated successfully!'
                }
                return Response(response_data, status=status.HTTP_200_OK)
            return Response(dim_update, status=status.HTTP_400_BAD_REQUEST)
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['DELETE'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def delete_recon(request, recon_id):

    if is_write_permitted(request.user.email):
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            instance = Recon.objects.filter(recon_id=recon_id)[0]
            instance.is_deleted = True
            instance.save()

            # Deleting applications
            ReconApplications.objects.filter(recon_id=recon_id).update(is_deleted=True)

            # Deleting bridges
            ReconBridgeMapping.objects.filter(recon_id=recon_id).update(is_deleted=True)

            # Deleting dimensions
            ReconDimensions.objects.filter(recon_id=recon_id).update(is_deleted=True)
            response_data = {
                'status': 200,
                'message': 'Recon deleted successfully!'
            }
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response_data = {
           'status': 6002,
           'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def recon_dim_order_update(request):
    recon_id = request.data['recon_id']
    drag_order = request.data['dragOrder']
    drop_order = request.data['dropOrder']

    if is_write_permitted(request.user.email):
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            if ReconDimensions.objects.filter(recon_id=recon_id, turn_on_define_order=drag_order).exists():

                # Obtaining the dragged dimension details
                updated_list = []
                instance = ReconDimensions.objects.filter(recon_id=recon_id, turn_on_define_order=drag_order)
                updated_list.append(instance[0].dimensions_id)
                updated_list.append(instance[1].dimensions_id)

                # Updating the order for dropped dimension
                ReconDimensions.objects.filter(recon_id=recon_id, turn_on_define_order=drag_order) \
                    .update(turn_on_define_order=drop_order)

                # Checking if the order got increased or decreased
                if drag_order > drop_order:
                    # Drag order is greater. Need to increment other fields
                    for i in range(drop_order, drag_order):
                        loop_instance = ReconDimensions.objects.filter(recon_id=recon_id,
                                                                       turn_on_define_order=i)
                        dim_len = len(loop_instance)
                        for j in range(0, dim_len):
                            app_id = loop_instance[j].dimensions_id
                            if app_id not in updated_list:
                                ReconDimensions.objects.filter(recon_id=recon_id, dimensions_id=app_id) \
                                    .update(turn_on_define_order=i + 1)
                                updated_list.append(app_id)
                else:
                    # Drag order is lesser. Need to decrement other fields
                    for i in range(drop_order, drag_order, -1):
                        loop_instance = ReconDimensions.objects.filter(recon_id=recon_id,
                                                                       turn_on_define_order=i)
                        dim_len = len(loop_instance)
                        for j in range(0, dim_len):
                            app_id = loop_instance[j].dimensions_id
                            if app_id not in updated_list:
                                ReconDimensions.objects.filter(recon_id=recon_id, dimensions_id=app_id) \
                                    .update(turn_on_define_order=i - 1)
                                updated_list.append(app_id)

                # Getting the return data
                get_dimensions_instance = ReconDimensions.objects.filter(recon_id=recon_id)
                get_serialized_dimensions = DimensionGetSerializer(get_dimensions_instance, many=True)

                # Merging the same order dimension together
                merged_dimensions = []
                number_of_dimensions = len(get_serialized_dimensions.data)
                for i in range(0, number_of_dimensions):
                    for j in range(i + 1, number_of_dimensions):
                        if get_serialized_dimensions.data[i]['order'] == get_serialized_dimensions.data[j]['order']:
                            merged_dict = get_serialized_dimensions.data[i] | get_serialized_dimensions.data[j]
                            merged_dimensions.append(merged_dict)

                # Ordering dimensions
                merged_dimensions.sort(key=lambda x: int(x['order']))

                response_data = {
                    'status': 200,
                    'data': merged_dimensions,
                    'message': 'Dimension re-ordered successfully!'
                }
            else:
                response_data = {
                    'status': 403,
                    'message': 'No dimension found with the specified order!'
                }
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }

    return Response(response_data, status=status.HTTP_200_OK)


# @api_view(['GET'])
# @permission_classes((IsAuthenticated,))
# @renderer_classes((JSONRenderer,))
# def dim_export(request, recon_id):
#     if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
#         current_time = datetime.now().time().strftime("%H:%M:%S")
#         current_date = datetime.now().strftime("%Y-%m-%d")
#         modified_date = str(current_date) + '_' + str(current_time)
#         file_name = 'Dim_Export_'+modified_date+'.csv'
#         export_file = get_dim_export(recon_id)
#
#
#         # Setting the download response
#         response_data = HttpResponse(export_file.getvalue(), content_type='text/csv')
#         response_data['Content-Disposition'] = 'attachment; filename=' + file_name
#         response_data['Access-Control-Expose-Headers'] = 'Content-Disposition'
#
#         return response_data
#     else:
#         response_data = {
#             'status': 403,
#             'message': 'No recon found with the specified id!'
#         }
#         return Response(response_data, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def dim_export(request, recon_id):
    if is_write_permitted(request.user.email):
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():

            current_time = datetime.now().time().strftime("%H:%M:%S")
            current_date = datetime.now().strftime("%Y-%m-%d")
            modified_date = str(current_date) + '_' + str(current_time)
            file_name = 'Dimension_export.csv'

            #Constructing the query
            query = dim_query(recon_id)

            # Calling the Shell script to create a csv file
            run_export_script(recon_id, file_name, query)

            file_path = os.path.join(settings.MEDIA_ROOT, str(recon_id) + "/export/" +file_name)
            file_path = (str(file_path).replace("\\", "/"))
            if os.path.exists(file_path):
                with open(file_path, 'rb') as fh:
                    response = HttpResponse(fh.read(), content_type="application/vnd.ms-excel")
                    response['Content-Disposition'] = 'inline; filename=' + os.path.basename(modified_date + file_path)
                    response['Access-Control-Expose-Headers'] = 'Content-Disposition'
                    return response
            else:
                response = {
                    'status': 6002,
                    'message': 'File Not Found'
                }
        else:
            response = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }
    return Response(response, status=status.HTTP_200_OK)


@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@parser_classes((MultiPartParser, FormParser))
def get_dim_import(request):
    recon_id = request.data['recon_id']
    file_obj = request.FILES['Dim_File']

    if is_write_permitted(request.user.email):
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            # Getting recon data
            instance = Recon.objects.filter(recon_id=recon_id)[0]

            # Storing file
            save_file = store_file(recon_id, file_obj)
            file_path = save_file[1]

            is_valid = is_valid_file(file_path)
            if is_valid['status'] == 200:
                # Get the imported file data
                dim_data = get_import_data(recon_id, file_path)
                response_data = copy.deepcopy(dim_data)
                # print(dim_data)

                # Saving the Dim info
                is_valid = is_valid_file(file_path)
                if is_valid['status'] == 200:
                    save_data = recon_update_dim(dim_data['rows'], instance, recon_id)

                    if save_data['status'] == 6002:
                        response_data = is_valid
                    else:
                        pass
            else:
                response_data = is_valid
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response_data = {
           'status': 6002,
           'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def dc_info(request):
    email = request.data['email']
    DC_Url = request.data['DC_Url']
    DC_Username = request.data['DC_Username']
    DC_Password = request.data['DC_Password']
    recon_id = request.data['recon_id']
    app_type = request.data['appType']

    response = requests.get(DC_Url)
    if response.status_code == 200:
        response = requests.get(DC_Url + "/HyperionPlanning/rest/", auth=(DC_Username, DC_Password))

        if response.status_code == 200:
            if isinstance(DC_Password, str):
                dc_password = DC_Password.encode()
                key = b"\xf82\xea\xaap@\n'Yw\x10B\xd8b\xac\xc6"
                cipher = AES.new(key, AES.MODE_EAX)
                nonce = cipher.nonce
                dc_password, tag = cipher.encrypt_and_digest(dc_password)

                ReconUser.objects.filter(email=email).update(DC_Url=DC_Url, DC_Username=DC_Username,
                                                             DC_Password=dc_password, tag=tag, nonce=nonce)

                ReconApplications.objects.filter(recon_id=recon_id, app_name=app_type).update(url=DC_Url)

                response_data = {
                    'status': 200,
                    'message': 'URL and Username Updated Successfully'
                }
        else:
            response_data = {
                'status': 6002,
                'message': 'Invalid Credentials'
            }
    else:
        response_data = {
            'status': 6002,
            'message': 'Invalid URL'
        }
        
    return Response(response_data, status=status.HTTP_200_OK)