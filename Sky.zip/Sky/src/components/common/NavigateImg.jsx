import React from "react";
import { useNavigate } from "react-router";

const NavigateImg = (props) => {
    const navigate = useNavigate();
    const navURI = props.path;
    const btnLabel = props.label;
    const style = {'cursor':'pointer','width':'130px'};
    return (
        <img onClick={() => {
            navigate(navURI)
        }} src={btnLabel} style={style}/>
    )
}
export default NavigateImg;