import React, { useState } from 'react';
import { useDispatch } from "react-redux";
import { useFormik } from 'formik';
import { Password } from 'primereact/password';
import { classNames } from 'primereact/utils';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { getEmail } from '../../../../utils/utils';
//import { directconnectLogin } from '../../../../store/sliceReducers/AuthReducer';
import { OneStreamSourceData } from '../../../../store/sliceReducers/DirectConnectReducer';
function OneStreamConfig() {
  const [errMessage, setErrorMessage] = useState("");
  const dispatch = useDispatch();

  // const selectedReconId = useSelector(state =>
  //   state.reconRun.selectedReconRunId
  // );

  const email = getEmail();

  const OneStreamForm = useFormik({
    initialValues: {
      url:'',
     // adapterName:'',
      clientId:'',
      tenantId: '',
      secretKey:''
    },
    validate: (data) => {
      let errors = {};

      if (!data.url) {
        errors.url = 'Url is required.';
      }
      // if (!data.adapterName) {
      //   errors.adapterName = 'Adapter Name is required.';
      // }
      if (!data.clientId) {
        errors.clientId = 'Client ID is required.';
      }
      if (!data.tenantId) {
        errors.tenantId = 'Tenant ID is required.';
      }
      // else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(data.email)) {
      //   errors.email = 'Invalid email address. E.g. example@email.com';
      // }
      if (!data.secretKey) {
        errors.secretKey = 'Secret Key is required.';
      }
      return errors;
    },
    onSubmit: (data) => {
      dispatch(OneStreamConfig({
        // "recon_id": selectedReconId,
          //  "tenant_id": data.tenantId,
          //  "client_id": data.clientId,        
          //  "client_secret": data.secretKey,        
          //  "url": data.url,
          //  "email": email 
      }));
      OneStreamForm.resetForm();
      setErrorMessage("");
    },
  });

  const isFormFieldValid = (name) => !!(OneStreamForm.touched[name] && OneStreamForm.errors[name]);
  const getFormErrorMessage = (name) => {
    return isFormFieldValid(name) && <small className="p-error">{OneStreamForm.errors[name]}</small>;
  };

  return (
    <div style={{ width: "26vw", alignItems: 'center', textAlign: 'center' }}>
      
      <form onSubmit={OneStreamForm.handleSubmit}
           className="p-fluid">
        <div className="field m-2 mb-4">
          <span className="p-float-label">
            <InputText id="url" name="url"
              value={OneStreamForm.values.url}
              onChange={(e) => { OneStreamForm.handleChange(e); }}
              autoFocus className={classNames({ 'p-invalid': isFormFieldValid('url') })} />
            <label htmlFor="url" className={classNames({ 'p-error': isFormFieldValid('url') })}>OneStream URL*</label>
          </span>
          {getFormErrorMessage('url')}
        </div>

        {/* <div className="field m-2 mb-4">
          <span className="p-float-label">
            
            <InputText id="adapterName" name="adapterName"
              value={OneStreamForm.values.adapterName}
              onChange={(e) => { OneStreamForm.handleChange(e); }}
              className={classNames({ 'p-invalid': isFormFieldValid('adapterName') })} />
            <label htmlFor="adapterName" className={classNames({ 'p-error': isFormFieldValid('adapterName') })}>Adapter Name</label>
          </span>
          {getFormErrorMessage('adapterName')}
        </div> */}
        <div className="field m-2 mb-4">
          <span className="p-float-label">
            
            <InputText id="clientId" name="clientId"
              value={OneStreamForm.values.clientId}
              onChange={(e) => { OneStreamForm.handleChange(e); }}
              className={classNames({ 'p-invalid': isFormFieldValid('clientId') })} />
            <label htmlFor="clientId" className={classNames({ 'p-error': isFormFieldValid('clientId') })}>Client Id</label>
          </span>
          {getFormErrorMessage('clientId')}
        </div>
        <div className="field m-2 mb-4">
          <span className="p-float-label ">
           
            <InputText id="tenantId" name="tenantId"
              value={OneStreamForm.values.tenantId}
              onChange={(e) => { OneStreamForm.handleChange(e); }}
              className={classNames({ 'p-invalid': isFormFieldValid('tenantId') })} />
            <label htmlFor="tenantId" className={classNames({ 'p-error': isFormFieldValid('tenantId') })}>Tenant Id</label>
          </span>
          {getFormErrorMessage('tenantId')}
        </div>
        <div className="field m-2 mb-4">
          <span className="p-float-label">
            <Password id="secretKey" name="secretKey" 
                      value={OneStreamForm.values.secretKey}
                      onChange={(e) => { OneStreamForm.handleChange(e); }}
                      toggleMask className={classNames({ 'p-invalid': isFormFieldValid('secretKey') })} 
                      panelClassName="hidden" />
            <label htmlFor="secretKey" className={classNames({ 'p-error': isFormFieldValid('secretKey') })}>Secret Key</label>
          </span>
          {getFormErrorMessage('secretKey')}
        </div>
        <div className="field m-2 mt-3 mb-2">
        <Button type="submit" label="Submit" className="bg-primary" />
        </div>
      
      </form>
    </div>
  )
}

export default OneStreamConfig;