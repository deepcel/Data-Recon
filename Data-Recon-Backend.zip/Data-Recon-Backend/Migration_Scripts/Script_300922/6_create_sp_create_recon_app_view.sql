create or replace procedure fileservice.sp_create_recon_app_view(
	in recon_id integer
)
language 'plpgsql'
as $body$
declare 
var_recon_id integer := recon_id;
s_schema_name text := 'fileservice';
var_recon_name text := '';
var_view text := 'view_';

var_app1_id integer := 0;
var_app1_script text := '';
var_app1_table text := '';

var_app2_id integer := 0;
var_app2_script text := '';
var_app2_table text := '';

var_view_script text := 'Create or replace view '||s_schema_name||'.';
var_view_dim text[];
v_dim_name text := '';

begin 
	
	
	/*
	 * if active get the individual application id that belong to the recon id
	 * 
	 */
	if
		exists (select 1 from fileservice.recon r where r.recon_id=var_recon_id and r.is_deleted=false)
		then
			select r.app1_id, r.app2_id, r."name" , concat('app_',app1_id,'_',r."name") as app1_table, concat('app_',app2_id,'_',r."name") as app2_table
			into var_app1_id, var_app2_id, var_recon_name, var_app1_table, var_app2_table
			from fileservice.recon r 
			where r.recon_id = var_recon_id
			and r.is_deleted = false;
		else
			call fileService.sp_log_entry(
				null::integer, 
				'''ERROR: Recon id '|| var_recon_id ||' does not exist''', 
				var_recon_id, 
				null::text
			);
			return;
	end if;
	var_view = var_view||var_recon_name;
	
--	raise notice 'app ids are % and %', var_app1_id, var_app2_id;
	/*
	 * get the dimension combinations between the two applications
	 */
	select concat('select app_id, ',string_agg(app1,','),', file_name as "file name"') as app1, concat('select app_id, ',string_agg(app2,','),', file_name as "file name"') as app2
	into var_app1_script, var_app2_script
	from (
		select 
			concat(app1,' as "',dim_name,'"') as app1,
			concat(app2,' as "',dim_name,'"') as app2
		from (
			select
				rd1.dimension as app1, rd2.dimension as app2, concat(rd1.dimension,'-' ,rd2.dimension) as dim_name 
			from
				fileservice.recon_dimensions rd1
				full outer join	fileservice.recon_dimensions rd2
				on rd1.turn_on_define_order  = rd2.turn_on_define_order  
				and rd2.recon_app_id = var_app2_id
			where
				rd1.recon_app_id = var_app1_id
			order by rd1.dimensions_id 
		) q1
	)q2;
	
	
	var_app1_script = var_app1_script ||' from '||s_schema_name||'.'||var_app1_table;
	var_app2_script = var_app2_script ||' from '||s_schema_name||'.'||var_app2_table;

	var_view_script = var_view_script || var_view || ' as (';
	var_view_script = var_view_script || var_app1_script ||' union all '||var_app2_script||');';

--	raise notice '%',var_view_script;
	execute var_view_script;
--	 Log Script
	call fileService.sp_log_entry(
								null::integer,
								'''View '|| var_view || ' created'''::text,
								var_recon_id::integer,
								var_view::text
								);
	
	
	
	
end;
$body$
