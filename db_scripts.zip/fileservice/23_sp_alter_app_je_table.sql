DROP PROCEDURE if exists sp_alter_app_je_table(integer,character varying,character varying);
CREATE OR REPLACE PROCEDURE fileservice.sp_alter_app_je_table(recon_app_id integer, new_column varchar, old_column varchar default '')
 LANGUAGE plpgsql
AS $procedure$
declare
	var_app_id integer := recon_app_id;
	var_old_col varchar := old_column;
	var_new_col varchar := new_column;
	var_table_name_app RECORD;
	var_table_name_je RECORD;
	var_script_app varchar := '';
	var_script_je varchar := '';
	var_update boolean := false;
	var_default varchar := '';
	s_schema_name varchar := 'fileservice';
begin
--	raise notice '%', var_old_col;
--	raise notice '%', var_new_col;
/*
 * Check if the application exists. If yes, get the app details
 */
	if
		not exists(select 1 from fileservice.recon_applications ra where ra.recon_app_id=var_app_id)
		then 
			-- Log Script
			call fileService.sp_log_entry(
									var_app_id::integer,
									'''ERROR: Application does not exist'''::text
									);
			return;		
	end if;
	
	select *
	into var_table_name_app
	from f_check_get_app_details(var_app_id, false) as (table_name text, rec_id integer);

	select *
	into var_table_name_je
	from f_check_get_app_details(var_app_id, true) as (table_name text, rec_id integer);

--	raise notice '%', var_table_name_je;

	if var_old_col = ''
	then
		var_script_app = 'alter table if exists '||s_schema_name||'.'||var_table_name_app.table_name||' add column if not exists "'||var_new_col||'" character varying';
		var_script_je = 'alter table if exists '||s_schema_name||'.'||var_table_name_je.table_name||' add column if not exists "'||var_new_col||'" character varying';
	
--		raise notice '%', var_script_app;
--		raise notice '%', var_script_je;
	else
	/*
	 * Need to check if the old_column exists on the table
	 */
		var_script_app = 'alter table if exists '||s_schema_name||'.'||var_table_name_app.table_name||' rename column "'||var_old_col||'" to "'||var_new_col||'"';
		var_script_je = 'alter table if exists '||s_schema_name||'.'||var_table_name_je.table_name||' rename column "'||var_old_col||'" to "'||var_new_col||'"';
	
--		raise notice '%', var_script_app;
--		raise notice '%', var_script_je;
	end if;

-- Execute alter app table script
	begin
		execute var_script_app;
		--catch exception
		exception
			when sqlstate '42703' then
			raise exception 'Column ''%'' does not exist in app table',var_old_col;
	end;

	/*
	 * Check if dimension is present in file
	 */
	select rd.dim_in_file::boolean, rd.top_member 
	into var_update, var_default
	from fileservice.recon_dimensions rd 
	where not rd.is_deleted 
	and rd.is_active 
	and rd.recon_app_id = var_app_id
	and lower(rd.dimension) = lower(var_new_col);

--	raise notice '%====%',var_update, var_default;
	
	/*
	 * If dimension is present in file update app table
	 */
	if var_update
		then
--			raise notice 'In app update';
			if exists(select 1 from information_schema.tables where table_schema=s_schema_name and table_name=var_table_name_app.table_name)
				then
					var_script_app = 'update '||s_schema_name||'.'||var_table_name_app.table_name||' set '||var_new_col||'='||var_default;
					execute var_script_app;
			end if;		
	end if;
	
	/*
	 * Log final load status
	 */
	call fileservice.sp_log_entry(
	var_app_id, 
	'''App table altered''', 
	var_table_name_app.rec_id, 
	var_table_name_app.table_name
	); 

-- Execute alter je table script
	begin
		execute var_script_je;
		--catch exception
		exception
			when sqlstate '42703' then
			raise exception 'Column ''%'' does not exist in je table',var_old_col;
	end;

	/*
	 * If dimension is present in file update je table
	 */
	if var_update
		then
--			raise notice 'In je update';
			if exists(select 1 from information_schema.tables where table_schema=s_schema_name and table_name=var_table_name_je.table_name)
				then
					var_script_app = 'update '||s_schema_name||'.'||var_table_name_je.table_name||' set '||var_new_col||'='||var_default;
					execute var_script_app;
			end if;		
	end if;
	/*
	 * Log final load status
	 */
	call fileservice.sp_log_entry(
	var_app_id, 
	'''Je table altered''', 
	var_table_name_app.rec_id, 
	var_table_name_app.table_name
	); 
end
$procedure$
;

-- Permissions
ALTER PROCEDURE fileservice.sp_alter_app_je_table(int4, varchar, varchar) OWNER TO "user_dataRecon_file";
GRANT ALL ON PROCEDURE fileservice.sp_alter_app_je_table(int4, varchar, varchar) TO public;
GRANT ALL ON PROCEDURE fileservice.sp_alter_app_je_table(int4, varchar, varchar) TO postgres;
GRANT ALL ON PROCEDURE fileservice.sp_alter_app_je_table(int4, varchar, varchar) TO "user_dataRecon_file";
