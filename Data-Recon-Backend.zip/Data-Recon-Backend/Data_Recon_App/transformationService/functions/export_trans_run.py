import io
import csv
from ... utils.get_recon import get_recon
from .get_sync_view import get_sync_view


'''
<!---------- Method to get the transformation run data from db
             and return as file data for download ----------!>
'''


def export_trans_run(recon_id):
    recon_data = get_recon(recon_id)
    app1_id = recon_data['app1_id']
    app2_id = recon_data['app2_id']

    # Getting both apps data
    view_query = 'SELECT * FROM fileService.bridgesync_' + str(recon_id)
    trans_run_data = get_sync_view(view_query, app1_id, app2_id)

    # Creating a file object without saving
    csv_file = io.StringIO()
    header = trans_run_data['headers']
    csv_writer = csv.DictWriter(csv_file, fieldnames=header)
    csv_writer.writeheader()

    for i in range(0, len(trans_run_data['rows'])):
        # Creating the row object
        row = dict()

        # Looping headers and adding in object
        for head in header:
            if head == 'Comments':
                comment_data = list(filter(None, trans_run_data['rows'][i][head]))
                if comment_data:
                    trans_run_data['rows'][i][head] = "-".join(comment_data)
                else:
                    trans_run_data['rows'][i][head] = None

            row[head] = trans_run_data['rows'][i][head]

        # Writing to file object
        csv_writer.writerow(row)

    return csv_file
