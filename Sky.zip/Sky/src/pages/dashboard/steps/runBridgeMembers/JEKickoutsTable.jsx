import React, { useState } from "react";
import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useDispatch, useSelector } from "react-redux";
import "./runBridgeMembers.scss";
import {
  downloadUnMappedKickoutFile,
  updateUnMappedBridgeJE,
} from "../../../../store/sliceReducers/RunBridgeReducer";
import { toast } from "react-toastify";
import { InputText } from 'primereact/inputtext';
import { Button } from "primereact/button";
//import { FilterMatchMode, FilterOperator } from 'primereact/api';
import 'primeicons/primeicons.css';
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';
const JEKickoutsTable = () => {
  const dispatch = useDispatch();
  const [editingRows, setEditingRows] = useState({});
  const [filters2, setFilters2] = useState(null);
  const [globalFilterValue2, setGlobalFilterValue2] = useState('');
  const authData = useSelector((state) => state.auth);
  let { data } = authData.data;
  const AccessType = data.access_type.privilege === 0 ? true : false;

  const selectedReconId = useSelector(state =>
    state.reconRun.selectedReconRunId
  );

  const runBridge = useSelector(state =>
    state.runbridge.runBridge
  );


  const unMappedRowEditValidator = (rowData) => {
    if (!rowData['app1_app2']) {
      toast.error("Please select the appType");
      return false;
    }
    else if (!rowData['source_member']) {
      toast.error("Please enter the source member");
      return false;
    }
    else if (!rowData['bridge_member']) {
      toast.error("Please enter the bridge members");
      return false;
    }
    return true;
  }

  const unMappedJERowEditComplete = (e) => {
    let { newData } = e;
    dispatch(updateUnMappedBridgeJE(
      {
        recon_id: selectedReconId,
        rows: [{
          out_id: newData.out_id,
          app1_app2: newData.app1_app2,
          source_member: newData.source_member,
          bridge_member: newData.bridge_member
        }]
      }));
  }

  const downloadUnMappedKickoutJE = () => {
    dispatch(downloadUnMappedKickoutFile({
      "recon_id": selectedReconId,
      "je_flag": true,
    }));
  }

  const onGlobalFilterChange2 = (e) => {
    const value = e.target.value;
    let _filters2 = { ...filters2 };
    _filters2['global'].value = value;

    setFilters2(_filters2);
    setGlobalFilterValue2(value);
  }

  const onRowEditChange = (e) => {
    if (AccessType === true) {
      setEditingRows(e.data)
    }
    else {
      return
    }
  }

  const textEditor = (options) => {
    return <InputText type="text" value={options.value} onChange={(e) => options.editorCallback(e.target.value)} className="w-full" />;
  }

  const renderHeader4 = () => {
    return (
      <div className="flex justify-content-end">
        {/* <Button type="button" icon="pi pi-filter-slash" label="Clear" className="p-button-outlined" onClick={clearFilter2} /> */}
        <span className="p-input-icon-left">
          <i className="pi pi-search" />
          <InputText value={globalFilterValue2} onChange={onGlobalFilterChange2} placeholder="Search" />
        </span>
        <Button icon="pi pi-download" onClick={downloadUnMappedKickoutJE} disabled={!AccessType}
          className="p-button-rounded  mx-1 bg-primary" title="Download Unmapped kick outs" />

      </div>
    )
  }

  const header4 = renderHeader4();
  return (
    <>
      <DataTable value={runBridge.unMappedJE}
        id="unMappedTable"
        editMode="row"
        editingRows={editingRows}
        onRowEditChange={onRowEditChange}
        rowEditValidator={unMappedRowEditValidator}
        onRowEditComplete={unMappedJERowEditComplete}
        dataKey="out_id"
        showGridlines
        removableSort
        sortMode="multiple"
        paginator
        filterDisplay="menu"
        globalFilterFields={['app1_app2', 'source_member', 'bridge_member']}
        header={header4}
        filters={filters2}
        scrollHeight="500px"
        paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
        currentPageReportTemplate="Showing {first} to {last} of {totalRecords}"
        rows={10}
        rowsPerPageOptions={[10, 20, 50]}>
        <Column style={{ width: '15%' }} field="app1_app2" header="App Type" sortable filter editor={(options) => textEditor(options)}></Column>
        <Column style={{ width: '20%' }} field="source_member" header="Source Member" sortable filter editor={(options) => textEditor(options)}></Column>
        <Column style={{ width: '20%' }} field="bridge_member" header="Bridge Member" sortable filter editor={(options) => textEditor(options)}></Column>
        <Column style={{ width: '10%' }} rowEditor header="Edit"></Column>
      </DataTable>
    </>
  )
}
export default JEKickoutsTable;