import React, { useState, useEffect } from 'react';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { Password } from 'primereact/password';
import { useDispatch } from "react-redux";
import { useStore } from "react-redux";
import { useNavigate } from "react-router-dom";
import { registerUserDetails } from '../../../store/sliceReducers/AuthReducer';
import Footer from '../../../components/footer/Footer';
import { Grid } from '@mui/material';
import './register.scss';

const Register = () => {
    const [email, setEmail] = useState("");
    const [firstName, setfirstName] = useState("");
    const [lastName, setlastName] = useState("");
    const [password, setPassword] = useState("");
    const [retypepassword, setReTypePassword] = useState("");
    const dispatch = useDispatch();
    const store = useStore();
    const navigate = useNavigate();
    const [isFailed, setIsFailed] = useState({ error: null });

    useEffect(() => {
        // Fetch email value from query string and set it
        var params = new window.URLSearchParams(window.location.search);
        if (params && params.get('email')) {
            setEmail(params.get('email'))
        }
    }, []);

    const handleStateChange = () => {
        const authDetails = store.getState().auth;
        if (authDetails.error == null && !authDetails.loading) {
            // On successful sign up /register redirect to login page
            navigate("/");
        } else {
            // setIsLoggedIn(authDetails);
        }
    }

    const onSubmit = (e) => {
        e.preventDefault();
        var token = new window.URLSearchParams(window.location.search)?.get('token');
        if (validateForm() && token) {
            dispatch(registerUserDetails({
                email: email,
                firstName: firstName,
                lastName: lastName,
                password: password,
                token: token
            }, () => { handleStateChange() }, "User Registered Successfully"))
        }
    };

    const validateForm = () => {
        if (password === retypepassword && retypepassword.length > 5 && password.length > 5) {
            return true;
        }
        else {
            let errorMsg = password != retypepassword ? "Please re-enter the same password" : password.length < 6 || retypepassword.length < 6 ? "Password should contain more than 5 characters" : "Please re-enter the same password";
            setIsFailed({ message: errorMsg })
            return false;
        }
    }

    return (
        <React.Fragment>
            <div className="content grid grid-nogutter surface-section text-800">
                <div className="col-12 md:col-6 flex align align-items-center justify-content-center overflow-hidden">
                    <div className="surface-card m-4 p-4 shadow-2 border-round w-full lg:w-7">
                        <div className="text-center">
                            <div className="text-900 text-3xl font-medium mb-2">Complete Your Profile</div>
                        </div>
                        <form className="p-fluid" onSubmit={onSubmit}>
                            {isFailed.message != null &&
                                <Grid align='center'>
                                    <div className='errorMsg'>{isFailed.message}</div>
                                </Grid>
                            }<br></br>
                            <div className="field mb-3">
                                <span className="p-float-label p-input-icon-right">
                                    <InputText id="email"
                                        value={email}
                                        //as the user changes the input gets the text and set it the variable
                                        onChange={(e) => setEmail(e.target.value)}
                                        disabled="true"
                                    />
                                    <label htmlFor="email"
                                    >Email</label>
                                </span>
                            </div>
                            <div className="field mb-4">
                                <span className="p-float-label p-input-icon-right">
                                    <InputText id="firstname"
                                        value={firstName}
                                        onChange={(e) => setfirstName(e.target.value)}
                                        required
                                    />
                                    <label htmlFor="firstname"
                                    >First Name*</label>
                                </span>
                            </div>
                            <div className="field mb-4">
                                <span className="p-float-label p-input-icon-right">
                                    <InputText id="lastname"
                                        value={lastName}
                                        onChange={(e) => setlastName(e.target.value)}
                                    />
                                    <label htmlFor="lastname"
                                    >Last Name*</label>
                                </span>
                            </div>
                            <div className="field mb-4">
                                <span className="p-float-label">
                                    <Password id="password" name="password"
                                        toggleMask
                                        required
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                        panelClassName="hidden" />
                                    <label htmlFor="password"
                                    >Password*</label>
                                </span>
                                {password.length > 5 ? '' :
                                    <small id="password" className="block">Password should contain more than 5 characters</small>
                                }
                            </div>
                            <div className="field mb-4">
                                <span className="p-float-label">
                                    <Password id="retype-password" name="retype-password"
                                        toggleMask
                                        required
                                        value={retypepassword}
                                        onChange={(e) => setReTypePassword(e.target.value)}
                                        panelClassName="hidden" />
                                    <label htmlFor="retype-password"
                                    >Re-Type Password*</label>
                                </span>
                            </div>
                            <Button type="submit" label="Sign up" className="mt-2 bg-primary" />
                        </form>
                    </div>
                </div>
                <div className="col-12 md:col-6 overflow-hidden">
                    <img src="assets/images/register1.svg" alt="hero-1" className="md:ml-auto block md:h-full" style={{ clipPath: 'polygon(8% 0, 100% 0%, 100% 100%, 0 100%)', width: "82%", marginRight: "19px" }} />
                </div>
            </div>
            <Footer />
        </React.Fragment>
    )
}
export default Register