import React, { useState } from 'react';
import { useDispatch, useSelector } from "react-redux";
import { useFormik } from 'formik';
import { Password } from 'primereact/password';
import { classNames } from 'primereact/utils';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { getEmail } from '../../../../utils/utils';
import { directconnectLogin } from '../../../../store/sliceReducers/DirectConnectReducer';

function DirectLogin(props) {
  const [errMessage, setErrorMessage] = useState("");
  const dispatch = useDispatch();
  const AppType=props.apptype===1?"0":"1";
  // const [url, setUrl] = useState("");
  // const [username, setUsername] = useState("");
  // const [password, setPassword] = useState("");

  const email = getEmail();

  const selectedReconId = useSelector(state =>
    state.reconRun.selectedReconRunId
  );
  
  const loginForm = useFormik({
    initialValues: {
      url: '',
      username: '',
      password: '',
    },
    validate: (data) => {
      let errors = {};

      if (!data.url) {
        errors.url = 'Url is required.';
      }
      if (!data.username) {
        errors.username = 'Username is required.';
      }
      // else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(data.email)) {
      //   errors.email = 'Invalid email address. E.g. example@email.com';
      // }
      if (!data.password) {
        errors.password = 'Password is required.';
      }
      return errors;
    },
    onSubmit: (data) => {
      props.visiblity();
      dispatch(directconnectLogin({ 
        "recon_id": selectedReconId,
        "appType":AppType,
        "DC_Url": data.url, 
        "DC_Username": data.username, 
        "DC_Password": data.password, 
        "email": email 
    }));
      loginForm.resetForm();
      setErrorMessage("");
    },
  });

  const isFormFieldValid = (name) => !!(loginForm.touched[name] && loginForm.errors[name]);
  const getFormErrorMessage = (name) => {
    return isFormFieldValid(name) && <small className="p-error" style={{textAlign:'left'}}>{loginForm.errors[name]}</small>;
  };

  // const resetInputField = () => {
  //   setUrl("");
  //   setUsername("");
  //   setPassword("");
  // }

  return (
    <div style={{ width: "26vw", alignItems: 'center', textAlign: 'center' }}>
      <h3>Login to {props.connectOption}</h3>
      <form onSubmit={loginForm.handleSubmit}
        className="p-fluid" style={{ alignItems: 'center' }}>
        <div className="field" style={{textAlign:'left'}}>
          <span className="p-float-label">
            <InputText id="url" name="url"
              value={loginForm.values.url}
              onChange={(e) => { loginForm.handleChange(e); }}
              autoFocus className={classNames({ 'p-invalid': isFormFieldValid('url') })} />
            <label htmlFor="url" className={classNames({ 'p-error': isFormFieldValid('url') })}>URL*</label>
          </span>
          {getFormErrorMessage('url')}
        </div>
        
        <div className="field" style={{textAlign:'left'}}>
          <span className="p-float-label p-input-icon-right">
            <i className="pi pi-user" />
            <InputText id="username" name="username"
              value={loginForm.values.username}
              onChange={(e) => { loginForm.handleChange(e); }}
              className={classNames({ 'p-invalid': isFormFieldValid('username') })} />
            <label htmlFor="username" className={classNames({ 'p-error': isFormFieldValid('username') })}>Username*</label>
          </span>
          {getFormErrorMessage('username')}
        </div>

        <div className="field" style={{textAlign:'left'}}>
          <span className="p-float-label">
            <Password id="password" name="password" value={loginForm.values.password} onChange={(e) => { loginForm.handleChange(e); }}
              toggleMask className={classNames({ 'p-invalid': isFormFieldValid('password') })} panelClassName="hidden" />
            <label htmlFor="password" className={classNames({ 'p-error': isFormFieldValid('password') })}>Password*</label>
          </span>
          {getFormErrorMessage('password')}
        </div>
        <Button type="submit" label="Submit" className="mt-2  bg-primary" />
      </form>
    </div>
  )
}
export default DirectLogin;