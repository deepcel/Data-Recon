ALTER TABLE IF EXISTS fileservice.recon_dimensions
    ADD COLUMN is_active boolean;

ALTER TABLE IF EXISTS fileservice.recon_dimensions
ALTER COLUMN dim_in_file TYPE VARCHAR USING dim_in_file::VARCHAR;