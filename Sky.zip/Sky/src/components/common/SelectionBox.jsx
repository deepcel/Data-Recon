import React, { useState, useEffect } from "react";
import { MenuItem, Select } from "@material-ui/core";

const SelectionBox = (props) => {
  const [data, setData] = useState(props.data[0]);

  useEffect(() => {
    props.onValeChange(props.data[0]);
  }, []);

  const callfunc = (e) => {
    setData(e.target.value);
    props.onValeChange(e.target.value);
  };

  return (
    <div>
      <Select
        labelId="demo-simple-select-label"
        id="selectLabel"
        value={data}
        onChange={(e) => callfunc(e)}
      >
        {props.data.map((element, index) => (
          <MenuItem key={index} value={element}>
            {element}
          </MenuItem>
        ))}
      </Select>
    </div>
  );
};
export default SelectionBox;