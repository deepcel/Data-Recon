import React, { useState, useRef, useEffect } from "react";
import { makeStyles, withStyles } from "@material-ui/core/styles";
import { Panel } from 'primereact/panel';
import clsx from "clsx";
import Stepper from "@material-ui/core/Stepper";
import Step from "@material-ui/core/Step";
import StepLabel from "@material-ui/core/StepLabel";
import SettingsIcon from "@material-ui/icons/Settings";
import SupervisedUserCircleIcon from "@material-ui/icons/SupervisedUserCircle";
import StepConnector from "@material-ui/core/StepConnector";
import { Button } from 'primereact/button';
import ScheduleIcon from '@mui/icons-material/Schedule';
import SummarizeIcon from '@mui/icons-material/Summarize';
import FilterAltIcon from '@mui/icons-material/FilterAlt';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import "./Dashboard.scss";
import Select from "./steps/select/Select";
import DimensionLinking from "./steps/dimensionLinking/DimensionLinking";
import RunImport from "./steps/runImport/RunImport";
import BridgeMember from "./steps/bridgeMembers/BridgeMember";
import RunBridgeMember from "./steps/runBridgeMembers/RunBridgeMember";
import Transformation from "./steps/transformation/Transformation";
import RunTransformationSync from "./steps/runTransformation/Runtransformation";
import RunReport from "./steps/runReport/RunReport";
import { updateReconRun } from "../../store/sliceReducers/ReconRunReducer";
import { fieldEditStatus } from "../../store/sliceReducers/DimFieldReducer";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";

const ColorlibConnector = withStyles({
  alternativeLabel: {
    top: 22
  },
  active: {
    "& $line": {
      backgroundImage:
        "linear-gradient(265deg, rgba(30,111,154,1) 0%, rgba(66,134,169,1) 100%)"
    }
  },
  completed: {
    "& $line": {
      backgroundImage:
        "linear-gradient(0deg, rgba(245,67,67,1) 0%, rgba(38,243,50,1) 100%);"
    }
  },
  line: {
    height: 3,
    border: 0,
    backgroundColor: "#eaeaf0",
    borderRadius: 1
  }
})(StepConnector);

const useColorlibStepIconStyles = makeStyles({
  root: {
    backgroundColor: "#ccc",
    zIndex: 1,
    color: "#fff",
    width: 50,
    height: 50,
    display: "flex",
    borderRadius: "50%",
    justifyContent: "center",
    alignItems: "center"
  },
  active: {
    background: "#333366",
    // backgroundImage:
    //   "radial-gradient(circle, rgba(161,202,58) 0%, rgba(161,202,58) 47%, rgba(161,202,58) 100%)",
    boxShadow: "0 4px 10px 0 rgba(0,0,0,.25)"
  },
  completed: {
    backgroundImage:
      "linear-gradient(-145deg, rgba(30,111,154,1) 0%, rgba(243,149,38,1) 100%)"
  }
});

function ColorlibStepIcon(props) {
  const classes = useColorlibStepIconStyles();
  const { active, completed } = props;

  const icons = {
    1: <SettingsIcon />,
    2: <SupervisedUserCircleIcon />,
    3: <CloudUploadIcon />,
    4: <SummarizeIcon />,
    5: <ScheduleIcon />,
    6: <FilterAltIcon />,
    7: <SummarizeIcon />,
    8: <ScheduleIcon />
  };


  return (
    <div className={clsx(classes.root, {
      [classes.active]: active,
      [classes.completed]: completed
    })}>
      {icons[String(props.icon)]}
    </div>
  );
}

const useStyles = makeStyles(theme => ({
  root: {
    width: "100%"
  },
  button: {
    marginRight: theme.spacing(1)
  },
  instructions: {
    marginTop: theme.spacing(.3),
    marginBottom: theme.spacing(.3)
  }
}));

const Dashboard = () => {
  const classes = useStyles();
  const dispatch = useDispatch();
  const stepHeaderRef = useRef(null);
  const scrollToStepHeader = () => stepHeaderRef.current.scrollIntoView();

  const dimlinkInitValues = {
    app1_delimiter: "",
    app2_delimiter: "",
    variance_threshold: ""
  }



  //Get dashboard appdata from store
  const appDataList = useSelector(state =>
    state.reconRun.appData[0]
  );

  const selectedReconId = useSelector(state =>
    state.reconRun.selectedReconRunId
  );

  const savedFields = useSelector(state =>
    state.dimField.reconDetails
  );
  const isEdited = useSelector(state =>
    state.dimField.isFieldEdit
  );

  const updatenext = () => {
    dispatch(updateReconRun());
  }
  const [dimensionlink, setDimensionLink] = useState(dimlinkInitValues)

  const [activeStep, setActiveStep] = useState(0);

  const steps = ["Select", "Dimension Linking", "Run Import", "BridgeMembers", "Run Bridge", "Transformation", "Run Transformation", "Run Report"];
  // steps next

  const requiredValidation = () => {
    let isValid = false;
    for (var i = 0; i < appDataList.length; i++) {
      if (appDataList[i].recon_id == selectedReconId) {
        if ((appDataList[i].name == null) && (appDataList[i].app1_delimiter == null) && (appDataList[i].app2_delimiter == null) && (appDataList[i].variance_threshold == null)) {
          isValid = true;
        }
      }
    }
    return isValid;
  }

  const handleNext = (e) => {
    e.preventDefault();
    //dim link
    if (activeStep === 1) {
      const isValid = requiredValidation();
      if (isValid) {
        if (isEdited) {
          dispatch(fieldEditStatus());
          setUpdateReconRunFlag(true);
        } else {
          toast.error("Please select reconrun and enter app1 and app2 delimiter and variance threshold required fields");
          return;
          // if (!reconname) {
          //   toast.error("Please select a reconrun.");
          //   return;
          // }

          // if (!delimiter1) {
          //   toast.error("Please enter an app1 delimiter.");
          //   return;
          // }

          // if (!delimiter2) {
          //   toast.error("Please enter an app2 delimiter.");
          //   return;
          // }

          // if (!varianceThreshold) {
          //   toast.error("Please enter a variance threshold.");
          //   return;
          // }
        }
      }
    }
    setActiveStep(prevActiveStep => prevActiveStep + 1);
  };

  const [updateReconRunFlag, setUpdateReconRunFlag] = useState(false);

  useEffect(() => {
    if (updateReconRunFlag) {
      dispatch(updateReconRun(savedFields));
      setUpdateReconRunFlag(false);
    }
  }, [updateReconRunFlag, savedFields]);

  const handleBack = (e) => {
    e.preventDefault();
    setActiveStep(prevActiveStep => prevActiveStep - 1);
  };


  // const stepNavigate = (e) => {
  //   var a = Number(e.currentTarget.getAttribute('data-active-id'))
  //   if (isEdited && activeStep === 1) {
  //     dispatch(updateReconRun(savedFields))
  //   }
  //   if (activeStep === 1) {
  //     if (a != 0) {
  //       const isValid = requiredValidation();
  //       if ((isValid == true) && (isEdited)) {
  //         dispatch(fieldEditStatus());
  //         toast.error("Please enter app1 and app2 delimiter and variance threshold required fields");
  //         return;
  //       }
  //     }
  //   }
  //   setActiveStepWizard(Number(e.currentTarget.getAttribute('data-active-id')));
  // }

  const requiredValidations = () => {
    let isValid = false;
    for (var i = 0; i < appDataList.length; i++) {
      if (appDataList[i].recon_id == selectedReconId) {
        if (appDataList[i].name == null && appDataList[i].app1_delimiter == null && appDataList[i].app2_delimiter == null && appDataList[i].variance_threshold == null) {
          isValid = true; // exit loop early since validation has failed for this recon_id
        }
      }
    }
    return isValid;
  }

  // const stepNavigate = (e) => {
  //   console.log('stepNavigate called'); // add this line to log when the function is called
  //   const a = Number(e.currentTarget.getAttribute('data-active-id'));

  //   // Check if required fields are filled in when navigating to the next step
  //   if (activeStep === 1) {
  //     if (a !== 0) {
  //       const isValid = requiredValidations();
  //       if (isValid && isEdited) {
  //         dispatch(fieldEditStatus());
  //         toast.error("Please enter app1 and app2 delimiter and variance threshold required fields");
  //         return;
  //       } else if (isValid && activeStep === 1 && a !== 1) {
  //         dispatch(updateReconRun(savedFields));
  //       }
  //     }
  //   }
  //   setActiveStepWizard(a);
  // }

  const stepNavigate = (e) => {
    // add this line to log when the function is called
    const a = Number(e.currentTarget.getAttribute('data-active-id'));

    // If the user is moving from step 1 to step 2
    if (activeStep === 1 && a !== 0) {
      const reconname = savedFields.name;
      const delimiter1 = savedFields.app1_delimiter;
      const delimiter2 = savedFields.app2_delimiter;
      const varianceThreshold = savedFields.variance_threshold;

      // If required fields are not filled in, show an error message
      // if (!reconname || !delimiter1 || !delimiter2 || !varianceThreshold) {
      //   toast.error("Please select reconrun and enter app1 and app2 delimiter and variance threshold required fields");
      //   return;
      // }

      if (!reconname) {
        toast.error("Please select a reconrun name.");
        return;
      }

      if (!delimiter1) {
        toast.error("Please enter an app1 delimiter.");
        return;
      }

      if (!delimiter2) {
        toast.error("Please enter an app2 delimiter.");
        return;
      }

      if (!varianceThreshold) {
        toast.error("Please enter a variance threshold.");
        return;
      }

      // Update the isEdited state to indicate that the fields have been edited
      dispatch(fieldEditStatus());
    }

    // Call updateReconRun action if valid and navigating to a new step
    if (a !== activeStep) {
      const isValid = requiredValidations();
      if (isValid) {
        dispatch(updateReconRun(savedFields));
      }
    }

    setActiveStepWizard(a);
  }

  const setActiveStepWizard = (id) => {
    setActiveStep(id);
  }

  return (
    <>
      <div style={{
        margin: '0', top: '0',
        position: 'sticky',
        width: '100%', zIndex: '100'
      }}>

        <Stepper alternativeLabel activeStep={activeStep} connector={<ColorlibConnector />}>
          {
            steps.map((label, index) => (
              <Step key={label}>
                <StepLabel StepIconComponent={ColorlibStepIcon} data-active-id={index} onClick={stepNavigate}>{label}</StepLabel>
              </Step>
            ))}
        </Stepper>

      </div>
      <div className={classes.root} >
        {
          <React.Fragment>
            <div className={classes.instructions + " stepContent mx-6"}
              variant="h2">
              {
                (() => {
                  switch (activeStep) {
                    case 0:
                      return (<Select setActiveStepWizard={setActiveStepWizard} />);
                    case 1:
                      return (<DimensionLinking />);
                    case 2:
                      return (<RunImport />);
                    case 3:
                      return (<BridgeMember />);
                    case 4:
                      return (<RunBridgeMember />);
                    case 5:
                      return (<Transformation />);
                    case 6:
                      return (<RunTransformationSync />);
                    case 7:
                      return (<RunReport />);
                    default:
                      return "Unknown step";
                  }
                })()
              }
            </div>
            <div className="m-5">
              {
                activeStep !== 0 && <Button variant="contained" color="primary" disabled={activeStep === 0} onClick={handleBack} className={classes.button + " bg-primary"}>
                  Back </Button>
              }
              <Button
                variant="contained" color="primary"
                onClick={handleNext}
                disabled={(activeStep === steps.length - 1) ? true : false}
                className={classes.button + " bg-primary"}
                style={{ float: "right" }}> Next </Button>
              <br />
            </div>
            <br />
          </React.Fragment>
        }
      </div >
    </>
  );
}
export default Dashboard;