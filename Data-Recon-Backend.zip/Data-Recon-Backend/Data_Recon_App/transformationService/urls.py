from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from . import views


urlpatterns = [
    path('list/<int:recon_id>', views.get_transformation, name='get_transformation'),
    path('update', views.update_transformation, name='update_transformation'),
    path('run', views.run_transformation, name='run_transformation'),
    path('run/export/<int:recon_id>', views.run_trans_export, name='run_trans_export'),
    path('sync/combinations/<int:recon_id>', views.get_sync_combinations, name='get_sync_combinations'),
    path('sync/update', views.update_sync_mappings, name='update_sync_mappings'),
    path('sync/list/<int:recon_id>', views.get_tfn_sync, name='get_tfn_sync'),
    path('sync/export', views.sync_export, name='sync_export'),
    path('sync/import', views.import_sync, name='import_sync'),
    path('sync/delete', views.delete_sync, name='delete_sync'),
]

urlpatterns = format_suffix_patterns(urlpatterns)
