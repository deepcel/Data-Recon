import React, { useState, useRef } from "react";
import { toast } from "react-toastify";
import { useDispatch, useSelector } from "react-redux";
import { FileUpload } from 'primereact/fileupload';
import { Button } from "primereact/button";
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';
import "./runImport.scss";
import { JEsourceDataImport} from "../../../../store/sliceReducers/RunImportReducer";
import { getExtension, chooseOptions,uploadOptions,cancelOptions } from "../../../../utils/fileutils";
const JEFileImport= () => {
    const dispatch = useDispatch();
    const authData = useSelector((state) => state.auth);
    let { data } = authData.data;
    const AccessType = data.access_type.privilege === 0 ? true : false;   
    const fileUploadRef1 = useRef(null);
    const fileUploadRef2 = useRef(null);
    const [totalSizeApp1JE, setTotalSizeApp1JE] = useState(0);
    const [totalSizeApp2JE, setTotalSizeApp2JE] = useState(0);


  const selectedReconId = useSelector(state =>
    state.reconRun.selectedReconRunId
  );

  const onTemplateRemoveApp1JE = (file, callback) => {
    setTotalSizeApp1JE(totalSizeApp1JE - file.size);
    callback();
  };
  const onTemplateRemoveApp2JE = (file, callback) => {
    setTotalSizeApp2JE(totalSizeApp2JE - file.size);
    callback();
  };

  const itemTemplateApp1JE = (file, props) => {
    return (
      <div className="flex justify-content-between ">
        <div className="flex align-items-center" style={{ width: "40%" }}>
          <span className="flex flex-column text-left ml-3">{file.name}</span>
        </div>
        <Button
          icon="pi pi-times"
          className="p-button-secondary"
          onClick={() => onTemplateRemoveApp1JE(file, props.onRemove)}
        />
      </div>
    );
  };

  const itemTemplateApp2JE = (file, props) => {
    return (
      <div className="flex justify-content-between ">
        <div className="flex align-items-center" style={{ width: "40%" }}>
          <span className="flex flex-column text-left ml-3">{file.name}</span>
        </div>
        <Button
          icon="pi pi-times"
          className="p-button-secondary"
          onClick={() => onTemplateRemoveApp2JE(file, props.onRemove)}
        />
      </div>
    );
  };

  const JEapp1FileUpload = ({ files }) => {
    fileUploadJE(files, 0);
  };

  const JEapp2FileUpload = ({ files }) => {
    fileUploadJE(files, 1);
  };

  

  // const fileUploadJE = (files, appType) => {
  //     const supportedFileFormat = ["csv", "txt"];
  //     const file = files;
  //     if (file) {
  //         if (!supportedFileFormat.includes(getExtension(file.name))) {
  //             toast.error("Unsupported file format, Please upload valid files(.csv,.txt)");
  //             return;
  //         }
  //     }
  //     const fileReader = new FileReader();
  //     fileReader.onload = (e) => {
  //         let formData = new FormData();
  //         formData.append('source_file', file);
  //         formData.append('recon_id', selectedReconId);
  //         formData.append('app_type', appType);
  //         formData.append('max_rows', 100);
  //         formData.append('page_number', 1);
  //         dispatch(JEsourceDataImport(formData, appType));
  //     };
  //     fileReader.readAsDataURL(file);
  // }

  //multifile upload je
  const fileUploadJE = (files, appType) => {
    const supportedFileFormat = ["csv", "txt"];
    for (let file of files) {
      if (!supportedFileFormat.includes(getExtension(file.name))) {
        toast.error("Unsupported file format, Please upload valid files(.csv,.txt)");
        return;
      }
    }
    let formData = new FormData();
    let fileReaders = [];
    let a = 0;
    files.forEach((file, index) => {
      const fileReader = new FileReader();
      fileReaders.push(
        new Promise((resolve, reject) => {
          fileReader.onload = (e) => {
            formData.append(`source_file[${index}]`, file);
            resolve();
          };
          fileReader.onerror = reject;
          fileReader.readAsArrayBuffer(file);
          a++;
        })
      );
    });
    Promise.all(fileReaders)
      .then(() => {
        formData.append('num_files', a);
        formData.append('recon_id', selectedReconId);
        formData.append('app_type', appType);
        formData.append('max_rows', 100);
        formData.append('page_number', 1);
        formData.append('je', true);
        dispatch(JEsourceDataImport(formData, appType));
        if(appType===0)
        {
          fileUploadRef1.current.clear();        
        }
        else
        {
          fileUploadRef2.current.clear();
        }
      })
      .catch(err => {
        // console.error(err);
      });
  };

  return (
    <>
      <div className="formgrid grid mb-2">
        <div className="col-6">
          <label htmlFor="app1FileUpload" className="mb-3">App1 JE FileUpload:</label>
          <span className="p-float-label p-input-icon-right w-full mt-2">
            <FileUpload
              accept=".csv, .txt"
              ref={fileUploadRef1}
              disabled={!AccessType}
              maxFileSize={500000000}
              // multiple                                        
              chooseOptions={chooseOptions}
              uploadOptions={uploadOptions}
              cancelOptions={cancelOptions}
              itemTemplate={itemTemplateApp1JE}
              customUpload
              uploadHandler={JEapp1FileUpload}
              emptyTemplate={<p className="m-0">Drag and drop files to here to upload.</p>}
            />
          </span>
        </div>
        <div className="col-6">
          <label htmlFor="app2FileUpload" className="mb-3">App2 JE FileUpload:</label>
          <span className="p-float-label mt-2">
            <FileUpload
              accept=".csv, .txt"
              ref={fileUploadRef2}
              disabled={!AccessType}
              maxFileSize={500000000}
              // multiple
              customUpload
              chooseOptions={chooseOptions}
              uploadOptions={uploadOptions}
              cancelOptions={cancelOptions}
              itemTemplate={itemTemplateApp2JE}
              uploadHandler={JEapp2FileUpload}
              emptyTemplate={<p className="m-0">Drag and drop files to here to upload.</p>}
            />
          </span>
        </div>
      </div>
    </>
  )
}
export default JEFileImport;