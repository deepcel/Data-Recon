import React, { useEffect, useState } from "react";
import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useDispatch, useSelector } from "react-redux";
import "./runBridgeMembers.scss";
import {
  downloadRunBridge,
} from "../../../../store/sliceReducers/RunBridgeReducer";
import { InputText } from 'primereact/inputtext';
import { Button } from "primereact/button";
import { FilterMatchMode, FilterOperator } from 'primereact/api';
import 'primeicons/primeicons.css';
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';

const RunBridgeTable = () => {

  const dispatch = useDispatch();
  const [filters2, setFilters2] = useState(null);
  const [globalFilterValue2, setGlobalFilterValue2] = useState('');

  const authData = useSelector((state) => state.auth);
  let { data } = authData.data;
  const AccessType = data.access_type.privilege === 0 ? true : false;

  const selectedReconId = useSelector(state =>
    state.reconRun.selectedReconRunId
  );

  const runBridge = useSelector(state =>
    state.runbridge.runBridge
  );


  const clearFilter2 = () => {
    initFilters2();
  }

  useEffect(() => {

    initFilters2();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const initFilters2 = () => {
    setFilters2({
      'global': { value: null, matchMode: FilterMatchMode.CONTAINS },
      'App1-App2': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Year-Years': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'YEAR-YEAR': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridge-YEAR-YEAR': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'PERIOD-PERIOD': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridge-PERIOD-PERIOD': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'ENTITY-ENTITY': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridge-ENTITY-ENTITY': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'VIEW-VIEW': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridge-VIEW-VIEW': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'ACCOUNT-ACCOUNT': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridge-ACCOUNT-ACCOUNT': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridge-Year-Years': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Period-Period': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridge-Period-Period': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Entity-Ent': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridge-Entity-Ent': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Value-Cons': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridge-Value-Cons': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Scenario-Scenario': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridge-Scenario-Scenario': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Account-ACCT': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridge-Account-ACCT': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Flows-Flow': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridge-Flows-Flow': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Dim8-Origin': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridge-Dim8-Origin': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'ICP-IC': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridge-ICP-IC': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'DataSource-U1': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridge-DataSource-U1C': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Segment-U2': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridge-Segment-U2': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Dim12-Function': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridge-Dim12-Function': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Dim13-U4': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridge-Dim13-U4': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Geography-U5': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridge-Geography-U5': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Customer-U6': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridge-Customer-U6': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Dim16-U7': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridge-Dim16-U7': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Census-Dim17': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridge-Census-Dim1': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Dim18-U8': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridge-Dim18-U8': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'View-View': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'bridge-View-View': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Initial Amount': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Amounts with Sign Flips & App2 Reversals': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'Comments': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
    });
    setGlobalFilterValue2('');
  }

  const onGlobalFilterChange2 = (e) => {
    const value = e.target.value;
    let _filters2 = { ...filters2 };
    _filters2['global'].value = value;

    setFilters2(_filters2);
    setGlobalFilterValue2(value);
  }

  const dynamicColumns = runBridge.headers?.map((col, i) => {
    return <Column field={col} style={{ "width": "13%" }} header={<div>{col}</div>} sortable filter />;
  });

  const downloadnormalRunBridge = () => {
    dispatch(downloadRunBridge(
      {
        "recon_id": selectedReconId,
        "je_flag": false
      }));
  }

  const renderHeader2 = () => {
    return (
      <div className="flex justify-content-end">
        <span className="p-input-icon-left">
          <i className="pi pi-search" />
          <InputText value={globalFilterValue2} onChange={onGlobalFilterChange2} placeholder="Search" />
        </span>
        <Button type="button"
          icon="pi pi-filter-slash"
          title="Clear"
          disabled={(selectedReconId === '' || !AccessType ? true : false)}
          className="p-button-rounded  ml-1 bg-primary"
          onClick={clearFilter2} />
        <Button icon="pi pi-download"
          disabled={!AccessType}
          onClick={downloadnormalRunBridge}
          className="p-button-rounded  mx-1 bg-primary" title="Download run bridge" />

      </div>
    )
  }

  const header2 = renderHeader2();
  return (
    <>
      <DataTable id="runBridgeTable" value={runBridge.rows}
        scrollable
        scrollDirection="both"
        showGridlines
        sortMode="multiple"
        removableSort
        filterDisplay="menu"
        dataKey="index"
        header={header2}
        filters={filters2}
        globalFilterFields={[
          'App1-App2',
          'Year-Years',
          'YEAR-YEAR',
          'bridge-YEAR-YEAR',
          'PERIOD-PERIOD',
          'bridge-PERIOD-PERIOD',
          'ENTITY-ENTITY',
          'bridge-ENTITY-ENTITY',
          'VIEW-VIEW',
          'bridge-VIEW-VIEW',
          'ACCOUNT-ACCOUNT',
          'bridge-ACCOUNT-ACCOUNT',
          'bridge-Year-Years',
          "Period-Period",
          "bridge-Period-Period",
          "Entity-Ent",
          "bridge-Entity-Ent",
          "Value-Cons",
          "bridge-Value-Cons",
          "Scenario-Scenario",
          "bridge-Scenario-Scenario",
          "Account-ACCT",
          "bridge-Account-ACCT",
          "Flows-Flow",
          "bridge-Flows-Flow",
          "Dim8-Origin",
          "bridge-Dim8-Origin",
          "ICP-IC",
          "bridge-ICP-IC",
          "DataSource-U1",
          "bridge-DataSource-U1",
          "Segment-U2",
          "bridge-Segment-U2",
          "Dim12-Function",
          "bridge-Dim12-Function",
          "Dim13-U4",
          "bridge-Dim13-U4",
          "Geography-U5",
          "bridge-Geography-U5",
          "Customer-U6",
          "bridge-Customer-U6",
          "Dim16-U7",
          "bridge-Dim16-U7",
          "Census-Dim17",
          "bridge-Census-Dim17",
          "Dim18-U8",
          "bridge-Dim18-U8",
          "View-View",
          "bridge-View-View",
          "Initial Amount",
          "Amounts with Sign Flips & App2 Reversals",
          "Comments"]}
        paginator
        scrollHeight="500px"
        paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
        currentPageReportTemplate="Showing {first} to {last} of {totalRecords}"
        rows={10}
        rowsPerPageOptions={[10, 20, 50]}>
        {dynamicColumns}
      </DataTable>
    </>
  )
}
export default RunBridgeTable;