CREATE TABLE "admin".django_content_type (
	id serial4 NOT NULL,
	app_label varchar(100) NOT NULL,
	model varchar(100) NOT NULL,
	CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model),
	CONSTRAINT django_content_type_pkey PRIMARY KEY (id)
);

-- Permissions

ALTER TABLE "admin".django_content_type OWNER TO "user_dataRecon_admin";
GRANT ALL ON TABLE "admin".django_content_type TO "user_dataRecon_admin";