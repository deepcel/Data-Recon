import React, { useEffect, useState } from "react";
import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useDispatch, useSelector } from "react-redux";
import { Button } from "primereact/button";
import "./transformation.scss";
import { MultiSelect } from 'primereact/multiselect';
import { InputText } from 'primereact/inputtext';
import {
    listDimension
} from '../../../../store/sliceReducers/BridgeMemberReducer';
import {
    listTransformation,
    updateTransformationMember,
    listTransformationSync,
    listtransformationSyncCombination,
} from "../../../../store/sliceReducers/TransformationReducer";
import { ConfirmPopup } from 'primereact/confirmpopup';
import { Dropdown } from 'primereact/dropdown';
import { FilterMatchMode, FilterOperator } from 'primereact/api';

const TransTable = (props) => {
    const dispatch = useDispatch();
    const [editingRows, setEditingRows] = useState({});
    const [transformationRows, setTransformationRows] = useState([]);
    const [globalFilterValue1, setGlobalFilterValue1] = useState('');
    const [filters1, setFilters1] = useState(null);

    const authData = useSelector((state) => state.auth);
    let { data } = authData.data;
    const AccessType = data.access_type.privilege === 0 ? true : false;
    const applyAllMemberSource = [
        { label: 'Select', value: 0 },
        { label: 'YES', value: 1 },
        { label: 'NO', value: 2 }
    ];

    //BULK DELETE

    const reconRunList = useSelector(state =>
        state.reconRun.appData[0]
    );

    const selectedReconId = useSelector(state =>
        state.reconRun.selectedReconRunId
    );

    const transformation = useSelector(state =>
        state.transform.transformation
    );

    const dimensions = useSelector(state =>
        state.bridgeMember.dimensions
    );

    useEffect(() => {
        if (!dimensions && (!dimensions.app1Dimension || !dimensions.app2Dimension)
            && selectedReconId) {
            dispatch(listDimension(selectedReconId));
            dispatch(listTransformation(selectedReconId));
            dispatch(listTransformationSync(selectedReconId));
            dispatch(listtransformationSyncCombination(selectedReconId));
        }
        if (transformation.rows && transformation.rows.length === 0) {
            let rows = [];
            for (let i = 0; i < dimensions.app1Dimension.length; i++) {
                rows.push({
                    "id": i,
                    "app1_dimension_id": dimensions.app1Dimension[i].dimensions_id,
                    "app1_concatenation": [],
                    "app1_apply_all_members": null,
                    "app2_dimension_id": dimensions.app2Dimension[i].dimensions_id,
                    "app2_concatenation": [],
                    "app2_apply_all_members": null
                })
            }
            setTransformationRows(rows);
        }
        else {
            let rows = [...transformation.rows];
            rows = rows.map((obj, index) => ({ ...obj, id: index }));
            setTransformationRows(rows);
        }
        initFilters1();
    }, [dimensions, transformation.rows])

    const clearFilter1 = () => {
        initFilters1();
    }

    const onGlobalFilterChange1 = (e) => {
        const value = e.target.value;
        let _filters1 = { ...filters1 };
        _filters1['global'].value = value;

        setFilters1(_filters1);
        setGlobalFilterValue1(value);
    }

    const initFilters1 = () => {
        setFilters1({
            'global': { value: null, matchMode: FilterMatchMode.CONTAINS },
            'app1_apply_all_members': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'app1_dimension_id': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'app1_concatenation': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'app2_apply_all_members': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'app2_dimension_id': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
            'app2_concatenation': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
        });
        setGlobalFilterValue1('');
    }

    const saveTransformation = () => {
        dispatch(updateTransformationMember(
            {
                recon_id: selectedReconId,
                rows: transformationRows,
                dimensions: transformationRows
            }));
    }


    const app1AllMembersTemplate = (rowData) => {
        return (
            rowData.app1_apply_all_members === 1 ? "YES" : rowData.app1_apply_all_members === 2 ? "NO" : ""
        )
    }

    const app2AllMembersTemplate = (rowData) => {
        return (
            rowData.app2_apply_all_members === 1 ? "YES" : rowData.app2_apply_all_members === 2 ? "NO" : ""
        )
    }
    const App1AllMemberDropDownEditor = (options) => {
        return (
            <React.Fragment>
                <Dropdown value={options.value} options={applyAllMemberSource} optionLabel="label" optionValue="value"
                    onChange={(e) => { options.editorCallback(e.value) }} placeholder="select" className="w-full" />
            </React.Fragment>
        );
    }
    const App2AllMemberDropDownEditor = (options) => {
        return (
            <React.Fragment>
                < Dropdown value={options.value} options={applyAllMemberSource} optionLabel="label" optionValue="value"
                    onChange={(e) => { options.editorCallback(e.value) }} placeholder="select" className="w-full" />
            </React.Fragment>
        );
    }
    const onRowEditChange = (e) => {
        if (AccessType === true) {
            setEditingRows(e.data)
        }
        else {
            return
        }
    }

    const getDimensionData = (dimensionList, dimId) => {
        if (!!dimId) {
            const index = dimensionList.findIndex(dim => String(dim.dimensions_id) === String(dimId));
            if (index === -1) {
                return dimId;
            }
            else {
                return dimensionList[index]?.dimension;
            }
        }
        else {
            return "--";
        }
    }
    // const transformationRowEditValidator = (rowData) => {
    //     if (!rowData.app1_apply_all_members) {
    //         toast.error("Please enter the app1 member.");
    //         return false;
    //     } else if (rowData.app1_concatenation.length === 0) {
    //         toast.error("Please enter the app1 concatenation.");
    //         return false;
    //     }
    //     if (!rowData.app2_apply_all_members) {
    //         toast.error("Please enter the app2 member.");
    //         return false;
    //     } else if (rowData.app2_concatenation.length === 0) {
    //         toast.error("Please enter the app2 concatenation.");
    //         return false;
    //     }
    //     return true;
    // }
    const app1DimensionTemplate = (rowData) => {

        return (
            getDimensionData(dimensions.app1Dimension, rowData.app1_dimension_id)
        );
    }
    const app2DimensionTemplate = (rowData) => {
        return (
            getDimensionData(dimensions.app2Dimension, rowData.app2_dimension_id)
        );
    }
    const app2ConcatinationTemplate = (rowData) => {
        let result = "";
        rowData.app2_concatenation?.forEach(element => {
            result += getDimensionData(dimensions.app2Dimension, element) + " - ";
        });
        return (
            result?.slice(0, -2)
        );
    };
    const app1DimensionDropdownEditor = (options) => {
        return (
            <Dropdown value={options.value}
                options={dimensions.app1Dimension}
                optionLabel="dimension" optionValue="dimensions_id"
                onChange={(e) => { options.editorCallback(e.value) }}
                placeholder="select" className="w-full"
                filter showClear filterBy="dimension" />
        );
    }
    const app2ConcatDropdownEditor = (options) => {
        return (
            <MultiSelect value={options.value?.map(Number)}
                options={dimensions.app2Dimension}
                optionLabel="dimension" optionValue="dimensions_id"
                onChange={(e) => { options.editorCallback(e.value) }}
                placeholder="select" className="w-full" filter showClear
                filterBy="dimension"
                maxSelectedLabels={2} required />
        )
    };
    const app2DimensionDropdownEditor = (options) => {
        return (
            <Dropdown value={options.value}
                options={dimensions.app2Dimension}
                optionLabel="dimension" optionValue="dimensions_id"
                onChange={(e) => { options.editorCallback(e.value) }}
                placeholder="select" className="w-full" filter showClear
                filterBy="dimension" />
        )
    }
    const transformationRowEditComplete = (e) => {
        let { newData } = e;
        let rowIndex = transformationRows.findIndex(row => row.id === newData.id)
        let newState = [...transformationRows];
        newState[rowIndex] = {
            id: newData.id,
            app1_apply_all_members: newData.app1_apply_all_members,
            app1_dimension_id: newData.app1_dimension_id,
            app1_concatenation: newData.app1_concatenation,
            app2_apply_all_members: newData.app2_apply_all_members,
            app2_dimension_id: newData.app2_dimension_id,
            app2_concatenation: newData.app2_concatenation,
        }
        setTransformationRows(newState);
    }
    const app1ConcatinationTemplate = (rowData) => {
        let result = "";
        rowData.app1_concatenation?.forEach(element => {
            result += getDimensionData(dimensions.app1Dimension, element) + " - ";
        })
        return (
            result?.slice(0, -2)
        );
    };
    //apply all concat dropdown
    const app1ConcatDropdownEditor = (options) => {
        return (
            <MultiSelect value={options.value?.map(Number)}
                options={dimensions.app1Dimension}
                optionLabel="dimension" optionValue="dimensions_id"
                onChange={(e) => { options.editorCallback(e.value) }}
                placeholder="select" className="w-full" filter showClear
                filterBy="dimension"
                maxSelectedLabels={2} required />
        )
    }
    const renderHeader1 = () => {
        return (
            <div className="flex justify-content-end">
                <span className="p-input-icon-left">
                    <i className="pi pi-search" />
                    <InputText value={globalFilterValue1}
                        onChange={onGlobalFilterChange1} placeholder="Search" />
                </span>

                <Button type="button"
                    icon="pi pi-filter-slash"
                    title="Clear"
                    disabled={(selectedReconId === '' || !AccessType ? true : false)}
                    className="p-button-rounded  ml-1 bg-primary"
                    onClick={clearFilter1} />
            </div>)
    }

    const header1 = renderHeader1();
    return (
        <>
            <div className="formgrid grid" style={{ marginTop: '-8px' }}>
                <div className="col-6">
                    Recon RunName: <span className="font-bold">{props.reconRunName} </span>
                </div>
                <div className="col-6 text-right">
                    <Button type="submit" label="Save Transformation"
                        icon="pi pi-save"
                        disabled={!AccessType}
                        className="p-button-success  mx-1 mb-2 bg-primary"
                        tooltipOptions={{ "position": "top" }} tooltip="Save Transformation Details"
                        onClick={saveTransformation} />
                </div>
            </div>

            <div className="formgrid">
                <ConfirmPopup />
                <DataTable id="transformationTable"
                    className=""
                    value={transformationRows}
                    editMode="row"
                    editingRows={editingRows}
                    // rowClassName={rowClass}
                    onRowEditChange={onRowEditChange}
                    // rowEditValidator={transformationRowEditValidator}
                    onRowEditComplete={transformationRowEditComplete}
                    dataKey="id"
                    showGridlines
                    sortMode="multiple"
                    scrollHeight="400px"
                    scrollable
                    scrollDirection="both"
                    paginator
                    filterDisplay="menu"
                    removableSort
                    globalFilterFields={['app1_apply_all_members', 'app1_dimension_id', 'app1_concatenation', 'app2_apply_all_members', 'app2_dimension_id', 'app2_concatenation']}
                    header={header1}
                    filters={filters1}
                    paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
                    currentPageReportTemplate="Showing {first} to {last} of {totalRecords}"
                    rows={10}
                    rowsPerPageOptions={[10, 20, 50]}>
                    <Column style={{ width: '18%' }} field="app1_apply_all_members"
                        header={<span className="transformationsync">App1 Apply All Members</span>}
                        body={app1AllMembersTemplate} editor={(options) => App1AllMemberDropDownEditor(options)} sortable filter ></Column>
                    <Column style={{ width: '15%' }} field="app1_dimension_id"
                        header={<span className="transformationsync">Dimension Name </span>} sortable filter
                        body={app1DimensionTemplate} editor={(options) => app1DimensionDropdownEditor(options)}></Column>
                    <Column style={{ width: '20%' }} field="app1_concatenation"
                        header={<span className="transformationsync">App1 Concatenation </span>}
                        sortable body={app1ConcatinationTemplate} editor={(options) => app1ConcatDropdownEditor(options)} filter required></Column>
                    <Column style={{ width: '18%' }} field="app2_apply_all_members"
                        body={app2AllMembersTemplate}
                        header={<span className="transformationsync">App2 Apply All Members </span>} editor={(options) => App2AllMemberDropDownEditor(options)} sortable filter ></Column>
                    <Column style={{ width: '15%' }} field="app2_dimension_id" header={<span className="transformationsync">Dimension Name </span>} sortable filter body={app2DimensionTemplate} editor={(options) => app2DimensionDropdownEditor(options)}></Column>
                    <Column style={{ width: '20%' }} field="app2_concatenation" header={<span className="transformationsync">App2 Concatenation </span>} sortable filter body={app2ConcatinationTemplate} editor={(options) => app2ConcatDropdownEditor(options)} required></Column>
                    <Column style={{ width: '13%' }} rowEditor header="Edit"></Column>
                </DataTable>
            </div>
        </>
    )
}
export default TransTable;