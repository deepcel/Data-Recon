from ... models import ReconTransformationOverride, ReconTransformation
from ..serializers import TransOverrideSerializer
from ...utils.get_recon import get_recon


'''
<!---------- Method to get transformations sync
             then structure and return response ----------!>
'''


def get_sync_data(recon_id, app_type):
    response_data = {
        'status': 200,
        'recon_id': recon_id,
        'app_id': None,
        'app_type': app_type,
        'rows': [],
        'message': 'Obtained all the transformation sync mappings!'
    }

    recon_data = get_recon(recon_id)
    app_id = recon_data['app1_id'] if app_type == '0' else recon_data['app2_id']
    response_data['app_id'] = app_id

    instance = ReconTransformationOverride.objects.filter(recon_id=recon_id, app_id=app_id)
    serialized = TransOverrideSerializer(instance, many=True)

    for sync in serialized.data:
        dimensions_id = get_dim_id(sync['tfn_id'])
        if dimensions_id:
            sync_object = {
                'sync_id': sync['id'],
                'tfn_id': sync['tfn_id'],
                'dimensions_id': dimensions_id,
                'source_sync': sync['source_sync'],
                'flip_sign': 'YES' if sync['flip_sign'] else 'NO',
                'target_sync': sync['target_sync']
            }
            response_data['rows'].append(sync_object)
        else:
            response_data = {
                'status': 6002,
                'message': 'Invalid transformation id!'
            }
            return response_data

    return response_data


def get_dim_id(tfn_id):
    dim_id = None
    if ReconTransformation.objects.filter(id=tfn_id).exists():
        tfn_instance = ReconTransformation.objects.filter(id=tfn_id)[0]
        dim_id = tfn_instance.dim_id
    return dim_id


def get_all_sync_data(recon_id, app_type):
    response_data = {
        'status': 200,
        'recon_id': recon_id,
        'rows': [],
        'message': 'Here is all sync_data'
    }

    recon_data = get_recon(recon_id)
    app_id = recon_data['app1_id'] if app_type == '0' else recon_data['app2_id']
    response_data['app_id'] = app_id

    instance = ReconTransformationOverride.objects.filter(recon_id=recon_id, app_id=app_id)
    serialized = TransOverrideSerializer(instance, many=True)

    for sync in serialized.data:
        dimensions_id = get_dim_id(sync['tfn_id'])
        if dimensions_id:
            sync_object = {
                'sync_id': sync['id'],
                'source_sync': sync['source_sync']
            }
            response_data['rows'].append(sync_object.get('source_sync'))

        else:
            response_data = {
                'status': 6002,
                'message': 'Invalid transformation id!'
            }
            return response_data

    return response_data