import React, { useEffect, useState } from "react";
import { Card } from 'primereact/card';
import { useSelector } from "react-redux";
import "./runImport.scss";
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';
import { Message } from 'primereact/message';
import IconButton from '@mui/material/IconButton';
import InfoIcon from '@mui/icons-material/Info';
import JEdatatable from "./JEdatatable";
import JEFileImport from "./JEfileImport";
import Sourcedatatable from "./SourceDatatable";
import SampleSourceTemplate from "./SampleSourceTemplate";
import SampleJETemplate from "./SampleJETemplate";
import App1SourceFile from "./App1SourceFile";
import App2SourceFile from "./App2SourceFile";

const RunImport = () => {

    const [reconRunName, setReconRunName] = useState("");
    const [ShowMessage, setShowMessage]= useState(false);

    const reconRunList = useSelector(state =>
        state.reconRun.appData[0]
    );
    const selectedReconId = useSelector(state =>
        state.reconRun.selectedReconRunId
    );
    const runImportData = useSelector(state =>
        state.runImport.runImportData
    );
   
    const app1_Import_type=useSelector(state =>
        state.dimField.reconDetails.app1_import_type
      );
    
    const app2_Import_type=useSelector(state =>
        state.dimField.reconDetails.app2_import_type
      );

    let showTemplate=((app1_Import_type==='0')||(app2_Import_type==='0'))?true :false;
    useEffect(() => {
        let filteredRecon = reconRunList.find(run => run.recon_id === selectedReconId)
        if (filteredRecon) {
            setReconRunName(filteredRecon.name)
        }
    },[]);

    const MessageContent = ()=>{
        return (
            <React.Fragment>
                 <span>Files delimited with (,), (;), (|) in .csv or .txt format accepted for import</span>
            </React.Fragment>
        )
    }
    
    return (
        <React.Fragment>
            <Card className="shadow-5">
                <div className="card pt-0">
                    {!reconRunName && <div className="text-center text-pink-500">
                        Please select recon and click run import tab
                    </div>}
                    {
                        !!reconRunName && <>
                          
                                <div className="formgrid grid mb-2"
                                     style={{marginTop:'-10px'}}>
                                    <div className="col-6">                                       
                                         Recon RunName: <span className="font-bold">{reconRunName} </span><br></br>
                                     </div>
                                     <div className="col-5 card flex justify-content-end mt-2">
                                        {ShowMessage &&  <Message text={MessageContent} style={{marginTop:'-28px'}}/>}                                            
                                     </div>                                   
                                     <div className="col-1 text-right">
                                     <IconButton aria-label="delete"
                                                 sx={{marginTop:'-10px', color:'#ef5350'}}
                                                 onClick={()=>setShowMessage(!ShowMessage)}>
                                                 <InfoIcon/>
                                     </IconButton>
                                     </div>
                                </div>
                                {showTemplate && <SampleSourceTemplate/>}
                                <div className="formgrid grid">
                                  <div className="col-6 mt-3 mb-3">
                                     <App1SourceFile/>
                                  </div>
                                  <div className="col-6 mt-3 mb-3">
                                     <App2SourceFile/>
                                  </div>
                               </div>
                                {
                                    !runImportData.rows && <div>
                                        Please upload a app1 & app2 file.
                                    </div>
                                }
                               <Sourcedatatable/>
                                <div className="card pt-0">
                                  <h2 style={{ textAlign: "center" }}>Journal Entry</h2>
                                   <SampleJETemplate/>
                                   <JEFileImport />
                                </div>
                                 <JEdatatable />
                               </>
                    }
                </div>
            </Card>
           
        </React.Fragment >
    )
}
export default RunImport;