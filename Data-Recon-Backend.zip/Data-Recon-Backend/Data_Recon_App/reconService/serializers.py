from rest_framework import serializers
from .. models import ReconApplications, Recon, ReconDimensions


class ReconAppSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReconApplications
        fields = ['recon_app_id', 'recon_id', 'app_name', 'import_type', 'import_delimiter', 'has_header',
                  'url', 'cube', 'username', 'password', 'filename', 'is_deleted', 'currency_symbol',
                  'currency_delimiter']


class ReconGetSerializer(serializers.ModelSerializer):
    class Meta:
        model = Recon
        fields = ['recon_id', 'name', 'app1_id', 'app2_id', 'variance_threshold',
                  'created_by', 'created_date', 'execution_date', 'last_modified_by',
                  'last_modified_date', 'status', 'description']

    def to_representation(self, instance):
        representation = super(ReconGetSerializer, self).to_representation(instance)
        representation['created_date'] = instance.created_date.strftime('%m-%d-%Y %H:%M:%S')
        if instance.last_modified_date:
            representation['last_modified_date'] = instance.last_modified_date.strftime('%m-%d-%Y %H:%M:%S')
        if instance.execution_date:
            representation['execution_date'] = instance.execution_date.strftime('%m-%d-%Y %H:%M:%S')
        return representation


class ReconSerializer(serializers.ModelSerializer):
    class Meta:
        model = Recon
        fields = ['recon_id', 'name', 'app1_id', 'app2_id', 'variance_threshold',
                  'created_by', 'created_date', 'execution_date', 'status', 'description', 'is_deleted']


class ReconUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Recon
        fields = ['name', 'variance_threshold', 'execution_date', 'status', 'description',
                  'last_modified_by', 'last_modified_date', 'is_deleted']


class DimensionGetSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReconDimensions
        fields = ['dimensions_id', 'turn_on_define_order', 'dimension', 'dim_in_file',
                  'type_field', 'top_member', 'app_type', 'is_active', 'in_recon']

    def to_representation(self, instance):
        if instance.app_type == "0":
            return {
                'order': instance.turn_on_define_order,
                'app1_dimension': instance.dimension,
                'app1_dim_in_file': instance.dim_in_file,
                'app1_type_field': instance.type_field,
                'app1_top_member': instance.top_member,
                'app1_app_type': instance.app_type,
                'app1_is_active': instance.is_active,
                'in_recon': instance.in_recon
            }
        elif instance.app_type == "1":
            return {
                'order': instance.turn_on_define_order,
                'app2_dimension': instance.dimension,
                'app2_dim_in_file': instance.dim_in_file,
                'app2_type_field': instance.type_field,
                'app2_top_member': instance.top_member,
                'app2_app_type': instance.app_type,
                'app2_is_active': instance.is_active,
                'in_recon': instance.in_recon
            }


class DimensionSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReconDimensions
        fields = ['dimensions_id', 'turn_on_define_order', 'dimension', 'dim_in_file',
                  'type_field', 'top_member', 'app_type', 'recon_id', 'is_active', 'recon_app_id', 'in_recon']
