CREATE OR REPLACE PROCEDURE admin.sp_sendinvite(useremail character varying, role character varying, usergroup character varying, accesstype character varying)
 LANGUAGE plpgsql
AS $procedure$  
BEGIN         
   IF EXISTS (SELECT email FROM admin."UserDetails"
              WHERE  email = UserEmail
          ) THEN
      RAISE EXCEPTION 'User already exist!';
	  
   ELSE
   	  IF EXISTS (SELECT email FROM admin."InviteDetails"
              WHERE  email = UserEmail
          ) THEN
      RAISE EXCEPTION 'Invite already sent before!';
	  
	  ELSE
		  INSERT INTO admin."InviteDetails" (email,role,"group",access_type) VALUES   
		(UserEmail,Role,UserGroup,to_jsonb(AccessType::jsonb[]));
	   END IF;
	END IF;
END  
$procedure$
;

-- Permissions

ALTER PROCEDURE "admin".sp_sendinvite(varchar, varchar, varchar, varchar) OWNER TO "user_dataRecon_admin";
GRANT ALL ON PROCEDURE "admin".sp_sendinvite(varchar, varchar, varchar, varchar) TO postgres;
