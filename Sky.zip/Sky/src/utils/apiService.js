import axios from "axios";
import { redirectToLogin, getAuthorizationHeaders } from "./utils";
import { toast } from "react-toastify";
const ENDPOINT = process.env.REACT_APP_API;

const errorHandling = (err) => {
  if (err.response.status === 401) {
    toast.info("Session got expired, Please try to login again.");
    redirectToLogin();
    return;
  }
  toast.error("Oops something went wrong, Please contact administrator.");
};

// Handle GET API Call
export const makeGetAPICall = async (url) => {
  let URI = ENDPOINT + url;
  return new Promise(function (resolve, reject) {
    axios
      .get(URI, getAuthorizationHeaders())
      .then((res) => {
        resolve(res.data);
      })
      .catch((err) => {
        errorHandling(err);
        reject(err);
      });
  });
};

// Handle DELETE API Call
export const makeDeleteAPICall = async (url, email) => {
  let URI = ENDPOINT + url;

  return new Promise(function (resolve, reject) {
    if (!sessionStorage.getItem("profile")) {
      redirectToLogin();
      return;
    }
    const token = JSON.parse(sessionStorage.getItem("profile"));

    axios
      .delete(URI, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
        data: email,
      })
      .then((res) => {
        resolve(res.data);
      })
      .catch((err) => {
        errorHandling(err);
        reject(err);
      });
  });
};

// Handle DELETE API Call
export const makeDeleteBodyParamAPICall = async (url, reqObj) => {
  let URI = ENDPOINT + url;
  return new Promise(function (resolve, reject) {
    if (!sessionStorage.getItem("profile")) {
      redirectToLogin();
      return;
    }
    const token = JSON.parse(sessionStorage.getItem("profile"));
    axios
      .delete(URI, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
        data: reqObj,
      })
      .then((res) => {
        resolve(res.data);
      })
      .catch((err) => {
        errorHandling(err);
        reject(err);
      });
  });
};

// Handle POST API Call
export const makePostAPICall = async (url, reqObj, isRegistered = true) => {
  if (url === "report/run") {
    for (let i = 0; i < reqObj.colList.length; i++) {
      reqObj.colList[i] = reqObj.colList[i].replace(/['"]+/g, "");
    }
  }
  let URI = ENDPOINT + url;
  if (sessionStorage.getItem("profile") == "" && !!isRegistered) {
    redirectToLogin();
  }
  return new Promise(function (resolve, reject) {
    axios
      .post(URI, reqObj, getAuthorizationHeaders())
      .then((res) => {
        resolve(res.data);
      })
      .catch((err) => {
        errorHandling(err);
        reject(err);
      });
  });
};
// update user API call

export const makePostUpdateUserAPICall = async (
  url,
  reqObj,
  isRegistered = true
) => {
  let URI = ENDPOINT + url;
  if (sessionStorage.getItem("profile") == "" && !!isRegistered) {
    redirectToLogin();
  }
  let payload = {
    email: reqObj.email,
    access_type: reqObj.access_type,
    is_active: reqObj.is_active,
    role: reqObj.role,
  };
  return new Promise(function (resolve, reject) {
    axios
      .post(URI, payload, getAuthorizationHeaders())
      .then((res) => {
        resolve(res.data);
      })
      .catch((err) => {
        errorHandling(err);
        reject(err);
      });
  });
};

export const makeResetPostAPICall = async (url, reqObj) => {
  let URI = ENDPOINT + url;
  return new Promise(function (resolve, reject) {
    axios
      .post(URI, reqObj)
      .then((res) => {
        resolve(res.data);
      })
      .catch((err) => {
        errorHandling(err);
        reject(err);
      });
  });
};

// Handle POST API Call
export const makePostAPICallRegister = async (
  url,
  reqObj,
  isRegistered = true
) => {
  let URI = ENDPOINT + url;
  if (sessionStorage.getItem("profile") == "" && !!isRegistered) {
    redirectToLogin();
  }
  return new Promise(function (resolve, reject) {
    axios
      .post(URI, reqObj)
      .then((res) => {
        resolve(res.data);
      })
      .catch((err) => {
        errorHandling(err);
        reject(err);
      });
  });
};

// make POST API CALL to get user credentials
export const makePostAPICallgetUserDetails = async (url, email) => {
  let URI = ENDPOINT + url;

  if (sessionStorage.getItem("profile") == "") {
    redirectToLogin();
  }
  return new Promise(function (resolve, reject) {
    axios
      .post(URI, email, getAuthorizationHeaders())
      .then((res) => {
        resolve(res.data);
      })
      .catch((err) => {
        errorHandling(err);
        reject(err);
      });
  });
};

export const makePostAPICallFileDownload = async (url, reqObj) => {
  let URI = ENDPOINT + url;

  return new Promise(function (resolve, reject) {
    axios
      .post(URI, reqObj, getAuthorizationHeaders(), { responseType: "blob" })
      .then((response) => {
        const filename = response.headers["content-disposition"]
          .split(";")
          .find((n) => n.includes("filename="))
          .replace("filename=", "")
          .trim();
        const url = window.URL.createObjectURL(
          new Blob([response.data], { type: "text/csv" })
        );
        const link = document.createElement("a");
        link.href = url;
        link.setAttribute("download", filename);
        document.body.appendChild(link);
        link.click();
      })
      .catch((err) => {
        errorHandling(err);
        reject(err);
      });
  });
};

export const makePostAPICallFileDownloadrunreportexport = async (url, reqObj) => {
  let URI = ENDPOINT + url;

  return new Promise(function (resolve, reject) {
    axios
      .post(URI, reqObj, getAuthorizationHeaders(), { responseType: "arraybuffer" })
      .then((response) => {
        const token = JSON.parse(sessionStorage.getItem("profile"));
        // Call the getReportFunction
        axios
          .get(ENDPOINT + 'report/run/getReport/' + reqObj.recon_id,
            {
              responseType: 'arraybuffer',
              headers: {
                "Content-Type": "multipart/form-data",
                Authorization: `Bearer ${token}`,
              }
            })
          .then((response) => {
            const data = new Blob([response.data]);
            const url = window.URL.createObjectURL(data);
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute("download","Report.zip");
            document.body.appendChild(link);
            link.click();
          })
          .catch((err) => {
            errorHandling(err);
            reject(err);
          })
      })
      .catch((err) => {
        errorHandling(err);
        reject(err);
      });
  });
};

export const makeGetAPICallFileDownload = async (url, reqObj) => {
  let URI = ENDPOINT + url;
  const token = JSON.parse(sessionStorage.getItem("profile"));
  return new Promise(function (resolve, reject) {
    axios
      .get(URI + reqObj, {
        responseType: "arraybuffer",
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      })
      .then((response) => {
        const filename = response.headers["content-disposition"]
          .split(";")
          .find((n) => n.includes("filename="))
          .replace("filename=", "")
          .trim();
        let blob = new Blob([response.data], { type: "text/csv" });
        const downloadUrl = URL.createObjectURL(blob);
        let a = document.createElement("a");
        a.href = downloadUrl;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
      });
  });
};

export const makeZIPGetAPICallFileDownload = async (url, reqObj) => {
  let URI = ENDPOINT + url;
  const token = JSON.parse(sessionStorage.getItem("profile"));
  return new Promise(function (resolve, reject) {
    axios
      .get(URI + reqObj, {
        responseType: "arraybuffer",
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      })
      .then((response) => {
        const filename = response.headers["content-disposition"]
          .split(";")
          .find((n) => n.includes("filename="))
          .replace("filename=", "")
          .trim();
        let blob = new Blob([response.data], { type: "application/zip" });
        const downloadUrl = URL.createObjectURL(blob);
        let a = document.createElement("a");
        a.href = downloadUrl;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
      });
  });
};

//     axios
//       .get(
//         URI + reqObj,
//         {
//           headers: {
//             Authorization: `Bearer ${token}`,
//             'Content-Type': 'multipart/form-data'
//           },
//         },
//         { responseType: "arrayBuffer" }
//       )
//       .then((response) => {
//         const filename = response.headers["content-disposition"]
//           .split(";")
//           .find((n) => n.includes("filename="))
//           .replace("filename=", "")
//           .trim();
//         let blob = new Blob([response.data], { type: "application/zip" });
//         const url = window.URL.createObjectURL(blob);
//         const link = document.createElement("a");
//         link.href = url;
//         link.setAttribute("download", filename);
//         document.body.appendChild(link);
//         link.click();
//       })
//       .catch((err) => {
//         errorHandling(err);
//         reject(err);
//       });
//   });
// };

// Handle PUT API Call
export const makePutAPICall = async (url, reqObj) => {
  let URI = ENDPOINT + url;
  return new Promise(function (resolve, reject) {
    axios
      .put(URI, reqObj, getAuthorizationHeaders())
      .then((res) => {
        resolve(res.data);
      })
      .catch((err) => {
        errorHandling(err);
        reject(err);
      });
  });
};

// Handle PUT API Call
export const makePutAPIFormData = async (url, formData) => {
  let URI = ENDPOINT + url;
  return new Promise(function (resolve, reject) {
    if (!sessionStorage.getItem("profile")) {
      redirectToLogin();
      return;
    }
    const token = JSON.parse(sessionStorage.getItem("profile"));
    axios
      .put(URI, formData, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((res) => {
        resolve(res.data);
      })
      .catch((err) => {
        errorHandling(err);
        reject(err);
      });
  });
};
// Handle POST without auth headers
export const authUser = async (url, email, password) => {
  let URI = ENDPOINT + url;
  return new Promise(function (resolve, reject) {
    axios
      .post(URI, { email, password }, {headers: {
         "access-control-allow-origin" : "*",
         "Content-type": "application/json; charset=UTF-8"
         }})
      .then((res) => {
        resolve(res.data);
      })
      .catch((err) => {
        errorHandling(err);
        reject(err);
      });
  });
};

//reset
export const forgotPassPost = async (url, reqObj) => {
  let URI = ENDPOINT + url;
  return new Promise(function (resolve, reject) {
    axios
      .post(URI, reqObj)
      .then((res) => {
        resolve(res.data);
      })
      .catch((err) => {
        reject(err);
      });
  });
};
