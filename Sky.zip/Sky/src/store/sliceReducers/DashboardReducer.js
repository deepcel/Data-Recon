import { createSlice } from "@reduxjs/toolkit";
import { toast } from "react-toastify";
import {
  makeGetAPICall,
  makeDeleteAPICall,
  makePostAPICall,
  makePutAPICall,
  makePutAPIFormData,
  makePostAPICallFileDownload,
  makeDeleteBodyParamAPICall,
  makeGetAPICallFileDownload,
  makeZIPGetAPICallFileDownload,
} from "../../utils/apiService";
import { redirectToLogin } from "../../utils/utils";
import { enableLoader, hideLoader } from "./LoadReducer";

// Dashboard reducer is used for handle all the steps data
export const dashboardReducer = createSlice({
  name: "dashboard",
  initialState: {
    loading: false,
    appData: [],
    error: null,
    selectedRole: "",
    selectedReconRunId: "",
    runImportData: {
      headers: [],
      rows: [],
      app1Rows: [],
      app2Rows: [],
      app1JERows: [],
      app2JERows: [],
      jerows: [],
      jeheaders: [],
    },
    selectedRecon: {
      recon_id: "",
      reconName: "",
    },
    dimensions: {
      app1Dimension: [],
      app2Dimension: [],
      dimensionsimport: [],
    },
    bridgeMembers: {
      app1Rows: [],
      app2Rows: [],
      comments: [],
      jecomments: [],
    },
    runBridge: {
      headers: [],
      rows: [],
      unMapped: [],
      jeheaders: [],
      jerows: [],
      unMappedJE: [],
    },
    transformation: {
      rows: [],
      app1Sync: [],
      app2Sync: [],
      combinations: {
        app1Dimension: [],
        app2Dimension: [],
        app1Data: [],
        app2Data: [],
      },
    },
    runTransformation: {
      headers: [],
      rows: [],
    },
    runReport: {
      fixedheaders: [],
      changedheaders: [],
      rows: [],
      main_report: [],
      je_report: [],
      final_report: [],
      variance_percentage: "",
    },
  },
  reducers: {
    isLoading: (state, action) => {
      state.loading = true;
    },
    VALIDATE_SESSION: (state, action) => {
      state.loading = false;
      state.error = null;
      state.appData = [action.payload.data];
    },
    RECON_ADD: (state, action) => {
      state.loading = false;
      state.error = null;
      state.appData[0].unshift(action.payload.data);
    },
    RECON_DELETE: (state, action) => {
      state.loading = false;
      state.error = null;
      state.appData[0] = state.appData[0].filter(
        (data) => data.recon_id !== action.payload
      );
    },
    RECON_UPDATE_DIMENSIONS: (state, action) => {
      state.loading = false;
      state.error = null;
      let index = state.appData[0].findIndex((p) => {
        return p.recon_id === action.payload.recon_id;
      });
      state.appData[0][index].dimensions = action.payload.response.data;
    },
    RUN_IMPORT_UPDATE: (state, action) => {
      state.loading = false;
      state.error = null;
      state.runImportData.headers = [...action.payload.response.headers];
      if (action.payload.appType === 0) {
        state.runImportData.app1Rows = [...action.payload.response.rows];
      } else {
        state.runImportData.app2Rows = [...action.payload.response.rows];
      }
      state.runImportData.rows = [
        ...state.runImportData.app1Rows,
        ...state.runImportData.app2Rows,
      ];
    },
    LOAD_RUN_IMPORT: (state, action) => {
      state.loading = false;
      state.error = null;
      state.runImportData.headers = [...action.payload.response.headers];
      state.runImportData.rows = [...action.payload.response.rows];
    },
    LOAD_RUN_JE_IMPORT: (state, action) => {
      state.loading = false;
      state.error = null;
      state.runImportData.jeheaders = [...action.payload.response.headers];
      state.runImportData.jerows = [...action.payload.response.rows];
    },
    LOAD_DIRECTCONNECT_RUN_IMPORT: (state, action) => {
      state.loading = false;
      state.error = null;
      state.runImportData.headers = [...action.payload.response.headers];
      state.runImportData.rows = [...action.payload.response.rows];
    },
    RECON_IMPORT_BRIDGE_MEMBERS: (state, action) => {
      state.loading = false;
      state.error = null;
      if (action.payload.response.app_type === "0") {
        state.bridgeMembers.app1Rows = [...action.payload.response.rows];
      } else if (action.payload.response.app_type === "1") {
        state.bridgeMembers.app2Rows = [...action.payload.response.rows];
      }
    },
    RECON_IMPORT_COMMENTS: (state, action) => {
      state.loading = false;
      state.error = null;
      state.bridgeMembers.comments = [...action.payload.response.rows];
    },
    LOAD_COMMENTS: (state, action) => {
      state.loading = false;
      state.error = null;
      state.bridgeMembers.comments = [...action.payload.response.rows];
    },
    LOAD_JE_COMMENTS: (state, action) => {
      state.loading = false;
      state.error = null;
      state.bridgeMembers.jecomments = [...action.payload.response.rows];
    },
    DELETE_INVALID_COMMENTS: (state, action) => {
      state.loading = false;
      state.error = null;
      state.bridgeMembers.comments = state.bridgeMembers.comments.filter(
        (item) => item.bridge_id !== action.payload
      );
    },
    DELETE_INVALID_JE_COMMENTS: (state, action) => {
      state.loading = false;
      state.error = null;
      state.bridgeMembers.jecomments = state.bridgeMembers.jecomments.filter(
        (item) => item.bridge_id !== action.payload
      );
    },
    LOAD_BRIDGE_MEMBERS: (state, action) => {
      state.loading = false;
      state.error = null;
      state.bridgeMembers.app1Rows = [...action.payload.response.app1_rows];
      state.bridgeMembers.app2Rows = [...action.payload.response.app2_rows];
    },
    UPDATE_BRIDGE_MEMBERS: (state, action) => {
      state.loading = false;
      state.error = null;
      if (action.payload.response.app_type === "0") {
        state.bridgeMembers.app1Rows = [...action.payload.response.rows];
      } else if (action.payload.response.app_type === "1") {
        state.bridgeMembers.app2Rows = [...action.payload.response.rows];
      }
    },
    RECON_LOAD_DIMENSION_MEMBERS: (state, action) => {
      state.loading = false;
      state.error = null;
      state.dimensions.app1Dimension = [
        ...action.payload.response.app_01_dimension,
      ];
      state.dimensions.app2Dimension = [
        ...action.payload.response.app_02_dimension,
      ];
    },
    RECON_LOAD_RUN_BRIDGE: (state, action) => {
      state.loading = false;
      state.error = null;
      state.runBridge.headers = [...action.payload.response.headers];
      state.runBridge.rows = [...action.payload.response.rows];
    },
    RECON_LOAD_RUN_BRIDGE_JE: (state, action) => {
      state.loading = false;
      state.error = null;
      state.runBridge.jeheaders = [...action.payload.response.headers];
      state.runBridge.jerows = [...action.payload.response.rows];
    },
    RECON_LOAD_BRIDGE_UNMAPPED: (state, action) => {
      state.loading = false;
      state.error = null;
      state.runBridge.unMapped = [...action.payload.response.rows];
    },
    RECON_LOAD_BRIDGE_UNMAPPED_JE: (state, action) => {
      state.loading = false;
      state.error = null;
      state.runBridge.unMappedJE = [...action.payload.response.rows];
    },
    RECON_REMOVE_UNMAPPED_ITEM: (state, action) => {
      state.loading = false;
      state.error = null;
      state.runBridge.unMapped = state.runBridge.unMapped.filter(
        (item) => item.out_id !== action.payload.response.rows[0].out_id
      );
    },
    RECON_REMOVE_UNMAPPEDJE_ITEM: (state, action) => {
      state.loading = false;
      state.error = null;
      state.runBridge.unMappedJE = state.runBridge.unMappedJE.filter(
        (item) => item.out_id !== action.payload.response.rows[0].out_id
      );
    },
    DELETE_BRIDGE_MEMBER: (state, action) => {
      state.loading = false;
      state.error = null;
      if (action.payload.response.appType === "0") {
        state.bridgeMembers.app1Rows = state.bridgeMembers.app1Rows.filter(
          (item) => item.bridge_id !== action.payload.response.bridgeId
        );
      } else if (action.payload.response.appType === "1") {
        state.bridgeMembers.app2Rows = state.bridgeMembers.app2Rows.filter(
          (item) => item.bridge_id !== action.payload.response.bridgeId
        );
      }
    },
    LOAD_TRANSFORMATION_MEMBERS: (state, action) => {
      state.loading = false;
      state.error = null;
      state.transformation.rows = [...action.payload.response.rows];
    },
    UPDATE_TRANSFORMATION_MEMBERS: (state, action) => {
      state.loading = false;
      state.error = null;
      state.transformation.rows = [...action.payload.response.rows];
    },
    UPDATE_TRANSFORMATION_SYNC_MEMBERS: (state, action) => {
      state.loading = false;
      state.error = null;
      if (action.payload.response.app_type === "0") {
        state.transformation.app1Sync = [...action.payload.response.rows];
      } else if (action.payload.response.app_type === "1") {
        state.transformation.app2Sync = [...action.payload.response.rows];
      }
    },
    RECON_IMPORT_TRANSFORM_MAPPINGS: (state, action) => {
      state.loading = false;
      state.error = null;
      if (action.payload.response.app_type === "0") {
        state.transformation.app1Sync = [...action.payload.response.rows];
      } else if (action.payload.response.app_type === "1") {
        state.transformation.app2Sync = [...action.payload.response.rows];
      }
    },
    LOAD_TRANSFORMATION_SYNC: (state, action) => {
      state.loading = false;
      state.error = null;
      state.transformation.app1Sync = [...action.payload.response.app1_rows];
      state.transformation.app2Sync = [...action.payload.response.app2_rows];
    },
    TRANSFORM_LOAD_COMBINATIONS: (state, action) => {
      state.loading = false;
      state.error = null;
      state.transformation.combinations.app1Dimension = [
        ...action.payload.response.app1_dimensions,
      ];
      state.transformation.combinations.app2Dimension = [
        ...action.payload.response.app2_dimensions,
      ];
      state.transformation.combinations.app1Data = [
        ...action.payload.response.app1_data,
      ];
      state.transformation.combinations.app2Data = [
        ...action.payload.response.app2_data,
      ];
    },
    DELETE_TRANSFORM_SYNC: (state, action) => {
      state.loading = false;
      state.error = null;
      if (action.payload.response.appType === "0") {
        state.transformation.app1Sync = state.transformation.app1Sync.filter(
          (item) => item.sync_id !== action.payload.response.syncId
        );
      } else if (action.payload.response.appType === "1") {
        state.transformation.app2Sync = state.transformation.app2Sync.filter(
          (item) => item.sync_id !== action.payload.response.syncId
        );
      }
    },
    RECON_LOAD_RUN_TRANSFORMATION: (state, action) => {
      state.loading = false;
      state.error = null;
      state.runTransformation.headers = [...action.payload.response.headers];
      state.runTransformation.rows = [...action.payload.response.rows];
    },
    RECON_LOAD_RUN_REPORT: (state, action) => {
      state.loading = false;
      state.error = null;
      state.runReport.fixedheaders = [...action.payload.response.headers];
      // state.runReport.rows = [...action.payload.response.rows];
      state.runReport.main_report = [...action.payload.response.main_report];
      state.runReport.je_report = [...action.payload.response.je_report];
      state.runReport.final_report = [...action.payload.response.final_report];
      state.runReport.variance_percentage = [
        ...action.payload.response.variance_percentage,
      ];
    },
    RECON_LOAD_RUN_REPORT_FILTER: (state, action) => {
      state.loading = false;
      state.error = null;
      state.runReport.changedheaders = [...action.payload.newdata.colList];
      // state.runReport.rows = [...action.payload.response.rows];
      state.runReport.main_report = [...action.payload.response.main_report];
      state.runReport.je_report = [...action.payload.response.je_report];
      state.runReport.final_report = [...action.payload.response.final_report];
      state.runReport.variance_percentage = [
        ...action.payload.response.variance_percentage,
      ];
    },
    RECON_LOAD_RUN_REPORT_EMPTY: (state, action) => {
      state.loading = false;
      state.error = null;
      state.runReport.headers = [];
    },
    //update displaing dimensions
    RECON_UPDATE: (state, action) => {
      state.loading = false;
      state.error = null;
      let index = state.appData[0].findIndex((p) => {
        return p.recon_id === action.payload.recon_id;
      });
      state.appData[0][index] = action.payload.response.data;
      state.dimensions.dimensionsimport = [
        ...action.payload.response.data.dimensions,
      ];
    },
    //importing dimensions
    RECON_IMPORT_DIMENSIONS: (state, action) => {
      state.loading = false;
      state.error = null;
      state.dimensions.dimensionsimport = [...action.payload.response.rows];
    },
    RUN_JE_IMPORT_UPDATE: (state, action) => {
      state.loading = false;
      state.error = null;
      state.runImportData.jeheaders = [...action.payload.response.headers];
      if (action.payload.appType === 0) {
        state.runImportData.app1JERows = [...action.payload.response.rows];
      } else {
        state.runImportData.app2JERows = [...action.payload.response.rows];
      }
      state.runImportData.jerows = [
        ...state.runImportData.app1JERows,
        ...state.runImportData.app2JERows,
      ];
    },
    RECON_IMPORT_JE_COMMENTS: (state, action) => {
      state.loading = false;
      state.error = null;
      state.bridgeMembers.jecomments = [...action.payload.response.rows];
    },
    USER_ROLE_CHANGED: (state, action) => {
      state.loading = false;
      state.error = null;
      state.appData = [action.payload];
      state.selectedRole = action.payload.product;
    },
    INVALID_SESSION: (state) => {
      state.loading = false;
      state.error = null;
    },
    failedRetrive: (state, action) => {
      state.loading = false;
      state.error = action.message;
      state.selectedRole = action.payload.value;
    },
    clearSession: (state) => {
      state.loading = false;
      state.error = null;
      state.appData = [];
    },
    setSelectedReconRunId: (state, action) => {
      state.selectedReconRunId = action.payload;
      state.runBridge = {
        headers: [],
        rows: [],
        unMapped: [],
      };
    },
  },
});

// Action creators are generated for each case reducer function
export const {
  VALIDATE_SESSION,
  INVALID_SESSION,
  RECON_ADD,
  RECON_DELETE,
  RECON_UPDATE,
  RECON_UPDATE_DIMENSIONS,
  setSelectedReconRunId,
  RUN_IMPORT_UPDATE,
  RECON_REMOVE_UNMAPPED_ITEM,
  LOAD_RUN_IMPORT,
  isLoading,
  failedRetrive,
  clearSession,
  LOAD_BRIDGE_MEMBERS,
  RECON_LOAD_DIMENSION_MEMBERS,
  RECON_LOAD_RUN_BRIDGE,
  RECON_LOAD_RUN_BRIDGE_JE,
  RECON_LOAD_BRIDGE_UNMAPPED,
  RECON_LOAD_BRIDGE_UNMAPPED_JE,
  RECON_IMPORT_BRIDGE_MEMBERS,
  DELETE_BRIDGE_MEMBER,
  RECON_IMPORT_COMMENTS,
  UPDATE_BRIDGE_MEMBERS,
  LOAD_COMMENTS,
  DELETE_INVALID_COMMENTS,
  LOAD_TRANSFORMATION_MEMBERS,
  UPDATE_TRANSFORMATION_MEMBERS,
  RECON_IMPORT_TRANSFORM_MAPPINGS,
  RECON_LOAD_RUN_TRANSFORMATION,
  LOAD_TRANSFORMATION_SYNC,
  DELETE_TRANSFORM_SYNC,
  UPDATE_TRANSFORMATION_SYNC_MEMBERS,
  TRANSFORM_LOAD_COMBINATIONS,
  RECON_LOAD_RUN_REPORT,
  RECON_IMPORT_DIMENSIONS,
  RUN_JE_IMPORT_UPDATE,
  RECON_IMPORT_JE_COMMENTS,
  DELETE_INVALID_JE_COMMENTS,
  LOAD_JE_COMMENTS,
  LOAD_RUN_JE_IMPORT,
  RECON_LOAD_RUN_REPORT_FILTER,
  RECON_LOAD_RUN_REPORT_EMPTY,
  USER_ROLE_CHANGED,
  RECON_REMOVE_UNMAPPEDJE_ITEM,
  LOAD_DIRECTCONNECT_RUN_IMPORT,
} = dashboardReducer.actions;

// update selected recon id in store
export const updateSelectedReconRunId = (payload) => async (dispatch) => {
  dispatch(setSelectedReconRunId(payload));
};

export const deleteInvalidComments = (payload) => async (dispatch) => {
  dispatch(DELETE_INVALID_COMMENTS(payload));
};

export const deleteInvalidJEComments = (payload) => async (dispatch) => {
  dispatch(DELETE_INVALID_JE_COMMENTS(payload));
};

// Create recon run
export const createReconRun = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePostAPICall("recon/create", payload);
    if (response.status === 200) {
      dispatch(RECON_ADD(response));
      toast.success("Recon Run Name is created successfully");
    } else if (response.status === 6001) {
      toast.error(
        "Recon Run Name is duplicated, please enter unique Recon RunName"
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

// Create recon run
export const bridgeRun = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePostAPICall("bridge/run", payload);
    if (response.status === 200) {
      dispatch(RECON_LOAD_RUN_BRIDGE({ response: response }));
      dispatch(
        listBrigeUnMapped({ recon_id: payload.recon_id, je_flag: false })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const listBrigeUnMapped = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePostAPICall("bridge/outs", payload);
    if (response.status === 200) {
      dispatch(RECON_LOAD_BRIDGE_UNMAPPED({ response: response }));
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

//JE Runbridge
export const bridgeRunJE = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePostAPICall("bridge/run", payload);
    if (response.status === 200) {
      dispatch(RECON_LOAD_RUN_BRIDGE_JE({ response: response }));
      dispatch(
        listBrigeUnMappedJE({ recon_id: payload.recon_id, je_flag: true })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const listBrigeUnMappedJE = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePostAPICall("bridge/outs", payload);
    if (response.status === 200) {
      dispatch(RECON_LOAD_BRIDGE_UNMAPPED_JE({ response: response }));
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

// Get all the recon run list
export const listReconRun = () => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makeGetAPICall("recon/list");
    if (response.status === 200) {
      dispatch(VALIDATE_SESSION(response));
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const reconsHarddeleteAPIcall = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePostAPICall("maintenance/update_config", payload);
    toast.success(response.message);
    if (response.status === 200) {
      // toast.success(response.message);
      dispatch(listReconRun(payload.recon_id));
    } else if (response.status === 401) {
      toast.error(response.message);
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      // toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

// Delete recon run based on reconid
export const deleteReconRun = (reconId) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makeDeleteAPICall("recon/delete/" + reconId);
    if (response.status === 200) {
      dispatch(RECON_DELETE(reconId));
      toast.success("Recon Run is deleted successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

// Delete recon run based on reconid
export const deleteBridgeMember = (payload, appType) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makeDeleteBodyParamAPICall("bridge/delete", payload);
    if (response.status === 200) {
      dispatch(
        DELETE_BRIDGE_MEMBER({
          response: {
            appType: appType,
            bridgeId: payload.bridge_id,
          },
        })
      );
      toast.success("Recon bridge member is deleted successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

// Delete recon run based on reconid
export const deleteComments = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makeDeleteBodyParamAPICall(
      "bridge/comments/delete",
      payload
    );
    if (response.status === 200) {
      dispatch(deleteInvalidComments(payload.bridge_id));
      toast.success("Comment is deleted successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

// Update specific/particular recon details
export const updateReconRun = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPICall("recon/update", { data: payload });
    if (response.status === 200) {
      dispatch(
        RECON_UPDATE({
          response: response,
          recon_id: payload.recon_id,
        })
      );
      toast.success("ReconRun is updated successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const updateUnMappedBride = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPICall("bridge/outs/update", payload);
    if (response.status === 200) {
      dispatch(
        RECON_REMOVE_UNMAPPED_ITEM({
          response: payload,
        })
      );
      dispatch(
        bridgeRun({
          recon_id: payload.recon_id,
          max_rows: 100,
          page_number: 1,
          je_flag: false,
        })
      );
      toast.success("Unmapped kickouts updated successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const updateUnMappedBridgeJE = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPICall("bridge/outs/update", payload);
    if (response.status === 200) {
      dispatch(
        RECON_REMOVE_UNMAPPEDJE_ITEM({
          response: payload,
        })
      );
      dispatch(
        bridgeRun({
          recon_id: payload.recon_id,
          max_rows: 100,
          page_number: 1,
          je_flag: true,
        })
      );
      toast.success("Unmapped kickouts updated successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

// Update recon dimension
export const updateReconDimension = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPICall("recon/update", { data: payload });
    if (response.status === 200) {
      dispatch(
        RECON_UPDATE({
          response: response,
          recon_id: payload.recon_id,
        })
      );
      toast.success("ReconRun is updated successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const reorderDimension = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPICall("recon/dim/order/update", payload);
    if (response.status === 200) {
      dispatch(
        RECON_UPDATE_DIMENSIONS({
          response: response,
          recon_id: payload.recon_id,
        })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const updateBrideMember = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPICall("bridge/update", payload);
    if (response.status === 200) {
      dispatch(
        UPDATE_BRIDGE_MEMBERS({
          response: response,
        })
      );
      toast.success("Bridge members updated successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const updateCommentBride = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPICall("bridge/comments/update", payload);
    if (response.status === 200) {
      dispatch(
        LOAD_COMMENTS({
          response: response,
        })
      );
      toast.success("Bridge members updated successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

// Get Recon details with dimension
export const listReconRunDimension = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makeGetAPICall("recon/info/" + payload);
    if (response.status === 200) {
      dispatch(
        RECON_UPDATE({
          response: response,
          recon_id: payload,
        })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const getSourceData = (payload) => async (dispatch) => {
  try {
    dispatch(isLoading({ loading: true }));
    const response = await makePostAPICall("source/data", payload);
    if (response.status === 200) {
      dispatch(
        LOAD_RUN_IMPORT({
          response: response,
        })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

// Get Recon details with dimension
export const runImport = (formData, appType) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPIFormData("source/file/import", formData);
    if (response.status === 200) {
      dispatch(
        RUN_IMPORT_UPDATE({
          response: response,
          appType: appType,
        })
      );
      toast.success("File imported successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

// Get Recon details with dimension
export const bridgeMemberImport = (formData, appType) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPIFormData(
      "bridge/import",
      formData,
      appType
    );
    if (response.status === 200) {
      dispatch(
        RECON_IMPORT_BRIDGE_MEMBERS({
          response: response,
        })
      );
      toast.success("File imported successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const commentsImport = (formData) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPIFormData(
      "bridge/comments/import",
      formData
    );
    if (response.status === 200) {
      dispatch(
        RECON_IMPORT_COMMENTS({
          response: response,
        })
      );
      toast.success("File imported successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const unMappedKickoutImport =
  (formData, reconId) => async (dispatch) => {
    try {
      dispatch(isLoading({ loading: true }));
      const response = await makePutAPIFormData("bridge/outs/import", formData);
      if (response.status === 200) {
        dispatch(
          bridgeRun({
            recon_id: reconId,
            max_rows: 100,
            page_number: 1,
            je_flag: false,
          })
        );
        toast.success("File imported successfully");
      } else if (response.status === 401) {
        dispatch(INVALID_SESSION(response));
        redirectToLogin();
      } else {
        toast.error(response.message);
      }
      dispatch(hideLoader());
    } catch (err) {
      dispatch(hideLoader());
    }
  };

export const unMappedKickoutImportJE =
  (formData, reconId) => async (dispatch) => {
    try {
      dispatch(isLoading({ loading: true }));
      const response = await makePutAPIFormData("bridge/outs/import", formData);
      if (response.status === 200) {
        dispatch(
          bridgeRunJE({
            recon_id: reconId,
            max_rows: 100,
            page_number: 1,
            je_flag: true,
          })
        );
        toast.success("File imported successfully");
      } else if (response.status === 401) {
        dispatch(INVALID_SESSION(response));
        redirectToLogin();
      } else {
        toast.error(response.message);
      }
      dispatch(hideLoader());
    } catch (err) {
      dispatch(hideLoader());
    }
  };

// Get Recon details with dimension
export const listBridgeMembers = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makeGetAPICall("bridge/list/" + payload);
    if (response.status === 200) {
      dispatch(
        LOAD_BRIDGE_MEMBERS({
          response: response,
        })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

// Get Recon details with dimension
export const listComments = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makeGetAPICall("bridge/comments/list/" + payload);
    if (response.status === 200) {
      dispatch(
        LOAD_COMMENTS({
          response: response,
        })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

//Display je comments in bridge member tab
export const listJEComments = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makeGetAPICall("bridge/comments/je/list/" + payload);
    if (response.status === 200) {
      dispatch(
        LOAD_COMMENTS({
          response: response,
        })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

// Get Recon details with dimension
export const downloadBridgeMember = (payload) => async (dispatch) => {
  try {
    dispatch(isLoading({ loading: true }));
    const response = await makePostAPICallFileDownload(
      "bridge/export",
      payload
    );
    if (response.status === 200) {
      // dispatch(RUN_IMPORT_UPDATE({
      //     response: response,
      //     appType: appType
      // }));
      toast.success("Download triggered successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

// Get Recon details with dimension
export const downloadCommentsFile = (payload) => async (dispatch) => {
  try {
    dispatch(isLoading({ loading: true }));
    const response = await makeGetAPICallFileDownload(
      "bridge/comments/export/",
      payload
    );
    if (response.status === 200) {
      toast.success("Download triggered successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

// Get Recon details with dimension
export const downloadUnMappedKickoutFile = (payload) => async (dispatch) => {
  try {
    dispatch(isLoading({ loading: true }));
    const response = await makePostAPICallFileDownload(
      "bridge/outs/export",
      payload
    );
    if (response.status === 200) {
      toast.success("Download triggered successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

// Get all the recon run list
export const listDimension = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makeGetAPICall("bridge/dimension/list/" + payload);
    if (response.status === 200) {
      dispatch(
        RECON_LOAD_DIMENSION_MEMBERS({
          response: response,
        })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

// Get Recon transformation details
export const listTransformation = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makeGetAPICall("transformation/list/" + payload);
    if (response.status === 200) {
      dispatch(
        LOAD_TRANSFORMATION_MEMBERS({
          response: response,
        })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const updateTransformationMember = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPICall("transformation/update", payload);
    if (response.status === 200) {
      dispatch(
        UPDATE_TRANSFORMATION_MEMBERS({
          response: response,
          recon_id: payload.recon_id,
        })
      );
      dispatch(listTransformationSync(payload.recon_id));
      dispatch(listtransformationSyncCombination(payload.recon_id));
      toast.success("Transformation members updated successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const transformSyncImport = (formData, appType) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPIFormData(
      "transformation/sync/import",
      formData
    );
    if (response.status === 200) {
      dispatch(
        RECON_IMPORT_TRANSFORM_MAPPINGS({
          response: response,
        })
      );
      // dispatch(listTransformationSync());
      toast.success("File imported successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const downloadTransformSyncMap = (payload) => async (dispatch) => {
  try {
    dispatch(isLoading({ loading: true }));
    const response = await makePostAPICallFileDownload(
      "transformation/sync/export",
      payload
    );
    if (response.status === 200) {
      toast.success("Download triggered successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const listTransformationSync = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makeGetAPICall(
      "transformation/sync/list/" + payload
    );
    if (response.status === 200) {
      dispatch(
        LOAD_TRANSFORMATION_SYNC({
          response: response,
        })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const updateTransformationSync = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPICall(
      "transformation/sync/update",
      payload
    );
    if (response.status === 200) {
      dispatch(
        UPDATE_TRANSFORMATION_SYNC_MEMBERS({
          response: response,
        })
      );
      dispatch(listTransformationSync(payload.recon_id));
      toast.success("Transformation Sync updated successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const listtransformationSyncCombination =
  (payload) => async (dispatch) => {
    try {
      dispatch(enableLoader());
      const response = await makeGetAPICall(
        "transformation/sync/combinations/" + payload
      );
      if (response.status === 200) {
        dispatch(TRANSFORM_LOAD_COMBINATIONS({ response: response }));
      } else if (response.status === 401) {
        dispatch(INVALID_SESSION(response));
        redirectToLogin();
      } else {
        toast.error(response.message);
      }
      dispatch(hideLoader());
    } catch (err) {
      dispatch(hideLoader());
    }
  };

// Delete transform sync based on reconid
export const deleteTransformSync = (payload, appType) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makeDeleteBodyParamAPICall(
      "transformation/sync/delete",
      payload
    );
    if (response.status === 200) {
      dispatch(
        DELETE_TRANSFORM_SYNC({
          response: {
            appType: appType,
            syncId: payload.sync_id,
          },
        })
      );
      dispatch(listTransformationSync(payload.recon_id));
      toast.success("Transformation sync deleted successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

//runtransformation
export const runTransform = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePostAPICall("transformation/run", payload);
    if (response.status === 200) {
      dispatch(
        RECON_LOAD_RUN_TRANSFORMATION({
          response: response,
        })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.info("Please click on the refresh data button");
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const exportruntransformation = (payload) => async (dispatch) => {
  try {
    dispatch(isLoading({ loading: true }));
    const response = await makeGetAPICallFileDownload(
      "transformation/run/export/",
      payload
    );
    if (response.status === 200) {
      toast.success("Download triggered successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

//runmport source data export
export const exportrunimport = (payload) => async (dispatch) => {
  try {
    dispatch(isLoading({ loading: true }));
    const response = await makePostAPICallFileDownload(
      "source/export",
      payload
    );
    if (response.status === 200) {
      toast.success("Source data downloaded successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

// export const exportrunbridge = (payload) => async (dispatch) => {
//   try {
//     dispatch(isLoading({ loading: true }));
//     const response = await makePostAPICallFileDownload(
//       "bridge/run/export/",
//       payload
//     );
//     if (response.status === 200) {
//       toast.success("Download triggered successfully");
//     } else if (response.status === 401) {
//       dispatch(INVALID_SESSION(response));
//       redirectToLogin();
//     } else {
//       toast.error(response.message);
//     }
//     dispatch(hideLoader());
//   } catch (err) {
//     dispatch(hideLoader());
//   }
// };

export const downloadRunBridge = (payload) => async (dispatch) => {
  try {
    dispatch(isLoading({ loading: true }));
    const response = await makePostAPICallFileDownload(
      "bridge/run/export/",
      payload
    );
    if (response.status === 200) {
      // dispatch(RUN_IMPORT_UPDATE({
      //     response: response,
      //     appType: appType
      // }));
      toast.success("Download triggered successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

//runreport
export const runReportPost = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader({ loading: true }));
    const response = await makePostAPICall("report/run", payload);
    if (response.status === 200) {
      dispatch(
        RECON_LOAD_RUN_REPORT({
          response,
        })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.info("Please click on the refresh data button");
      dispatch(
        RECON_LOAD_RUN_REPORT_EMPTY({
          response: [],
        })
      );
    }
    dispatch(hideLoader({ loading: false }));
  } catch (err) {
    dispatch(hideLoader({ loading: false }));
    dispatch(
      RECON_LOAD_RUN_REPORT({
        response: {},
      })
    );
  }
};

export const runReportPostFilter = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader({ loading: true }));
    const response = await makePostAPICall("report/run", payload);
    if (response.status === 200) {
      dispatch(
        RECON_LOAD_RUN_REPORT_FILTER({
          response: response,
          newdata: payload,
        })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
      dispatch(
        RECON_LOAD_RUN_REPORT_EMPTY({
          response: [],
        })
      );
    }
    dispatch(hideLoader({ loading: false }));
  } catch (err) {
    dispatch(hideLoader({ loading: false }));
    dispatch(
      RECON_LOAD_RUN_REPORT({
        response: {},
      })
    );
  }
};
export const exportrunreport = (payload) => async (dispatch) => {
  try {
    dispatch(isLoading({ loading: true }));
    const response = await makePostAPICallFileDownload(
      "report/run/export",
      payload
    );
    if (response.status === 200) {
      toast.success("Download triggered successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

//dimension tab import export
export const dimensionsImport = (formData) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPIFormData("recon/dim/import", formData);
    if (response.status === 200) {
      dispatch(
        RECON_IMPORT_DIMENSIONS({
          response: response,
        })
      );
      toast.success("File imported successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const downloadApp1App2DimensionsFile = (payload) => async (dispatch) => {
  try {
    dispatch(isLoading({ loading: true }));
    const response = await makeGetAPICallFileDownload(
      "recon/dim/export/",
      payload
    );
    if (response.status === 200) {
      toast.success("Download triggered successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const archiveRunReport = (payload) => async (dispatch) => {
  try {
    dispatch(isLoading({ loading: true }));
    const response = await makeZIPGetAPICallFileDownload(
      "report/run/archive/",
      payload
    );
    if (response.status === 200) {
      toast.success("Download triggered successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

//journal entry
export const exportJournalEntry = (payload) => async (dispatch) => {
  try {
    dispatch(isLoading({ loading: true }));
    const response = await makePostAPICallFileDownload(
      "source/export",
      payload
    );
    if (response.status === 200) {
      toast.success("JE data downloaded successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const JEsourceDataImport = (formData, appType) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPIFormData(
      "source/file/je/import",
      formData
    );
    if (response.status === 200) {
      dispatch(
        RUN_JE_IMPORT_UPDATE({
          response: response,
          appType: appType,
        })
      );
      toast.success("File imported successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const downloadJECommentsFile = (payload) => async (dispatch) => {
  try {
    dispatch(isLoading({ loading: true }));
    const response = await makeGetAPICallFileDownload(
      "bridge/comments/je/export/",
      payload
    );
    if (response.status === 200) {
      toast.success("Download triggered successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const jecommentsImport = (formData) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPIFormData(
      "bridge/comments/je/import",
      formData
    );
    if (response.status === 200) {
      dispatch(
        RECON_IMPORT_JE_COMMENTS({
          response: response,
        })
      );
      toast.success("File imported successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

// Delete jecomments
export const deleteJEComments = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makeDeleteBodyParamAPICall(
      "bridge/comments/je/delete",
      payload
    );
    if (response.status === 200) {
      dispatch(deleteInvalidJEComments(payload.bridge_id));
      toast.success("JE comment is deleted successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const updateJECommentBridge = (payload) => async (dispatch) => {
  try {
    dispatch(enableLoader());
    const response = await makePutAPICall("bridge/comments/je/update", payload);
    if (response.status === 200) {
      dispatch(
        LOAD_JE_COMMENTS({
          response: response,
        })
      );
      toast.success("JE comment updated successfully");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const getJESourceData = (payload) => async (dispatch) => {
  try {
    dispatch(isLoading({ loading: true }));
    const response = await makePostAPICall("source/je/data", payload);
    if (response.status === 200) {
      dispatch(
        LOAD_RUN_JE_IMPORT({
          response: response,
        })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const roleChanged = (payload) => async (dispatch) => {
  dispatch(enableLoader({ loading: true }));
  const response = await makePostAPICall("user/dashboard", {
    product: payload.value,
  });
  if (response.status == "200") {
    dispatch(USER_ROLE_CHANGED(response));
  } else {
    dispatch(failedRetrive({ message: response.data, ...payload }));
  }
  dispatch(hideLoader({ loading: false }));
};
//DIRECT CONNCET

export const getDirectConnectSourceData = (payload) => async (dispatch) => {
  try {
    dispatch(isLoading({ loading: true }));
    const response = await makePostAPICall("source/dc/import", payload);
    if (response.status === 200) {
      dispatch(
        LOAD_DIRECTCONNECT_RUN_IMPORT({
          response: response,
        })
      );
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export const defaultAPIcall = (payload) => async (dispatch) => {
  try {
    dispatch(isLoading({ loading: true }));
    const response = await makePostAPICall("bridge/default", payload);
    if (response.status === 200) {
      dispatch(listBridgeMembers(payload.recon_id));
      toast.success("Source members are defaulted to bridge members");
    } else if (response.status === 401) {
      dispatch(INVALID_SESSION(response));
      redirectToLogin();
    } else {
      toast.error(response.message);
    }
    dispatch(hideLoader());
  } catch (err) {
    dispatch(hideLoader());
  }
};

export default dashboardReducer.reducer;
