CREATE OR REPLACE PROCEDURE admin.errorlog(useremail character varying, logtime character varying, fromapi character varying, errordesc character varying)
 LANGUAGE plpgsql
AS $procedure$  
BEGIN 
	
   INSERT INTO admin."ErrorLogs" (email,"time",api,description) VALUES
    (UserEmail,LogTime,FromAPI,ErrorDesc);
	
END  
$procedure$
;

-- Permissions

ALTER PROCEDURE "admin".errorlog(varchar, varchar, varchar, varchar) OWNER TO "user_dataRecon_admin";
GRANT ALL ON PROCEDURE "admin".errorlog(varchar, varchar, varchar, varchar) TO postgres;
