import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { getUserlist, resendInvite } from '../../store/sliceReducers/UserReducer';
import { getToken } from '../../utils/utils';
import moment from 'moment';
import { Button } from 'primereact/button';
import { Dropdown } from 'primereact/dropdown';
import { InputText } from 'primereact/inputtext';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Badge } from 'primereact/badge';
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import { FilterMatchMode, FilterOperator } from 'primereact/api';
import 'primereact/resources/primereact.css';
import 'primeflex/primeflex.css';
import "../users/userList.scss";

export const InvUserTable = (props) => {
  const dispatch = useDispatch();
  const { data } = useSelector((state) => state.user);
  const [globalFilterValue, setGlobalFilterValue] = useState('');
  const [filters, setFilters] = useState(null);
  const [loggedInUser, setLoggedInUser] = useState('');
  //  Select table (invited or registered)
  const tableNames = [
    { name: 'Registered users', code: 'reg' },
    { name: 'Invited Users', code: 'inv' },
  ];

  const [selectedtable, setSelectedTable] = useState('Invited Users')

  // function for setting option to select table 
  const selectedtableHandler = (e) => {
    setSelectedTable(e.value);
    props.selectedtableHandler(e.value.name);
  }
  useEffect(() => {
    let userObj = getToken('objUser');
    setLoggedInUser(userObj.email);
    dispatch(getUserlist("general/invite/list"))
    initFilters();
  }, []);

  // consume response from call get userlist API based on selected option
  const usersList = data.data;
  let updatedList = usersList.map(
    (item) => (
      {
        ...item, privilege: (item.access_type.privilege ? 'Read' : 'Write')
      }
    ))
  //its called on clicking clear filters to set default table
  const initFilters = () => {
    setFilters({
      'global': { value: null, matchMode: FilterMatchMode.CONTAINS },
      'first_name': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'email': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'status': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'role': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'privilege': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
    });
    setGlobalFilterValue('');
  }

  const clearFilter = () => {
    initFilters();
  }

  const onGlobalFilterChange = (e) => {
    const value = e.target.value;
    let _filters = { ...filters };
    _filters['global'].value = value;
    setFilters(_filters);
    setGlobalFilterValue(value);
  }

  const checkExpired = (Data) => {
    var startTime = moment(Data);
    var endTime = moment();

    var hoursDiff = endTime.diff(startTime, 'hours');
    let status = hoursDiff >= 24 ? 'expired' : 'pending';
    return status;
  }

  const statusinvTemplate = (rowData) => {
    let status = checkExpired(rowData.created_date)
    return <Badge value={status} severity={`${(status === "pending" ? "info" : "success")}`} className="mr-2"></Badge>;
  }

  const roleTemplate = (rowData) => {
    return rowData.role;
  }
  
  const reinvite = (data) => {

    let payload = {
      'email': data.email,
      // 'role': data.role,
      // 'access_type': data.access_type
    }

    dispatch(resendInvite(payload));
  }

  const actionBodyTemplate = (rowData) => {
    let status = checkExpired(rowData.created_date) === 'expired' ? true : false;
    return (
      <React.Fragment>
        <Button icon="pi pi-send" className="p-button-rounded mx-1 bg-primary"
          tooltip="Resend" tooltipOptions={{ "position": "top" }}
          onClick={(e) => reinvite(rowData)} />
      </React.Fragment>
    );
  }

  // Function returns table header and search field
  const renderHeader1 = () => {
    return (
      <div className="flex justify-content-between"
        style={{ display: 'inlineFlex' }}>

        <span style={{ margin: '10px', marginTop: '20px' }}>Invited users details</span>

        <div style={{ margin: '10px' }}>
          <span className="field p-float-label"
            style={{ marginLeft: '10px', float: 'left' }}>
            <Dropdown optionLabel="name"
              inputId="tabledropdown"
              style={{ width: '200px' }}
              value={selectedtable}
              options={tableNames}
              onChange={(e) => selectedtableHandler(e)}
              placeholder={selectedtable} />
            <label htmlFor="tabledropdown">Select Users</label>
          </span>

          <Button type="button"
            icon="pi pi-filter-slash"
            title="Clear" className="p-button-rounded  ml-2 bg-primary" onClick={clearFilter} />

          <span className="p-input-icon-left" style={{ marginLeft: '10px', float: 'left' }}>
            <i className="pi pi-search" />
            <InputText value={globalFilterValue}
              onChange={onGlobalFilterChange}
              placeholder="Search" />
          </span>
        </div>
      </div>
    )
  }

  const header1 = renderHeader1();

  return (
    <div style={{ fontFamily: "'Open Sans', sans-serif" }}>
      <DataTable value={updatedList}
        id="userTable"
        dataKey="email"
        showGridlines
        sortMode="multiple"
        scrollable
        className="mt-6"
        removableSort
        scrollHeight="420px"
        scrollDirection="both"
        paginator
        filterDisplay="menu"
        globalFilterFields={['first_name', 'email', 'status', 'role', 'privilege']}
        header={header1}
        paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
        currentPageReportTemplate="Showing {first} to {last} of {totalRecords}"
        rows={5}
        filters={filters}
        responsiveLayout="scroll"
        rowsPerPageOptions={[5, 10, 20, 50]}
        emptyMessage="No data found.">
        <Column style={{ width: '45%' }} className="ellipsify" align="start"
          field="email" header="Email" filter sortable></Column>
        <Column style={{ width: '15%' }}
          field="role"
          align="center" header="Role"
          sortable filter body={roleTemplate} ></Column>
        <Column style={{ width: '15%' }}
          field="privilege"
          align="center"
          header="Access Type"
          filterMatchMode='startswith'
          sortable filter={true} ></Column>
        <Column style={{ width: '13%' }}
          align="center"
          field="status"
          header="Status" sortable
          body={statusinvTemplate} filter ></Column>
        <Column style={{ width: '10%' }} align="center" field="name"
          body={actionBodyTemplate} header="Reinvite" ></Column>
      </DataTable>
    </div>
  )
}

