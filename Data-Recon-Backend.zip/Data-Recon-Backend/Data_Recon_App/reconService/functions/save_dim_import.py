from ...utils.get_recon import get_recon
from ...models import ReconDimensions
from ..serializers import DimensionSerializer

'''
<!---------- Method to get save the structured data to db
             and return the structured data back ----------!>
'''


def save_dim_import(dim_data):
    recon_id = dim_data['recon_id']
    app_type = dim_data['app_type']
    recon_data = get_recon(recon_id)
    app_id = recon_data['app1_id'] if app_type == '0' else recon_data['app2_id']

    number_of_dims = len(dim_data['rows'])
    for i in range(0, number_of_dims):
        dim_data['rows'][i]['recon_id'] = recon_id
        dim_data['rows'][i]['app_id'] = app_id
        dim_data['rows'][i]['app_type'] = app_type

        # Save / Updating bridge
        if 'bridge_id' in dim_data['rows'][i]:
            if ReconDimensions.objects.filter(recon_id=recon_id,
                                              dim_id=dim_data['rows'][i]['dim_id']).exists():
                dim_instance = ReconDimensions.objects.filter(recon_id=recon_id,
                                                                 dim_id=dim_data['rows'][i]['dim_id'])[0]
                if dim_data['rows'][i]['dim_id']:
                    dim_data['rows'][i]['is_invalid'] = False
                else:
                    dim_data['rows'][i]['is_invalid'] = True
                serialized = DimensionSerializer(dim_instance, data=dim_data['rows'][i], partial=True)
        else:
            if ReconDimensions.objects.filter(
                    app_id=app_id, dim_id=dim_data['rows'][i]['dim_id'],
                    app_type=app_type, recon_id=recon_id,
                    source_member=dim_data['rows'][i]['source_member'], is_deleted=False).exists():
                dim_instance = ReconDimensions.objects.filter(
                    app_id=app_id, dim_id=dim_data['rows'][i]['dim_id'],
                    app_type=app_type, recon_id=recon_id,
                    source_member=dim_data['rows'][i]['source_member'], is_deleted=False)[0]
                serialized = DimensionSerializer(dim_instance, data=dim_data['rows'][i], partial=True)
            elif ReconDimensions.objects.filter(
                    app_id=app_id, dim_id=None,
                    app_type=app_type, recon_id=recon_id,
                    source_member=dim_data['rows'][i]['source_member'], is_deleted=False).exists():
                dim_instance = ReconDimensions.objects.filter(
                    app_id=app_id, dim_id=None,
                    app_type=app_type, recon_id=recon_id,
                    source_member=dim_data['rows'][i]['source_member'], is_deleted=False)[0]
                if dim_data['rows'][i]['dim_id']:
                    dim_data['rows'][i]['is_invalid'] = False
                else:
                    dim_data['rows'][i]['is_invalid'] = True
                serialized = DimensionSerializer(dim_instance, data=dim_data['rows'][i], partial=True)
            else:
                serialized = DimensionSerializer(data=dim_data['rows'][i])

        if serialized.is_valid():
            serialized.save()
        else:
            response_data = {
                'status': 6002,
                'message': serialized.errors
            }
            return response_data

    response_data = {
        'status': 200,
        'message': 'Saved successfully!'
    }
    return response_data
